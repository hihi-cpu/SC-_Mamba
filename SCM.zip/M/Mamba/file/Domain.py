import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from typing import Dict, Tuple
import copy
import os
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm
from models.Softclustering import ClusterGuidedPredictor


class MMDLoss(nn.Module):
    def __init__(self, kernel_type='rbf', kernel_mul=2.0, kernel_num=5):
        super().__init__()
        self.kernel_mul = kernel_mul
        self.kernel_num = kernel_num

    def forward(self, source, target):
        batch_size = min(source.size(0), target.size(0))
        source = source[:batch_size]
        target = target[:batch_size]

        # 计算固定带宽
        bandwidth = 1.0

        mmd_total = 0.0
        for i in range(self.kernel_num):
            sigma = bandwidth * (self.kernel_mul ** i)

            # 计算核矩阵
            def compute_kernel(x, y, sigma):
                # 计算成对距离
                x_norm = (x ** 2).sum(1).view(-1, 1)
                y_norm = (y ** 2).sum(1).view(1, -1)
                dist = x_norm + y_norm - 2.0 * torch.mm(x, y.t())

                # 防止数值不稳定
                dist = torch.clamp(dist, min=1e-8)

                return torch.exp(-dist / (2.0 * sigma ** 2))

            K_XX = compute_kernel(source, source, sigma)
            K_YY = compute_kernel(target, target, sigma)
            K_XY = compute_kernel(source, target, sigma)

            # 计算MMD
            mmd = K_XX.mean() + K_YY.mean() - 2 * K_XY.mean()

            # 确保非负
            mmd = torch.clamp(mmd, min=0.0)
            mmd_total += mmd

        return mmd_total / self.kernel_num


class MultiMetricLoss(nn.Module):
    """多指标损失函数：MAE、RMSE和R²"""

    def __init__(self):
        super().__init__()

    def mae_loss(self, pred, target):
        """平均绝对误差"""
        return F.l1_loss(pred, target)

    def rmse_loss(self, pred, target):
        """均方根误差"""
        mse = F.mse_loss(pred, target)
        return torch.sqrt(mse + 1e-8)  # 添加小常数避免梯度消失

    def r2_loss(self, pred, target):
        """
        R²损失（转换为越小越好）
        R² = 1 - SS_res / SS_tot
        R² loss = 1 - R² = SS_res / SS_tot
        这样R²越高，损失越小
        """
        # 计算残差平方和
        ss_res = torch.sum((target - pred) ** 2)

        # 计算总平方和
        target_mean = torch.mean(target)
        ss_tot = torch.sum((target - target_mean) ** 2)

        # 避免除零
        ss_tot = torch.clamp(ss_tot, min=1e-8)

        # R² loss = SS_res / SS_tot (越小越好)
        r2_loss = ss_res / ss_tot

        return r2_loss

    def forward(self, pred, target, focus_metric='mae', weights=None):
        """
        计算组合损失

        Args:
            pred: 预测值
            target: 目标值
            focus_metric: 当前关注的主要指标 ('mae', 'rmse', 'r2')
            weights: 自定义权重字典，如 {'mae': 0.5, 'rmse': 0.3, 'r2': 0.2}

        Returns:
            total_loss: 总损失
            metrics_dict: 各指标值的字典
        """
        # 计算三个指标
        mae = self.mae_loss(pred, target)
        rmse = self.rmse_loss(pred, target)
        r2 = self.r2_loss(pred, target)

        # 如果提供了自定义权重，使用自定义权重
        if weights is not None:
            w_mae = weights.get('mae', 0.33)
            w_rmse = weights.get('rmse', 0.33)
            w_r2 = weights.get('r2', 0.34)
        else:
            # 根据focus_metric动态调整权重
            if focus_metric == 'mae':
                w_mae, w_rmse, w_r2 = 0.7, 0.15, 0.15
            elif focus_metric == 'rmse':
                w_mae, w_rmse, w_r2 = 0.15, 0.7, 0.15
            elif focus_metric == 'r2':
                w_mae, w_rmse, w_r2 = 0.15, 0.15, 0.7
            else:
                # 默认均等权重
                w_mae, w_rmse, w_r2 = 0.33, 0.33, 0.34

        # 计算加权总损失
        total_loss = w_mae * mae + w_rmse * rmse + w_r2 * r2

        # 返回损失和各指标值
        metrics_dict = {
            'mae': mae.item(),
            'rmse': rmse.item(),
            'r2_loss': r2.item(),
            'r2_score': 1.0 - r2.item(),  # 真实的R²分数
            'weights': {'mae': w_mae, 'rmse': w_rmse, 'r2': w_r2}
        }

        return total_loss, metrics_dict


class FeatureExtractor:
    """简化版特征提取器 - 直接从模型输出获取特征"""

    def __init__(self, model):
        self.model = model

    def extract(self, x, require_grad=False):
        """
        提取特征 - 直接从模型输出获取
        Args:
            x: 输入数据
            require_grad: 是否需要梯度
        Returns:
            features: [B, D] 特征张量
        """
        if require_grad:
            # 需要梯度的情况
            outputs = self.model(x)
        else:
            # 不需要梯度的情况
            with torch.no_grad():
                outputs = self.model(x)

        # 从输出中提取特征
        if isinstance(outputs, dict):
            # 尝试不同特征名称
            for key in ['features', 'hidden_state', 'encoder_output', 'fine_features']:
                if key in outputs:
                    feat = outputs[key]
                    if feat.dim() == 3:
                        feat = feat.mean(dim=1)  # 时间维度平均
                    return feat
            # 如果没有找到特定特征，使用第一个张量
            for key, value in outputs.items():
                if torch.is_tensor(value) and value.dim() in [2, 3]:
                    feat = value
                    if feat.dim() == 3:
                        feat = feat.mean(dim=1)
                    return feat
        else:
            # 直接输出
            feat = outputs
            if feat.dim() == 3:
                feat = feat.mean(dim=1)
            return feat

        # 如果都没有，返回随机特征
        batch_size = x.size(0)
        return torch.randn(batch_size, 32, device=x.device)


class MMDDomainAdaptationTrainerSimple:
    """
    简化版MMD域适应训练器（多指标版本）
    核心修复：不使用钩子，直接从模型输出获取特征
    新增功能：使用MAE、RMSE、R²三个指标，轮流作为主要优化目标
    """

    def __init__(self,
                 source_model,
                 target_model,
                 feature_dim: int = 32,
                 device: str = 'cuda:0',
                 mmd_weight: float = 0.3,
                 causal_weight: float = 0.2,  # 新增：因果对齐权重
                 metric_cycle_epochs: int = 10):
        """
        新增参数:
        causal_weight: 因果矩阵对齐损失权重
        """
        self.device = device
        self.feature_dim = feature_dim
        self.mmd_weight = mmd_weight
        self.causal_weight = causal_weight  # 新增
        self.metric_cycle_epochs = metric_cycle_epochs

        # 模型
        self.source_model = source_model.to(device)
        self.target_model = target_model.to(device)

        # 冻结源模型
        for param in self.source_model.parameters():
            param.requires_grad = False
        self.source_model.eval()

        # 损失函数
        self.mmd_loss = MMDLoss(kernel_type='rbf', kernel_mul=2.0, kernel_num=5)
        self.multi_metric_loss = MultiMetricLoss()

        # 新增：因果对齐模块
        self.causal_alignment = FastCausalMatrixAlignment(
            target_size=200  # 可选：指定目标尺寸，如果不指定则自动计算
        ).to(device)

        # 城市信息（用于掩码处理）
        self.source_info = None
        self.target_info = None

        # 优化器
        self.optimizer = optim.Adam(
            self.target_model.parameters(),
            lr=1e-4,
            weight_decay=1e-5
        )

        # 训练状态
        self.best_val_loss = float('inf')
        self.best_model_state = None
        self.history = {
            'train_loss': [],
            'pred_loss': [],
            'mmd_loss': [],
            'causal_loss': [],  # 新增：因果损失
            'mae': [],
            'rmse': [],
            'r2_loss': [],
            'r2_score': [],
            'val_mae': [],
            'val_rmse': [],
            'val_r2': [],
            'focus_metric': []
        }

    def set_city_info(self, source_info, target_info):
        """设置城市信息，用于掩码处理"""
        self.source_info = source_info
        self.target_info = target_info

    def prepare_masks(self, batch_size):
        return None, None
    def get_focus_metric(self, epoch: int) -> str:
        """
        根据epoch确定当前关注的主要指标
        每metric_cycle_epochs个epoch切换一次指标
        """
        cycle_position = (epoch // self.metric_cycle_epochs) % 3

        if cycle_position == 0:
            return 'mae'
        elif cycle_position == 1:
            return 'rmse'
        else:
            return 'r2'

    def extract_features_fixed(self, model, x, model_type='source'):
        """
        修复特征提取：确保特征维度正确
        Args:
            model: 模型
            x: 输入数据 [B, T, N]
            model_type: 'source' 或 'target'
        Returns:
            features: [B, D] 特征张量
        """
        batch_size = x.size(0)

        # 获取模型输出
        outputs = model(x)

        # 提取特征
        if isinstance(outputs, dict):
            # 尝试获取特征
            if 'features' in outputs:
                feats = outputs['features']
            elif 'encoder_output' in outputs:
                feats = outputs['encoder_output']
            elif 'hidden_state' in outputs:
                feats = outputs['hidden_state']
            else:
                # 取第一个张量
                for key, value in outputs.items():
                    if torch.is_tensor(value) and value.dim() in [2, 3]:
                        feats = value
                        break
                else:
                    feats = outputs['fine_predictions'] if 'fine_predictions' in outputs else None
        else:
            feats = outputs

        if feats is None:
            # 创建随机特征（备份）
            return torch.randn(batch_size, self.feature_dim, device=x.device)

        # 处理特征维度
        if feats.dim() == 3:
            # [B, T, N] -> [B, N] 或 [B, D]
            # 根据模型类型处理
            if model_type == 'source' and feats.size(-1) == 460:  # 源城市网格数
                # 源模型：对整个网格的特征，取平均
                feats = feats.mean(dim=1)  # [B, 460]
                # 进一步压缩到特征维度
                if feats.size(1) > self.feature_dim:
                    # 使用PCA-like的线性投影
                    feats = F.adaptive_avg_pool1d(feats.unsqueeze(1), self.feature_dim).squeeze(1)
            else:
                # 目标模型或其他情况：时间维度平均
                feats = feats.mean(dim=1)  # [B, N] 或 [B, D]

        # 确保输出维度正确
        if feats.size(1) > self.feature_dim:
            # 如果特征维度太大，压缩
            feats = feats[:, :self.feature_dim]
        elif feats.size(1) < self.feature_dim:
            # 如果特征维度太小，填充
            padding = torch.zeros(
                batch_size,
                self.feature_dim - feats.size(1),
                device=x.device,
                requires_grad=False
            )
            feats = torch.cat([feats, padding], dim=1)

        return feats

    def train_epoch_simple(self, source_loader: DataLoader, target_loader: DataLoader,
                           epoch: int, total_epochs: int) -> Dict:
        """增强版训练epoch：集成因果对齐"""

        self.target_model.train()

        stats = {
            'total_loss': 0.0,
            'pred_loss': 0.0,
            'mmd_loss': 0.0,
            'causal_loss': 0.0,  # 新增
            'mae': 0.0,
            'rmse': 0.0,
            'r2_loss': 0.0,
            'r2_score': 0.0,
        }

        # 确定当前epoch关注的主要指标
        focus_metric = self.get_focus_metric(epoch)

        min_batches = min(len(source_loader), len(target_loader))
        source_iter = iter(source_loader)
        target_iter = iter(target_loader)

        # 准备掩码
        source_mask, target_mask = self.prepare_masks(min_batches)

        pbar = tqdm(range(min_batches),
                    desc=f'Epoch {epoch + 1}/{total_epochs} [Focus: {focus_metric.upper()}]')

        for batch_idx in pbar:
            try:
                # 获取批次数据
                source_batch = next(source_iter)
                target_batch = next(target_iter)

                source_flow, _, _, _ = source_batch
                target_flow, _, _, target_target = target_batch

                # 处理输入形状（应用掩码）
                if source_flow.dim() == 4:
                    B, T, H, W = source_flow.shape
                    source_flow = source_flow.view(B, T, H * W)
                    # 应用源域掩码
                    if source_mask is not None:
                        source_flow = source_flow[:, :, source_mask]

                if target_flow.dim() == 4:
                    B, T, H, W = target_flow.shape
                    target_flow = target_flow.view(B, T, H * W)
                    # 应用目标域掩码
                    if target_mask is not None:
                        target_flow = target_flow[:, :, target_mask]

                source_flow = source_flow.to(self.device)
                target_flow = target_flow.to(self.device)
                target_target = target_target.to(self.device).view(target_target.size(0), -1)

                # ==================== 获取模型输出 ====================
                # 源域输出（无梯度）
                with torch.no_grad():
                    source_outputs = self.source_model(
                        source_flow,
                        return_cluster_info=False,
                        return_causal_matrix=True
                    )

                # 目标域输出
                target_outputs = self.target_model(
                    target_flow,
                    return_cluster_info=False,
                    return_causal_matrix=True
                )

                # 提取因果矩阵
                source_fine_causal = source_outputs.get('fine_causal_matrix')
                target_fine_causal = target_outputs.get('fine_causal_matrix')

                # ==================== 因果矩阵对齐（减少频率） ====================
                # 只在特定批次进行因果对齐
                should_align_causal = (
                        batch_idx % 10 == 0 or  # 每10个批次对齐一次
                        batch_idx < 10 or  # 前10个批次都对齐
                        epoch == 0  # 第一个epoch多对齐
                )

                if should_align_causal and source_fine_causal is not None and target_fine_causal is not None:
                    # 检查维度
                    if source_fine_causal.shape != target_fine_causal.shape:
                        # 只在前几个批次显示警告

                        # 对齐到最小维度
                        min_dim = min(source_fine_causal.size(0), target_fine_causal.size(0))

                        if min_dim > 0:
                            source_aligned = source_fine_causal[:min_dim, :min_dim]
                            target_aligned = target_fine_causal[:min_dim, :min_dim]

                            causal_loss, causal_metrics = self.causal_alignment(
                                {'fine_causal_matrix': source_aligned},
                                {'fine_causal_matrix': target_aligned},
                                None, None,
                                debug=False  # 关闭调试输出
                            )

                            # 只在前几个批次显示对齐结果
                            if epoch < 2 and batch_idx < 5:
                                print(f"✅ 对齐后因果损失: {causal_loss.item():.6f}")
                        else:
                            causal_loss = torch.tensor(0.0, device=self.device)
                else:
                    # 不使用因果对齐时，损失设为0
                    causal_loss = torch.tensor(0.0, device=self.device)

                # ==================== 获取预测结果 ====================
                target_pred = target_outputs['fine_predictions']
                if target_pred.dim() == 3:
                    target_pred = target_pred.squeeze(1)

                # ==================== 计算多指标预测损失 ====================
                min_dim = min(target_pred.size(1), target_target.size(1))
                pred_loss, metrics = self.multi_metric_loss(
                    target_pred[:, :min_dim],
                    target_target[:, :min_dim],
                    focus_metric=focus_metric
                )

                # ==================== 提取特征用于MMD对齐 ====================
                source_feats = self.extract_features_fixed(
                    self.source_model, source_flow, model_type='source'
                )
                target_feats = self.extract_features_fixed(
                    self.target_model, target_flow, model_type='target'
                )

                # ==================== 计算MMD损失 ====================
                batch_size = min(source_feats.size(0), target_feats.size(0))
                source_feats = source_feats[:batch_size]
                target_feats = target_feats[:batch_size]

                mmd_loss = self.mmd_loss(source_feats.detach(), target_feats)

                # ==================== 动态权重调整 ====================
                # 根据训练阶段调整权重
                if epoch < 10:
                    # 初期：更注重预测任务
                    mmd_weight = 0.1
                    causal_weight = 0.1
                elif epoch < 30:
                    # 中期：平衡预测和域对齐
                    mmd_weight = 0.3
                    causal_weight = 0.2
                else:
                    # 后期：加强域对齐
                    mmd_weight = 0.2
                    causal_weight = 0.3

                # 如果预测损失很小，降低域对齐权重
                if pred_loss.item() < 0.001:
                    mmd_weight *= 0.5
                    causal_weight *= 0.5

                # ==================== 总损失 ====================
                total_loss = (
                        pred_loss +
                        mmd_weight * mmd_loss +
                        causal_weight * causal_loss
                )

                # ==================== 反向传播 ====================
                self.optimizer.zero_grad()
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.target_model.parameters(), 1.0)
                self.optimizer.step()

                # ==================== 记录统计 ====================
                stats['total_loss'] += total_loss.item()
                stats['pred_loss'] += pred_loss.item()
                stats['mmd_loss'] += mmd_loss.item()
                stats['causal_loss'] += causal_loss.item()
                stats['mae'] += metrics['mae']
                stats['rmse'] += metrics['rmse']
                stats['r2_loss'] += metrics['r2_loss']
                stats['r2_score'] += metrics['r2_score']

                pbar.set_postfix({
                    'pred': f'{pred_loss.item():.4f}',
                    'mmd': f'{mmd_loss.item():.4f}',
                    'causal': f'{causal_loss.item():.4f}',
                    'mae': f'{metrics["mae"]:.4f}',
                    'r2': f'{metrics["r2_score"]:.4f}',
                })

                # 定期清理GPU缓存
                if batch_idx % 20 == 0:
                    torch.cuda.empty_cache()

            except Exception as e:
                print(f"\n❌ 批次 {batch_idx} 出错: {e}")
                continue

        # 平均统计
        num_batches = batch_idx + 1
        for key in stats:
            if num_batches > 0:
                stats[key] /= num_batches

        stats['focus_metric'] = focus_metric

        return stats
    def get_valid_indices(self):
        """获取源域和目标域的有效节点索引"""
        if self.source_info is None or self.target_info is None:
            return None, None

        try:
            source_valid = self.source_info['valid_indices']
            target_valid = self.target_info['valid_indices']

            return source_valid, target_valid
        except Exception as e:
            print(f"⚠️ 获取有效节点索引失败: {e}")
            return None, None

    def compute_efficient_causal_alignment(self, source_causal, target_causal):
        """
        高效的因果对齐计算 - 专门处理小矩阵
        """
        if source_causal is None or target_causal is None:
            return torch.tensor(0.0, device=self.device)

        # 方法1：如果维度不同，使用自适应对齐
        if source_causal.size(0) != target_causal.size(1):
            # 使用更高效的对齐方法
            return self.adaptive_causal_alignment(source_causal, target_causal)

        # 方法2：维度相同，直接计算相似性
        return self.direct_causal_alignment(source_causal, target_causal)

    def adaptive_causal_alignment(self, source_causal, target_causal):
        """自适应因果对齐 - 处理不同维度"""
        # 获取最小维度
        min_dim = min(source_causal.size(0), target_causal.size(0))

        if min_dim <= 0:
            return torch.tensor(0.0, device=self.device)

        # 截取相同大小的子矩阵
        source_sub = source_causal[:min_dim, :min_dim]
        target_sub = target_causal[:min_dim, :min_dim]

        # 展平为特征向量
        source_features = source_sub.flatten().unsqueeze(0)
        target_features = target_sub.flatten().unsqueeze(0)

        # 计算MMD损失
        loss = self.mmd_loss(source_features, target_features)

        return loss

    def direct_causal_alignment(self, source_causal, target_causal):
        """直接因果对齐 - 维度相同时使用"""
        # 展平为特征向量
        source_features = source_causal.flatten().unsqueeze(0)
        target_features = target_causal.flatten().unsqueeze(0)

        # 计算MMD损失
        loss = self.mmd_loss(source_features, target_features)

        return loss

    def train(self,
              source_loader: DataLoader,
              target_loader: DataLoader,
              target_val_loader: DataLoader,
              epochs: int = 50,
              patience: int = 10) -> Dict:
        """完整训练流程"""
        print(f"\n{'=' * 60}")
        print(f"🚀 开始MMD域适应训练（多指标版本）")
        print(f"{'=' * 60}")
        print(f"训练轮次: {epochs}")
        print(f"早停耐心: {patience}")
        print(f"设备: {self.device}")
        print(f"MMD权重: {self.mmd_weight}")
        print(f"指标循环周期: 每{self.metric_cycle_epochs}轮切换主要指标")
        print(f"指标顺序: MAE → RMSE → R²")
        print(f"{'=' * 60}\n")

        patience_counter = 0

        for epoch in range(epochs):
            train_stats = self.train_epoch_simple(
                source_loader,
                target_loader,
                epoch,
                epochs
            )

            val_metrics = self.validate(target_val_loader)

            # 记录历史
            self.history['train_loss'].append(train_stats['total_loss'])
            self.history['pred_loss'].append(train_stats['pred_loss'])
            self.history['mmd_loss'].append(train_stats['mmd_loss'])
            self.history['mae'].append(train_stats['mae'])
            self.history['rmse'].append(train_stats['rmse'])
            self.history['r2_loss'].append(train_stats['r2_loss'])
            self.history['r2_score'].append(train_stats['r2_score'])
            self.history['val_mae'].append(val_metrics['MAE'])
            self.history['val_rmse'].append(val_metrics['RMSE'])
            self.history['val_r2'].append(val_metrics['R2'])
            self.history['focus_metric'].append(train_stats['focus_metric'])

            print(f"\n{'=' * 60}")
            print(f"Epoch {epoch + 1}/{epochs} 总结 [主要指标: {train_stats['focus_metric'].upper()}]")
            print(f"{'=' * 60}")
            print(f"📊 训练统计:")
            print(f"   总损失: {train_stats['total_loss']:.6f}")
            print(f"   预测损失: {train_stats['pred_loss']:.6f}")
            print(f"   MMD损失: {train_stats['mmd_loss']:.6f}")

            print(f"\n📊 训练指标:")
            print(f"   MAE: {train_stats['mae']:.4f}")
            print(f"   RMSE: {train_stats['rmse']:.4f}")
            print(f"   R² Score: {train_stats['r2_score']:.4f}")

            print(f"\n📊 验证指标:")
            print(f"   MAE: {val_metrics['MAE']:.4f}")
            print(f"   RMSE: {val_metrics['RMSE']:.4f}")
            print(f"   R²: {val_metrics['R2']:.4f}")

            # 保存最佳模型（基于MAE）
            if val_metrics['MAE'] < self.best_val_loss:
                self.best_val_loss = val_metrics['MAE']
                self.best_model_state = copy.deepcopy(self.target_model.state_dict())

                torch.save({
                    'epoch': epoch,
                    'model_state': self.best_model_state,
                    'val_mae': self.best_val_loss,
                    'val_rmse': val_metrics['RMSE'],
                    'val_r2': val_metrics['R2'],
                    'history': self.history,
                }, 'best_mmd_model_multi_metric.pth')

                print(f"\n✅ 保存最佳模型 (MAE: {self.best_val_loss:.4f}, R²: {val_metrics['R2']:.4f})")
                patience_counter = 0
            else:
                patience_counter += 1
                print(f"\n⏳ 早停计数: {patience_counter}/{patience}")

                if patience_counter >= patience:
                    print(f"\n🛑 早停于 epoch {epoch + 1}")
                    break

        # 恢复最佳模型
        if self.best_model_state:
            self.target_model.load_state_dict(self.best_model_state)
            print(f"\n✅ 已恢复最佳模型")

        print(f"\n{'=' * 60}")
        print(f"🎯 训练完成!")
        print(f"{'=' * 60}")
        print(f"最佳验证MAE: {self.best_val_loss:.4f}")
        print(f"最终MMD损失: {self.history['mmd_loss'][-1]:.6f}")
        print(f"最终R² Score: {self.history['val_r2'][-1]:.4f}")

        # 计算指标改善情况
        if len(self.history['mmd_loss']) > 1:
            mmd_improvement = (self.history['mmd_loss'][0] - self.history['mmd_loss'][-1]) / \
                              self.history['mmd_loss'][0] * 100
            print(f"MMD改善: {mmd_improvement:.1f}%")

        print(f"{'=' * 60}\n")

        return self.history

    def validate(self, val_loader: DataLoader) -> Dict:
        """验证 - 计算MAE、RMSE和R²"""
        self.target_model.eval()

        all_preds = []
        all_targets = []

        with torch.no_grad():
            for flow, _, _, target in tqdm(val_loader, desc='验证中'):
                flow = flow.to(self.device).view(flow.size(0), flow.size(1), -1)
                target = target.to(self.device).view(target.size(0), -1)

                outputs = self.target_model(flow)

                if isinstance(outputs, dict):
                    preds = outputs.get('fine_predictions')
                    if preds is None:
                        preds = list(outputs.values())[0]
                else:
                    preds = outputs

                if preds.dim() == 3:
                    preds = preds.squeeze(1)

                min_dim = min(preds.size(1), target.size(1))
                all_preds.append(preds[:, :min_dim].cpu())
                all_targets.append(target[:, :min_dim].cpu())

        if all_preds:
            all_preds = torch.cat(all_preds, dim=0)
            all_targets = torch.cat(all_targets, dim=0)

            # 计算MAE
            mae = F.l1_loss(all_preds, all_targets).item()

            # 计算RMSE
            mse = F.mse_loss(all_preds, all_targets).item()
            rmse = np.sqrt(mse)

            # 计算R²
            ss_res = torch.sum((all_targets - all_preds) ** 2).item()
            ss_tot = torch.sum((all_targets - torch.mean(all_targets)) ** 2).item()
            r2 = 1 - (ss_res / (ss_tot + 1e-8))

            return {
                'MAE': mae,
                'RMSE': rmse,
                'R2': r2,
                'MSE': mse
            }

        return {
            'MAE': float('inf'),
            'RMSE': float('inf'),
            'R2': -float('inf'),
            'MSE': float('inf')
        }


class FastCausalMatrixAlignment(nn.Module):
    """快速因果矩阵对齐 - 与原始接口兼容"""

    def __init__(self, target_size):
        super().__init__()
        self.target_size = target_size
        self.mmd_loss = MMDLoss(kernel_type='rbf', kernel_mul=2.0, kernel_num=3)

    def forward(self, source_outputs, target_outputs, source_mask=None, target_mask=None, debug=False):
        """
        与原始CausalMatrixAlignment接口保持一致
        只处理fine_causal_matrix
        """
        # 提取因果矩阵
        source_causal = source_outputs.get('fine_causal_matrix')
        target_causal = target_outputs.get('fine_causal_matrix')

        if source_causal is None or target_causal is None:
            return torch.tensor(0.0, device=source_causal.device if source_causal is not None else 'cpu'), {
                'fine_causal_loss': 0.0,
                'coarse_causal_loss': 0.0,
                'total_causal_loss': 0.0
            }

        # 快速池化到固定大小
        if source_causal.dim() == 2:
            source_causal = source_causal.unsqueeze(0).unsqueeze(0)
        if target_causal.dim() == 2:
            target_causal = target_causal.unsqueeze(0).unsqueeze(0)

        # 使用自适应池化到固定大小
        source_pooled = F.adaptive_avg_pool2d(source_causal, (self.target_size, self.target_size))
        target_pooled = F.adaptive_avg_pool2d(target_causal, (self.target_size, self.target_size))

        # 展平并计算MMD
        source_features = source_pooled.flatten().unsqueeze(0)
        target_features = target_pooled.flatten().unsqueeze(0)

        loss = self.mmd_loss(source_features, target_features)

        return loss, {
            'fine_causal_loss': loss.item(),
            'coarse_causal_loss': 0.0,
            'total_causal_loss': loss.item()
        }
# 保持原有的工具函数不变
def get_city_node_info(data_dict: Dict, city_name: str) -> Dict:
    """获取城市节点信息"""
    mask = data_dict['mask']
    grid_h, grid_w = mask.shape

    mask_flat = mask.view(-1)
    valid_indices = torch.where(mask_flat)[0]
    fine_nodes = len(valid_indices)

    return {
        'city_name': city_name,
        'grid_size': (grid_h, grid_w),
        'total_nodes': grid_h * grid_w,
        'fine_nodes': fine_nodes,
        'valid_indices': valid_indices,
        'mask': mask
    }


def prepare_models(source_info: Dict,
                   target_info: Dict,
                   device: torch.device) -> Tuple:
    """准备源模型和目标模型"""

    pretrained_path = os.path.join('/mnt/d/python_study/ST-Mamba/file',
                                   'pretrained_integrated_model.pth')

    print(f"\n🔧 准备模型...")

    source_model = ClusterGuidedPredictor(
        fine_nodes=source_info['fine_nodes'],
        grid_size=source_info['grid_size'],
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    ).to(device)

    target_model = ClusterGuidedPredictor(
        fine_nodes=target_info['fine_nodes'],
        grid_size=target_info['grid_size'],
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    ).to(device)

    if os.path.exists(pretrained_path):
        print(f"📥 加载预训练模型: {pretrained_path}")
        try:
            state_dict = torch.load(pretrained_path, map_location=device, weights_only=False)

            # 处理不匹配的键
            model_dict = source_model.state_dict()

            # 1. 筛选出匹配的键
            pretrained_dict = {k: v for k, v in state_dict.items()
                               if k in model_dict and v.size() == model_dict[k].size()}

            # 2. 对于不匹配的键，尝试调整
            for k, v in state_dict.items():
                if k not in pretrained_dict:
                    # 尝试添加下划线前缀
                    if f"_{k}" in model_dict and v.size() == model_dict[f"_{k}"].size():
                        pretrained_dict[f"_{k}"] = v
                    # 尝试移除前缀
                    elif k.startswith('_') and k[1:] in model_dict and v.size() == model_dict[k[1:]].size():
                        pretrained_dict[k[1:]] = v

            # 更新模型参数
            model_dict.update(pretrained_dict)
            source_model.load_state_dict(model_dict)

            print(f"✅ 成功加载 {len(pretrained_dict)}/{len(model_dict)} 个参数到源模型")

        except Exception as e:
            print(f"⚠️ 加载预训练模型失败: {e}")
            print("   将使用随机初始化")
    else:
        print(f"⚠️ 预训练模型不存在: {pretrained_path}")
        print("   将使用随机初始化")

    print(f"\n✅ 模型初始化完成")
    print(f"   源模型 ({source_info['city_name']}): {source_info['fine_nodes']}个节点")
    print(f"   目标模型 ({target_info['city_name']}): {target_info['fine_nodes']}个节点")

    return source_model, target_model


def prepare_data_loaders(source_data: Dict,
                         target_data: Dict,
                         batch_size: int = 16) -> Tuple:
    """准备数据加载器"""

    source_dataset = source_data['dataset']
    source_train_size = int(0.7 * len(source_dataset))
    source_val_size = len(source_dataset) - source_train_size

    source_train_dataset, _ = torch.utils.data.random_split(
        source_dataset, [source_train_size, source_val_size]
    )

    target_dataset = target_data['dataset']
    target_train_size = int(0.7 * len(target_dataset))
    target_val_size = len(target_dataset) - target_train_size

    target_train_dataset, target_val_dataset = torch.utils.data.random_split(
        target_dataset, [target_train_size, target_val_size]
    )

    print(f"\n📊 数据集大小:")
    print(f"   源域训练: {len(source_train_dataset)}")
    print(f"   目标域训练: {len(target_train_dataset)}")
    print(f"   目标域验证: {len(target_val_dataset)}")

    source_loader = DataLoader(
        source_train_dataset,
        batch_size=batch_size,
        shuffle=True,
        drop_last=True,
        num_workers=2,
        pin_memory=True
    )

    target_train_loader = DataLoader(
        target_train_dataset,
        batch_size=batch_size,
        shuffle=True,
        drop_last=True,
        num_workers=2,
        pin_memory=True
    )

    target_val_loader = DataLoader(
        target_val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    print(f"\n📊 数据加载器统计:")
    print(f"   源域批次数: {len(source_loader)}")
    print(f"   目标域训练批次数: {len(target_train_loader)}")
    print(f"   目标域验证批次数: {len(target_val_loader)}")

    return source_loader, target_train_loader, target_val_loader

