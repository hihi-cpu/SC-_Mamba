import torch
import numpy as np
import os

from file.Pretrain import pretrain_source_city_joint
from file.Domain import MMDDomainAdaptationTrainerSimple, prepare_models, get_city_node_info, prepare_data_loaders
from models.targetfinetune import TargetDomainFinetuner, prepare_target_data_splits, plot_training_history
from models.Softclustering import ClusterGuidedPredictor
from models.model_utils import load_city_data


def set_random_seed(seed=42):
    """
    统一设置所有随机种子，确保实验可复现
    """
    print(f"🎲 设置随机种子: {seed}")

    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    print(f"✅ 随机种子设置完成")


def load_normalization_params(city_name, base_data_dir):
    """
    加载指定城市的归一化参数

    Args:
        city_name: 城市名称，如 "DC", "NY"
        base_data_dir: 数据基础目录

    Returns:
        dict: {'max': float, 'min': float}
    """
    city_dir = os.path.join(base_data_dir, city_name)

    max_path = os.path.join(city_dir, 'max_val.npy')
    min_path = os.path.join(city_dir, 'min_val.npy')

    if not os.path.exists(max_path) or not os.path.exists(min_path):
        raise FileNotFoundError(f"归一化参数文件不存在: {city_dir}")

    max_val = np.load(max_path).item()
    min_val = np.load(min_path).item()

    print(f"📊 {city_name} 归一化参数:")
    print(f"   最大值: {max_val}")
    print(f"   最小值: {min_val}")
    print(f"   范围: [{min_val}, {max_val}]")

    return {'max': max_val, 'min': min_val}


def denormalize(normalized_data, norm_params):
    """
    反归一化: 从[0,1]恢复到原始尺度

    公式: original = normalized * (max - min) + min
    """
    max_val = norm_params['max']
    min_val = norm_params['min']

    return normalized_data * (max_val - min_val) + min_val


def calculate_metrics_original_scale_4d(predictions, targets, norm_params):
    """
    计算4D数据的原始尺度指标
    predictions: [B, 1, H, W]
    targets: [B, 1, H, W]
    """
    # 确保是4D
    if len(predictions.shape) != 4 or len(targets.shape) != 4:
        raise ValueError(f"需要4D输入, 但得到 predictions: {predictions.shape}, targets: {targets.shape}")

    # 展平为1D
    pred_flat = predictions.reshape(-1)
    target_flat = targets.reshape(-1)

    print(f"📊 反归一化前统计:")
    print(f"  预测值范围: [{pred_flat.min():.4f}, {pred_flat.max():.4f}]")
    print(f"  目标值范围: [{target_flat.min():.4f}, {target_flat.max():.4f}]")

    # 反归一化
    pred_original = denormalize(pred_flat, norm_params)
    target_original = denormalize(target_flat, norm_params)

    print(f"📊 反归一化后统计:")
    print(f"  预测值范围: [{pred_original.min():.4f}, {pred_original.max():.4f}]")
    print(f"  目标值范围: [{target_original.min():.4f}, {target_original.max():.4f}]")

    # 转换为numpy
    pred_np = pred_original.cpu().numpy() if torch.is_tensor(pred_original) else pred_original
    target_np = target_original.cpu().numpy() if torch.is_tensor(target_original) else target_original

    # 计算指标
    mae = np.mean(np.abs(pred_np - target_np))
    rmse = np.sqrt(np.mean((pred_np - target_np) ** 2))

    ss_res = np.sum((target_np - pred_np) ** 2)
    ss_tot = np.sum((target_np - np.mean(target_np)) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    mask = target_np != 0
    if np.any(mask):
        mape = np.mean(np.abs((target_np[mask] - pred_np[mask]) / target_np[mask])) * 100
    else:
        mape = 0

    return {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'MAPE': mape,
        'predictions_count': len(pred_np),
        'predictions_mean': float(np.mean(pred_np)),
        'targets_mean': float(np.mean(target_np)),
        'predictions_std': float(np.std(pred_np)),
        'targets_std': float(np.std(target_np))
    }


def evaluate_on_test_set_with_denorm(model, test_loader, device, norm_params):
    """
    简化版评估函数 - 直接提取fine_predictions
    模型返回字典，fine_predictions就是融合后的最终预测
    """
    model.eval()
    all_preds_4d = []  # 存储4D预测 [B, 1, H, W]
    all_targets_4d = []  # 存储4D目标 [B, 1, H, W]

    print("📊 开始测试集评估...")
    print("直接提取 'fine_predictions' - 这已经是融合后的结果")

    with torch.no_grad():
        for batch_idx, batch in enumerate(test_loader):
            # 解析batch
            flow_data_4d = batch[0].to(device)  # [B, 6, H, W]
            target_4d = batch[3].to(device)  # [B, 1, H, W]

            # 获取网格尺寸
            B, T_in, H, W = flow_data_4d.shape

            # 转换输入格式: [B, 6, H, W] -> [B, 6, H*W]
            flow_data_3d = flow_data_4d.reshape(B, T_in, H * W)

            # 模型预测
            outputs = model(flow_data_3d)  # 返回字典

            # ✅ 直接提取 fine_predictions - 这已经是融合后的结果
            y_pred_3d = outputs['fine_predictions']  # [B, 1, N]

            # 转换回4D: [B, 1, N] -> [B, 1, H, W]
            y_pred_4d = y_pred_3d.reshape(B, 1, H, W)

            # 添加到列表
            all_preds_4d.append(y_pred_4d)
            all_targets_4d.append(target_4d)

            if (batch_idx + 1) % 20 == 0:
                print(f"  处理批次 {batch_idx + 1}/{len(test_loader)}")

    # 合并所有批次
    all_preds = torch.cat(all_preds_4d, dim=0)
    all_targets = torch.cat(all_targets_4d, dim=0)

    print(f"\n📊 最终形状:")
    print(f"  预测: {all_preds.shape}")
    print(f"  目标: {all_targets.shape}")

    # 计算归一化尺度的指标
    pred_norm = all_preds.cpu().numpy().reshape(-1)
    target_norm = all_targets.cpu().numpy().reshape(-1)

    mae_norm = np.mean(np.abs(pred_norm - target_norm))
    rmse_norm = np.sqrt(np.mean((pred_norm - target_norm) ** 2))
    ss_res = np.sum((target_norm - pred_norm) ** 2)
    ss_tot = np.sum((target_norm - np.mean(target_norm)) ** 2)
    r2_norm = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    # 原始尺度指标
    metrics_original = calculate_metrics_original_scale_4d(all_preds, all_targets, norm_params)

    return {
        'normalized': {
            'MAE': mae_norm,
            'RMSE': rmse_norm,
            'R2': r2_norm,
        },
        'original': metrics_original,
        'predictions_shape': all_preds.shape,
        'targets_shape': all_targets.shape,
        'samples_count': len(pred_norm)
    }


def debug_batch_structure(loader, num_batches=1):
    """调试函数：查看数据加载器的batch结构"""
    print("\n🔍 调试batch结构:")
    for i, batch in enumerate(loader):
        print(f"\nBatch {i}:")
        print(f"  Type: {type(batch)}")

        if isinstance(batch, dict):
            print(f"  Keys: {list(batch.keys())}")
            for key, value in batch.items():
                print(f"    {key}: shape={value.shape}, dtype={value.dtype}")

        elif isinstance(batch, (list, tuple)):
            print(f"  Length: {len(batch)}")
            for j, item in enumerate(batch):
                if torch.is_tensor(item):
                    print(f"    Item {j}: tensor, shape={item.shape}, dtype={item.dtype}")
                else:
                    print(f"    Item {j}: type={type(item)}")

        if i >= num_batches - 1:
            break


def check_model_input_output(model, sample_input):
    """检查模型的输入输出格式"""
    print("\n🔍 检查模型输入输出格式:")
    model.eval()

    with torch.no_grad():
        # 创建不同格式的输入进行测试
        print(f"测试输入形状: {sample_input.shape}")

        # 测试1: 直接传入3D数据
        print("\n测试1: 直接传入3D数据")
        try:
            output1 = model(sample_input)
            print(f"  输出类型: {type(output1)}")
            if isinstance(output1, dict):
                print(f"  输出keys: {list(output1.keys())}")
                for key, value in output1.items():
                    if torch.is_tensor(value):
                        print(f"    {key}: shape={value.shape}")
            elif torch.is_tensor(output1):
                print(f"  输出形状: {output1.shape}")
        except Exception as e:
            print(f"  ❌ 失败: {e}")

        # 测试2: 传入字典格式
        print("\n测试2: 传入字典格式")
        try:
            input_dict = {'flow_data': sample_input}
            output2 = model(input_dict)
            print(f"  输出类型: {type(output2)}")
            if isinstance(output2, dict):
                print(f"  输出keys: {list(output2.keys())}")
        except Exception as e:
            print(f"  ❌ 失败: {e}")


def complete_cross_city_training_pipeline(seed=42):
    """
    完整的跨城市训练流程（改进版）

    改进点:
    1. 阶段2: 只保留R²最佳模型
    2. 阶段3: 使用综合指标（R²为主）
    3. 最终测试: 反归一化后评估
    """
    print("=" * 80)
    print("🚀 完整的跨城市训练流程（改进版）")
    print("=" * 80)
    print("\n本系统包含三个训练阶段:")
    print("   阶段1: 集成模型预训练 (源城市 NY)")
    print("   阶段2: MMD域适应训练 (NY → DC)")
    print("   阶段3: 目标域微调 (DC)")
    print("   最终测试: 反归一化后评估原始尺度指标 ⭐")
    print("=" * 80)

    set_random_seed(seed=seed)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"\n📱 使用设备: {device}")

    if torch.cuda.is_available():
        print(f"   GPU: {torch.cuda.get_device_name(0)}")
        torch.cuda.set_per_process_memory_fraction(0.7, device=device)
        torch.cuda.empty_cache()

    base_data_dir = "/mnt/d/python_study/ST-Mamba/data/processed/"
    save_dir = '/mnt/d/python_study/ST-Mamba/file'
    os.makedirs(save_dir, exist_ok=True)

    # 加载归一化参数
    print(f"\n📂 加载归一化参数...")
    target_city = "DC"
    target_norm_params = load_normalization_params(target_city, base_data_dir)

    # 加载数据
    print(f"\n📂 加载城市数据...")
    source_data = load_city_data("NY", base_data_dir, device)
    target_data = load_city_data("DC", base_data_dir, device)

    source_info = get_city_node_info(source_data, "NY")
    target_info = get_city_node_info(target_data, "DC")

    print(f"\n📊 城市信息:")
    print(f"   源城市 (NY): {source_info['fine_nodes']} 个有效节点")
    print(f"   目标城市 (DC): {target_info['fine_nodes']} 个有效节点")

    # ==================== 阶段1 ====================
    print("\n" + "=" * 80)
    print("🔧 阶段1: 集成模型预训练 (源城市)")
    print("=" * 80)

    stage1_config = {
        'epochs': 30,
        'learning_rate': 1e-4,
        'use_metric_loss': True,
        'metric_cycle_epochs': 7,
        'seed': seed,
    }

    integrated_model, best_mae_stage1 = pretrain_source_city_joint(
        source_data=source_data,
        device=device,
        epochs=stage1_config['epochs'],
        lrs=stage1_config['learning_rate'],
        use_metric_loss=stage1_config['use_metric_loss']
    )

    stage1_save_path = os.path.join(save_dir, 'stage1_integrated_model.pth')
    torch.save({
        'model_state': integrated_model.state_dict(),
        'best_mae': best_mae_stage1,
        'config': stage1_config,
    }, stage1_save_path)

    print(f"\n✅ 阶段1完成！最佳MAE: {best_mae_stage1:.4f}")

    # ==================== 阶段2 ====================
    print("\n" + "=" * 80)
    print("🔧 阶段2: MMD域适应训练（集成因果对齐）")
    print("=" * 80)

    source_model, target_model = prepare_models(source_info, target_info, device)
    batch_size = 16
    source_loader, target_train_loader, target_val_loader = prepare_data_loaders(
        source_data, target_data, batch_size=batch_size
    )

    stage2_config = {
        'epochs': 30,
        'batch_size': batch_size,
        'patience': 15,
        'feature_dim': 32,
        'mmd_weight': 0.3,
        'causal_weight': 0.2,  # 新增：因果对齐权重
        'metric_cycle_epochs': 10,
        'seed': seed,
    }

    trainer = MMDDomainAdaptationTrainerSimple(
        source_model=source_model,
        target_model=target_model,
        feature_dim=stage2_config['feature_dim'],
        device=device,
        mmd_weight=stage2_config['mmd_weight'],
        causal_weight=stage2_config['causal_weight'],  # 新增
        metric_cycle_epochs=stage2_config['metric_cycle_epochs'],
    )

    # 设置城市信息（用于掩码处理）
    trainer.set_city_info(source_info, target_info)

    # 训练阶段2
    history_stage2 = trainer.train(
        source_loader=source_loader,
        target_loader=target_train_loader,
        target_val_loader=target_val_loader,
        epochs=stage2_config['epochs'],
        patience=stage2_config['patience']
    )

    # 保存最终的R²最佳模型
    stage2_save_dir = os.path.join(save_dir, 'stage2_checkpoints')
    os.makedirs(stage2_save_dir, exist_ok=True)

    final_metrics = trainer.validate(target_val_loader)
    stage2_model_path = os.path.join(stage2_save_dir, 'stage2_final_model.pth')
    torch.save({
        'target_model_state': target_model.state_dict(),
        'metrics': final_metrics,
        'history': history_stage2,
        'config': stage2_config,
    }, stage2_model_path)

    print(f"\n✅ 阶段2完成！最终R²: {final_metrics['R2']:.4f}")

    # ==================== 阶段3 ====================
    print("\n" + "=" * 80)
    print("🔧 阶段3: 目标域微调")
    print("=" * 80)

    mask = target_data['mask']
    grid_h, grid_w = mask.shape
    fine_nodes = torch.where(mask.view(-1))[0].shape[0]

    train_loader, val_loader, test_loader = prepare_target_data_splits(
        target_data, train_ratio=0.7, val_ratio=0.15, batch_size=batch_size
    )

    # 创建微调模型
    finetune_model = ClusterGuidedPredictor(
        fine_nodes=fine_nodes,
        grid_size=(grid_h, grid_w),
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    )

    # 加载阶段2的模型
    finetune_model.load_state_dict(target_model.state_dict())
    finetune_model = finetune_model.to(device)

    # ✅ 简化的模型检查
    print("\n🔍 快速检查模型输出格式:")
    sample_batch = next(iter(train_loader))
    sample_input_4d = sample_batch[0].to(device)
    sample_input_3d = sample_input_4d.reshape(sample_input_4d.shape[0],
                                              sample_input_4d.shape[1],
                                              sample_input_4d.shape[2] * sample_input_4d.shape[3])

    finetune_model.eval()
    with torch.no_grad():
        outputs = finetune_model(sample_input_3d[:2])
        print("模型输出keys:", list(outputs.keys()))
        print("fine_predictions形状:", outputs['fine_predictions'].shape)
        print("coarse_predictions形状:", outputs['coarse_predictions'].shape)

    stage3_config = {
        'epochs': 30,
        'batch_size': batch_size,
        'learning_rate': 5e-5,
        'weight_decay': 1e-5,
        'patience': 15,
        'seed': seed,
    }

    finetuner = TargetDomainFinetuner(
        model=finetune_model,
        device=device,
        learning_rate=stage3_config['learning_rate'],
        weight_decay=stage3_config['weight_decay']
    )

    finetune_save_dir = os.path.join(save_dir, 'finetuned_checkpoints')
    os.makedirs(finetune_save_dir, exist_ok=True)

    # 微调训练
    history_stage3 = finetuner.train(
        train_loader=train_loader,
        val_loader=val_loader,
        epochs=stage3_config['epochs'],
        patience=stage3_config['patience'],
        save_dir=finetune_save_dir
    )

    # ==================== 最终测试（含反归一化） ====================
    print(f"\n" + "=" * 80)
    print(f"📊 最终测试集评估（反归一化到原始尺度）")
    print(f"=" * 80)

    # 最终评估 - 使用简化版函数
    print("\n📊 开始最终测试集评估...")
    test_results = evaluate_on_test_set_with_denorm(
        model=finetuner.model,
        test_loader=test_loader,
        device=device,
        norm_params=target_norm_params
    )

    print(f"\n【归一化尺度指标】[0, 1]范围:")
    print(f"  样本数: {test_results['samples_count']}")
    print(f"  MAE:  {test_results['normalized']['MAE']:.6f}")
    print(f"  RMSE: {test_results['normalized']['RMSE']:.6f}")
    print(f"  R²:   {test_results['normalized']['R2']:.6f}")

    print(f"\n【原始尺度指标】[{target_norm_params['min']:.1f}, {target_norm_params['max']:.1f}]范围:")
    print(f"  MAE:  {test_results['original']['MAE']:.4f} ⭐")
    print(f"  RMSE: {test_results['original']['RMSE']:.4f} ⭐")
    print(f"  R²:   {test_results['original']['R2']:.6f} ⭐")
    print(f"  MAPE: {test_results['original']['MAPE']:.2f}%")

    print(f"\n📈 统计信息:")
    print(f"  预测平均值: {test_results['original']['predictions_mean']:.2f}")
    print(f"  目标平均值: {test_results['original']['targets_mean']:.2f}")
    print(f"  预测标准差: {test_results['original']['predictions_std']:.2f}")
    print(f"  目标标准差: {test_results['original']['targets_std']:.2f}")

    # 绘制训练曲线
    plot_path = os.path.join(finetune_save_dir, 'training_curves.png')
    plot_training_history(history_stage3, save_path=plot_path)

    print(f"\n✅ 阶段3完成！")

    # 保存完整结果
    final_results = {
        'stage1': {
            'best_mae': best_mae_stage1,
            'config': stage1_config,
        },
        'stage2': {
            'history': history_stage2,
            'final_metrics': final_metrics,
            'config': stage2_config,
        },
        'stage3': {
            'history': history_stage3,
            'config': stage3_config,
        },
        'test_results': test_results,
        'normalization_params': target_norm_params,
        'seed': seed,
    }

    final_results_path = os.path.join(save_dir, 'improved_pipeline_results.pth')
    torch.save(final_results, final_results_path)

    print(f"\n💾 所有模型和结果已保存:")
    print(f"   阶段1: {stage1_save_path}")
    print(f"   阶段2: {stage2_save_dir}/")
    print(f"   阶段3: {finetune_save_dir}/")
    print(f"   完整结果: {final_results_path}")

    print(f"\n{'=' * 80}")
    print(f"✅ 改进版训练流程结束！")
    print(f"{'=' * 80}\n")

    return final_results


if __name__ == "__main__":
    results = complete_cross_city_training_pipeline(seed=42)