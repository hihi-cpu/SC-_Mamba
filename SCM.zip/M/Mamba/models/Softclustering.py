import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, List, Tuple
import numpy as np
import math

from models.Mam import MultiGrainMambaPredictor


class SoftCluster(nn.Module):
    """
    增强接口版本：保持核心接口兼容，但支持语义和邻接信息
    """

    def __init__(self, input_dim: int, num_clusters: int = 5, hidden_dim: Optional[int] = None,
                 redundancy_threshold: float = 0.1, use_full_metric: bool = False,
                 use_semantic_enhancement: bool = True):
        super().__init__()

        self.input_dim = input_dim
        self.num_clusters = num_clusters
        self.use_semantic_enhancement = use_semantic_enhancement

        # 设置隐藏维度
        if hidden_dim is None:
            hidden_dim = input_dim

        # 创建改进的聚类模块
        self.dynamic_cluster = TemporalDynamicSoftCluster(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            max_clusters=num_clusters,
            redundancy_threshold=redundancy_threshold,
            use_full_metric=use_full_metric
        )

        # 输出投影确保维度兼容
        self.output_proj = nn.Linear(hidden_dim, input_dim)

    def forward(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None,
                semantic_features: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        增强的前向传播接口
        H: (B, G, d) - 节点特征
        adjs: 邻接矩阵列表（用于空间约束）
        semantic_features: (B, G, s) 或 (G, s) - 语义特征（可选）
        returns: (assignments, H_coarse)
        """
        B, G, d = H.shape

        # 融合语义特征（如果提供）
        if semantic_features is not None and self.use_semantic_enhancement:
            if semantic_features.dim() == 2:  # (G, s)
                semantic_features = semantic_features.unsqueeze(0).expand(B, -1, -1)

            # 检查语义特征维度并调整
            if semantic_features.shape[1] != G:
                # 如果语义特征维度不匹配，进行插值或投影
                if semantic_features.shape[1] < G:
                    # 上采样
                    semantic_features = F.interpolate(
                        semantic_features.transpose(1, 2),
                        size=G,
                        mode='linear',
                        align_corners=False
                    ).transpose(1, 2)
                else:
                    # 下采样
                    semantic_features = semantic_features[:, :G, :]

            # 拼接语义特征
            H_enhanced = torch.cat([H, semantic_features], dim=-1)
            enhanced_dim = H_enhanced.shape[-1]

            # 动态调整聚类模块的输入维度
            if hasattr(self.dynamic_cluster.gnn_encoder[0], 'in_features'):
                if self.dynamic_cluster.gnn_encoder[0].in_features != enhanced_dim:
                    # 重新创建GNN编码器以适应新的输入维度
                    self.dynamic_cluster.gnn_encoder = nn.Sequential(
                        nn.Linear(enhanced_dim, self.dynamic_cluster.hidden_dim),
                        nn.ReLU(),
                        nn.Linear(self.dynamic_cluster.hidden_dim, self.dynamic_cluster.hidden_dim),
                        nn.LayerNorm(self.dynamic_cluster.hidden_dim)
                    ).to(H.device)
        else:
            H_enhanced = H
            enhanced_dim = d

        # 提取主要邻接矩阵（如果有）
        adj = adjs[0] if adjs and len(adjs) > 0 else None

        # 调用改进的聚类模块
        cluster_output = self.dynamic_cluster(H_enhanced, adj=adj)

        # 提取与原系统兼容的输出
        assignments = cluster_output['assignment']  # (B, G, K)
        H_coarse = cluster_output['zone_features']  # (B, K, d)

        # 确保输出维度与原系统兼容
        H_coarse = self.output_proj(H_coarse)  # (B, K, d)

        return assignments, H_coarse

    def forward_original(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None) -> Tuple[
        torch.Tensor, torch.Tensor]:
        """
        保持与原系统完全兼容的接口
        """
        return self.forward(H, adjs, semantic_features=None)

    def get_cluster_analysis(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None,
                             semantic_features: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """获取聚类分析信息"""
        adj = adjs[0] if adjs and len(adjs) > 0 else None

        # 融合语义特征
        if semantic_features is not None and self.use_semantic_enhancement:
            B, G, d = H.shape
            if semantic_features.dim() == 2:
                semantic_features = semantic_features.unsqueeze(0).expand(B, -1, -1)

            # 检查语义特征维度并调整
            if semantic_features.shape[1] != G:
                if semantic_features.shape[1] < G:
                    semantic_features = F.interpolate(
                        semantic_features.transpose(1, 2),
                        size=G,
                        mode='linear',
                        align_corners=False
                    ).transpose(1, 2)
                else:
                    semantic_features = semantic_features[:, :G, :]

            H_enhanced = torch.cat([H, semantic_features], dim=-1)
            enhanced_dim = H_enhanced.shape[-1]

            # 动态调整GNN编码器
            if hasattr(self.dynamic_cluster.gnn_encoder[0], 'in_features'):
                if self.dynamic_cluster.gnn_encoder[0].in_features != enhanced_dim:
                    self.dynamic_cluster.gnn_encoder = nn.Sequential(
                        nn.Linear(enhanced_dim, self.dynamic_cluster.hidden_dim),
                        nn.ReLU(),
                        nn.Linear(self.dynamic_cluster.hidden_dim, self.dynamic_cluster.hidden_dim),
                        nn.LayerNorm(self.dynamic_cluster.hidden_dim)
                    ).to(H.device)
        else:
            H_enhanced = H

        cluster_output = self.dynamic_cluster(H_enhanced, adj=adj)

        analysis = {
            'hard_assignment': torch.argmax(cluster_output['assignment'], dim=-1),
            'active_cluster_count': cluster_output['active_cluster_count'],
            'gate_weights': cluster_output['gate_weights'],
            'static_similarity': cluster_output['static_similarity'],
            'dynamic_similarity': cluster_output['dynamic_similarity']
        }

        return analysis

class TemporalDynamicSoftCluster(nn.Module):
    """
    改进的时间动态软聚类模块（内部实现）
    """

    def __init__(self, input_dim: int, hidden_dim: int, max_clusters: int = 100,
                 redundancy_threshold: float = 0.1, temp_init: float = 1.0,
                 use_full_metric: bool = False, device: Optional[str] = None):
        super().__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.max_clusters = int(max_clusters)
        self.redundancy_threshold = redundancy_threshold
        self.temperature = float(temp_init)
        self.use_full_metric = bool(use_full_metric)
        self.device = device

        # ==================== GNN编码器 ====================
        # 使用动态输入维度
        self.gnn_encoder = self._create_gnn_encoder(input_dim, hidden_dim)

        # ==================== 语义感知聚类中心 ====================
        # 静态语义中心（学习城市功能分区）
        self.static_centers = nn.Parameter(torch.randn(self.max_clusters, hidden_dim) * 0.1)

        # 动态语义中心（适应时空变化）
        self.dynamic_centers_init = nn.Parameter(torch.randn(self.max_clusters, hidden_dim) * 0.1)
        self.center_evolution = nn.GRUCell(hidden_dim, hidden_dim)

        # ==================== 语义门控机制 ====================
        self.semantic_gate = nn.Sequential(
            nn.Linear(hidden_dim, max(16, hidden_dim // 4)),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(max(16, hidden_dim // 4), self.max_clusters),
            nn.Sigmoid()
        )

        # ==================== 语义度量学习 ====================
        if self.use_full_metric:
            # 全语义度量矩阵
            self.semantic_metric = nn.Parameter(torch.eye(hidden_dim))
        else:
            # 对角语义度量（更高效）
            self.semantic_weights = nn.Parameter(torch.ones(hidden_dim))

        # ==================== 空间关系编码 ====================
        # 修正空间关系编码器，输入维度应该是聚类数量
        self.spatial_encoder = nn.Sequential(
            nn.Linear(self.max_clusters, hidden_dim // 2),  # 输入是聚类数量
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, hidden_dim)
        )

        # ==================== 多粒度语义输出 ====================
        self.semantic_node_proj = nn.Linear(hidden_dim, hidden_dim)
        self.semantic_zone_proj = nn.Linear(hidden_dim, hidden_dim)

        # 初始化参数
        self.reset_parameters()

    def _create_gnn_encoder(self, input_dim: int, hidden_dim: int) -> nn.Sequential:
        """创建GNN编码器"""
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )

    def reset_parameters(self):
        """初始化语义感知参数"""
        nn.init.xavier_uniform_(self.static_centers)
        nn.init.xavier_uniform_(self.dynamic_centers_init)
        if self.use_full_metric:
            nn.init.orthogonal_(self.semantic_metric)
        else:
            nn.init.ones_(self.semantic_weights)

    def compute_semantic_distance(self, features: torch.Tensor, centers: torch.Tensor) -> torch.Tensor:
        """
        语义感知距离计算
        考虑节点间的语义相似性和功能相关性
        """
        B, N, D = features.shape
        device = features.device

        if centers.dim() == 2:
            K = centers.shape[0]
            centers_b = centers.unsqueeze(0).expand(B, -1, -1).to(device)
        else:
            centers_b = centers.to(device)
            K = centers_b.shape[1]

        if not self.use_full_metric:
            # 语义加权距离
            semantic_weights = torch.sigmoid(self.semantic_weights).to(device)
            f_weighted = features * semantic_weights.view(1, 1, D)
            c_weighted = centers_b * semantic_weights.view(1, 1, D)

            # 语义感知的欧氏距离
            f_sq = (f_weighted ** 2).sum(dim=-1, keepdim=True)
            c_sq = (c_weighted ** 2).sum(dim=-1).unsqueeze(1)
            cross = torch.matmul(f_weighted, c_weighted.transpose(1, 2))
            semantic_dist = f_sq + c_sq - 2.0 * cross
        else:
            # 全语义度量距离
            M = torch.matmul(self.semantic_metric.t(), self.semantic_metric).to(device)
            xMx = torch.einsum('bnd,df,bnf->bn', features, M, features)
            cMc = torch.einsum('bkd,df,bkf->bk', centers_b, M, centers_b)
            xMc = torch.einsum('bnd,df,bkf->bnk', features, M, centers_b)
            semantic_dist = xMx.unsqueeze(-1) + cMc.unsqueeze(1) - 2.0 * xMc

        semantic_dist = torch.clamp(semantic_dist, min=0.0)
        return semantic_dist

    def compute_semantic_redundancy(self, features: torch.Tensor) -> torch.Tensor:
        """计算语义特征冗余度"""
        B, N, D = features.shape
        device = features.device

        # 语义特征归一化
        semantic_norm = F.normalize(features, p=2, dim=-1)

        # 语义相似度矩阵
        semantic_sim = torch.matmul(semantic_norm, semantic_norm.transpose(1, 2))

        # 排除自相似度
        eye = torch.eye(N, device=device, dtype=semantic_sim.dtype).unsqueeze(0)
        semantic_sim = semantic_sim * (1.0 - eye)

        # 语义冗余度
        redundancy = semantic_sim.sum(dim=(1, 2)) / (N * (N - 1) + 1e-8)

        return redundancy

    def evolve_semantic_centers(self, features: torch.Tensor,
                                prev_centers: Optional[torch.Tensor]) -> torch.Tensor:
        """
        语义中心演化
        基于当前语义特征更新动态中心
        """
        B, N, D = features.shape
        K = self.max_clusters
        device = features.device

        if prev_centers is None:
            return self.dynamic_centers_init.unsqueeze(0).expand(B, -1, -1).to(device)

        if prev_centers.dim() == 2:
            prev = prev_centers.unsqueeze(0).expand(B, -1, -1).to(device)
        else:
            prev = prev_centers.to(device)

        # 语义特征聚合
        semantic_agg = features.mean(dim=1)  # (B, D)
        semantic_agg_exp = semantic_agg.unsqueeze(1).expand(-1, K, -1).reshape(B * K, D)
        prev_flat = prev.reshape(B * K, D)

        # 语义中心演化
        updated_flat = self.center_evolution(semantic_agg_exp, prev_flat)
        updated = updated_flat.view(B, K, D)

        return updated

    def compute_semantic_assignment(self, features: torch.Tensor,
                                    centers: torch.Tensor,
                                    gate_weights: torch.Tensor) -> tuple:
        """
        语义感知的软分配计算
        """
        device = features.device

        # 静态语义相似度（长期功能相似性）
        static_centers = self.static_centers.to(device)
        static_dist = self.compute_semantic_distance(features, static_centers)
        static_sim = torch.exp(-static_dist / (self.temperature + 1e-9))

        # 动态语义相似度（短期时空相似性）
        dynamic_dist = self.compute_semantic_distance(features, centers)
        dynamic_sim = torch.exp(-dynamic_dist / (self.temperature + 1e-9))

        # 语义门控融合
        gated_dynamic = dynamic_sim * gate_weights.unsqueeze(1)

        # 双语义通道融合
        semantic_fused = 0.6 * static_sim + 0.4 * gated_dynamic

        # 语义软分配
        assignment = F.softmax(semantic_fused / (self.temperature + 1e-9), dim=-1)

        return assignment, static_sim, dynamic_sim

    def apply_semantic_constraints(self, assignment: torch.Tensor,
                                   adj: Optional[torch.Tensor]) -> torch.Tensor:
        """
        应用语义空间约束
        基于邻接关系平滑语义分配
        """
        if adj is None:
            return assignment

        device = assignment.device

        if adj.dim() == 2:
            adj_b = adj.unsqueeze(0).expand(assignment.shape[0], -1, -1).to(device)
        else:
            adj_b = adj.to(device)

        # 空间关系编码 - 修正维度处理
        # assignment形状: [B, N, K]
        B, N, K = assignment.shape

        # 重塑assignment以便通过空间编码器处理
        assignment_flat = assignment.reshape(B * N, K)
        spatial_weights_flat = self.spatial_encoder(assignment_flat)
        spatial_weights = spatial_weights_flat.reshape(B, N, -1)

        # 语义感知的图卷积
        deg = adj_b.sum(dim=-1, keepdim=True)
        adj_norm = adj_b / (deg + 1e-8)

        # 语义空间平滑
        semantic_smoothed = torch.bmm(adj_norm, assignment)
        assignment = 0.8 * assignment + 0.2 * semantic_smoothed

        return assignment

    def semantic_coarsening(self, features: torch.Tensor,
                            assignment: torch.Tensor) -> torch.Tensor:
        """
        语义特征粗化
        基于语义分配聚合特征
        """
        # 语义特征聚合
        # assignment形状: [B, N, K]
        # features形状: [B, N, D]
        semantic_clusters = torch.matmul(assignment.transpose(1, 2), features)  # [B, K, D]

        # 修正维度操作
        assign_sum = assignment.sum(dim=1, keepdim=True).transpose(1, 2)  # [B, K, 1]
        semantic_clusters = semantic_clusters / (assign_sum + 1e-8)

        return semantic_clusters

    def forward(self, x: torch.Tensor,
                adj: Optional[torch.Tensor] = None,
                prev_dynamic_centers: Optional[torch.Tensor] = None,
                time_step: int = 0) -> Dict[str, torch.Tensor]:
        """
        语义增强的前向传播
        """
        B, N, F = x.shape
        device = x.device

        # 1. 语义特征提取
        semantic_features = self.gnn_encoder(x)

        # 2. 语义中心演化
        dynamic_centers = self.evolve_semantic_centers(semantic_features, prev_dynamic_centers)

        # 3. 语义冗余度分析
        semantic_redundancy = self.compute_semantic_redundancy(semantic_features)
        semantic_ratio = 1.0 - semantic_redundancy * self.redundancy_threshold

        time_decay = 1.0 / (1.0 + 0.01 * float(time_step))
        active_ratio = semantic_ratio * time_decay
        active_count = torch.clamp(
            (active_ratio * float(self.max_clusters)).long(),
            min=3, max=self.max_clusters
        )

        # 4. 语义门控计算
        semantic_agg = semantic_features.max(dim=1)[0]
        semantic_gate = self.semantic_gate(semantic_agg)

        # 5. 语义分配计算
        assignment, static_sim, dynamic_sim = self.compute_semantic_assignment(
            semantic_features, dynamic_centers, semantic_gate
        )

        # 6. 语义空间约束
        if adj is not None:
            assignment = self.apply_semantic_constraints(assignment, adj)

        # 7. 语义特征粗化
        semantic_clusters = self.semantic_coarsening(semantic_features, assignment)

        # 多粒度语义输出
        node_semantic = self.semantic_node_proj(semantic_features)
        zone_semantic = self.semantic_zone_proj(semantic_clusters)

        # 8. 语义增强输出
        output_dict = {
            'node_features': node_semantic,
            'zone_features': zone_semantic,
            'assignment': assignment,
            'dynamic_centers': dynamic_centers,
            'gate_weights': semantic_gate,
            'active_cluster_count': active_count,
            'static_similarity': static_sim,
            'dynamic_similarity': dynamic_sim,
            'semantic_features': semantic_features,
            'semantic_redundancy': semantic_redundancy
        }

        return output_dict

class ClusterQualityTracker:
    """聚类质量跟踪器 - 修复版"""

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.assignment_histories = []
        self.prediction_losses = []
        self.quality_metrics = {
            'balance_score': [],
            'confidence_score': [],
            'coherence_score': []
        }

    def update_metrics(self, assignments: torch.Tensor, pred_loss: float, actual_clusters: int):
        """更新质量指标 - 修复版"""
        if assignments is None:
            return

        B, N, K = assignments.shape

        # 1. 平衡度得分 - 聚类大小分布
        balance_scores = []
        for b in range(B):
            cluster_sizes = assignments[b].sum(dim=0)
            if cluster_sizes.sum() > 0:
                size_dist = cluster_sizes / cluster_sizes.sum()
                entropy = -torch.sum(size_dist * torch.log(size_dist + 1e-8))
                max_entropy = math.log(K)
                balance_score = entropy / max_entropy if max_entropy > 0 else 0.0
                balance_scores.append(balance_score.item())

        balance_score = np.mean(balance_scores) if balance_scores else 0.0

        # 2. 置信度得分 - 分配置信度
        confidence_scores = []
        for b in range(B):
            max_probs = assignments[b].max(dim=1).values
            confidence_score = max_probs.mean().item()
            confidence_scores.append(confidence_score)

        confidence_score = np.mean(confidence_scores) if confidence_scores else 0.0

        # 3. 一致性得分 - 基于预测损失（反向指标，损失越小越好）
        coherence_score = 1.0 / (1.0 + pred_loss)  # 将损失转换为得分

        # 更新历史记录
        self.quality_metrics['balance_score'].append(balance_score)
        self.quality_metrics['confidence_score'].append(confidence_score)
        self.quality_metrics['coherence_score'].append(coherence_score)

        # 保持窗口大小
        for key in self.quality_metrics:
            if len(self.quality_metrics[key]) > self.window_size:
                self.quality_metrics[key] = self.quality_metrics[key][-self.window_size:]

    def get_overall_quality(self) -> float:
        """获取整体质量得分 - 修复版"""
        if not self.quality_metrics['balance_score']:
            return 0.5  # 默认中等质量

        # 计算各项得分的平均值
        balance_avg = np.mean(self.quality_metrics['balance_score'][-10:])  # 最近10个批次
        confidence_avg = np.mean(self.quality_metrics['confidence_score'][-10:])
        coherence_avg = np.mean(self.quality_metrics['coherence_score'][-10:])

        # 加权综合得分
        overall_quality = (
                0.4 * balance_avg +  # 平衡度权重40%
                0.3 * confidence_avg +  # 置信度权重30%
                0.3 * coherence_avg  # 一致性权重30%
        )

        return float(overall_quality)

    def get_optimization_advice(self) -> Dict[str, str]:
        """获取优化建议 - 修复版"""
        quality = self.get_overall_quality()

        if quality > 0.7:
            return {"focus": "maintain_quality", "weight_suggestion": "stable"}
        elif quality > 0.4:
            return {"focus": "improve_balance", "weight_suggestion": "moderate"}
        else:
            return {"focus": "enhance_clustering", "weight_suggestion": "increase"}


class JointClusterConstraint:
    """联合聚类约束 - 只计算聚类约束"""

    def __init__(self, num_clusters: int = 5,
                 spatial_weight: float = 0.01,
                 balance_weight: float = 0.01):
        self.num_clusters = num_clusters
        self.spatial_weight = spatial_weight
        self.balance_weight = balance_weight

    def compute_constraint_loss(self, assignments: torch.Tensor,
                                adj_matrix: torch.Tensor = None,
                                valid_indices: torch.Tensor = None) -> Dict[str, torch.Tensor]:
        """
        只计算聚类约束损失，不包括任何预测指标
        """
        device = assignments.device

        # 1. 空间一致性损失
        spatial_loss = self._compute_simple_spatial_loss(assignments, adj_matrix, valid_indices)
        weighted_spatial = self.spatial_weight * spatial_loss

        # 2. 平衡约束损失
        balance_loss = self._compute_simple_balance_loss(assignments)
        weighted_balance = self.balance_weight * balance_loss

        # 3. 总约束损失
        total_constraint = weighted_spatial + weighted_balance

        return {
            'total_constraint_loss': total_constraint,
            'spatial_loss': spatial_loss,
            'balance_loss': balance_loss,
            'weighted_spatial': weighted_spatial,
            'weighted_balance': weighted_balance
        }

    # _compute_simple_spatial_loss 和 _compute_simple_balance_loss 保持不变

    def _compute_simple_spatial_loss(self, assignments: torch.Tensor,
                                     adj_matrix: torch.Tensor,
                                     valid_indices: torch.Tensor = None) -> torch.Tensor:
        """
        简化的空间一致性损失
        """
        B, N, K = assignments.shape

        # 确保维度匹配
        if adj_matrix.size(0) != N:
            if valid_indices is not None and len(valid_indices) == N:
                # 如果adj_matrix是全尺寸的，需要提取有效节点
                if adj_matrix.size(0) > N:
                    adj_matrix = adj_matrix[valid_indices][:, valid_indices]
            else:
                # 不匹配，返回0损失
                return torch.tensor(0.0, device=assignments.device)

        spatial_loss = 0.0

        for b in range(min(B, 4)):  # 限制batch数量
            # 邻居分配
            neighbor_assign = torch.matmul(adj_matrix, assignments[b])

            # 一致性损失：分配应该与邻居相似
            diff = assignments[b] - neighbor_assign
            loss_b = torch.mean(torch.sum(diff ** 2, dim=1))
            spatial_loss += loss_b

        spatial_loss = spatial_loss / min(B, 4)

        # 归一化
        spatial_loss = spatial_loss / (N * K)

        return spatial_loss

    def _compute_simple_balance_loss(self, assignments: torch.Tensor) -> torch.Tensor:
        """
        简化的平衡约束损失
        """
        B, N, K = assignments.shape

        balance_loss = 0.0

        for b in range(min(B, 4)):  # 限制batch数量
            # 计算每个聚类的"质量"
            cluster_masses = assignments[b].sum(dim=0)  # [K]

            # 理想情况下每个聚类应该有 N/K 个节点
            ideal_mass = N / K

            # 平衡损失：实际质量与理想质量的差异
            imbalance = torch.abs(cluster_masses - ideal_mass)
            balance_loss += imbalance.mean() / ideal_mass  # 归一化

        balance_loss = balance_loss / min(B, 4)

        return balance_loss


class ClusterGuidedPredictor(nn.Module):
    """聚类指导的预测器 - 使用StackingEnsemble进行融合"""

    def __init__(self, fine_nodes, grid_size=(20, 23), hidden_dim=32, num_clusters=5,
                 use_metric_loss=False, metric_weights=None, use_stacking_fusion=True):
        super().__init__()

        self.fine_nodes = fine_nodes  # 有效节点数：108
        self.grid_h, self.grid_w = grid_size
        self.grid_nodes = self.grid_h * self.grid_w
        self.num_clusters = num_clusters
        self.use_metric_loss = use_metric_loss
        self.use_stacking_fusion = use_stacking_fusion

        # 指标权重
        self.metric_weights = metric_weights if metric_weights else {
            'mae': 1.0,
            'rmse': 0.3,
            'r2': 0.2
        }

        print(f"✅ 创建ClusterGuidedPredictor:")
        print(f"   有效节点数: {fine_nodes}")
        print(f"   网格大小: {grid_size}")
        print(f"   网格总数: {self.grid_nodes}")
        print(f"   聚类数: {num_clusters}")
        print(f"   使用指标损失: {use_metric_loss}")
        print(f"   使用StackingEnsemble融合: {use_stacking_fusion}")

        # 1. 聚类模块
        self.cluster = SoftCluster(
            input_dim=1,
            num_clusters=num_clusters,
            hidden_dim=hidden_dim
        )

        # 2. 预测模型
        self.predictor = MultiGrainMambaPredictor(
            fine_nodes=fine_nodes,
            coarse_nodes=num_clusters,
            hidden_dim=hidden_dim,
            state_dim=16,
            node_batch=16,
            use_fine_causal=True,
            use_coarse_causal=True
        )

        # 3. 约束模块
        self.constraint = JointClusterConstraint(num_clusters=num_clusters)

        # 4. StackingEnsemble融合模块
        if use_stacking_fusion:
            # 确保可以导入StackingEnsemble
            try:
                from models.model_utils import StackingEnsemble
                self.stacking_ensemble = StackingEnsemble(
                    num_predictors=2,  # 融合细粒度和粗粒度两个预测
                    hidden_dim=hidden_dim
                )
                print(f"   ✅ StackingEnsemble初始化成功")
            except ImportError as e:
                print(f"   ⚠️ 无法导入StackingEnsemble: {e}")
                print(f"   将回退到简单融合")
                self.use_stacking_fusion = False

        # 5. 缓存
        self.last_assignments = None
        self.last_fine_features = None

    def forward(self, flow_data, adj_matrix=None, return_cluster_info=False,
                valid_indices=None,return_causal_matrix=False):
        """
        前向传播 - 使用StackingEnsemble融合
        保持接口完全不变！
        """
        B, T, N = flow_data.shape

        # ==================== 1. 聚类 ====================
        H_fine = flow_data[:, -1:, :].transpose(1, 2)  # [B, N, 1]

        assignments, coarse_features = self.cluster(
            H_fine,
            adjs=[adj_matrix] if adj_matrix is not None else None
        )

        # 缓存聚类结果
        self.last_assignments = assignments  # [B, N, K]
        self.last_fine_features = H_fine

        # ==================== 2. 创建粗粒度流量 ====================
        coarse_flow = self._aggregate_to_coarse(flow_data, assignments)  # [B, T, K]

        # ==================== 3. 构建粗粒度邻接矩阵 ====================
        C_coarse = self._build_coarse_adjacency(assignments, adj_matrix)  # [K, K]

        # ==================== 4. 双粒度预测 ====================
        pred_fine, pred_coarse, fine_causal_matrix, coarse_causal_matrix = self.predictor(
            flow_fine=flow_data,
            flow_coarse=coarse_flow,
            C_coarse=C_coarse,
            C_fine=adj_matrix
        )

        # ==================== 5. 使用StackingEnsemble融合 ====================
        if self.use_stacking_fusion and hasattr(self, 'stacking_ensemble'):
            # 关键：必须先将粗粒度预测上采样到细粒度维度
            pred_fine = self._fuse_with_stacking(pred_fine, pred_coarse, assignments)

        # ==================== 6. 返回结果 ====================
        outputs = {
            'fine_predictions': pred_fine,  # [B, 1, N]
            'coarse_predictions': pred_coarse,  # [B, 1, K]
            'assignments': assignments,  # [B, N, K]
            'coarse_flow': coarse_flow,  # [B, T, K]
            'C_coarse': C_coarse,  # [K, K]
            'fine_causal_matrix': fine_causal_matrix,  # [N, N] - 新增
            'coarse_causal_matrix': coarse_causal_matrix,  # [K, K] - 新增
        }

        if return_cluster_info:
            outputs.update({
                'coarse_features': coarse_features,
                'clustering_quality': self._evaluate_clustering_quality(assignments),
                'fusion_used': self.use_stacking_fusion
            })

        return outputs

    def _fuse_with_stacking(self, pred_fine, pred_coarse, assignments):
        """
        使用StackingEnsemble融合预测
        步骤：
        1. 用分配矩阵将粗粒度预测上采样到细粒度维度
        2. 使用StackingEnsemble融合两个细粒度维度的预测
        """
        B, _, N = pred_fine.shape  # N = 108
        _, _, K = pred_coarse.shape  # K = 5

        # 1. 用分配矩阵上采样粗粒度预测
        # assignments: [B, N, K]
        assignments_T = assignments.transpose(1, 2)  # [B, K, N]
        pred_coarse = pred_coarse.float()  # 确保是float32
        assignments_T = assignments_T.float()  # 确保是float32

        # 上采样: [B, 1, K] @ [B, K, N] = [B, 1, N]
        pred_coarse_upsampled = torch.bmm(pred_coarse, assignments_T)

        # 2. 确保维度匹配
        assert pred_fine.shape == (B, 1, N), f"pred_fine shape error: {pred_fine.shape}"
        assert pred_coarse_upsampled.shape == (B, 1, N), f"upsampled shape error: {pred_coarse_upsampled.shape}"

        # 3. 使用StackingEnsemble融合
        # StackingEnsemble期望输入: List[Tensor]，每个Tensor是[B, 1, N]
        fused_pred = self.stacking_ensemble([pred_fine, pred_coarse_upsampled])

        # 4. 验证输出维度
        assert fused_pred.shape == (B, 1, N), f"fused_pred shape error: {fused_pred.shape}"

        return fused_pred

    # ==================== 保持原有方法完全不变 ====================

    def compute_all_metrics(self, predictions, targets):
        """计算所有评价指标"""
        pred_flat = predictions.reshape(-1)
        targ_flat = targets.reshape(-1)

        metrics = {}
        metrics['mae'] = F.l1_loss(pred_flat, targ_flat)
        metrics['mse'] = F.mse_loss(pred_flat, targ_flat)
        metrics['rmse'] = torch.sqrt(metrics['mse'] + 1e-8)

        ss_tot = torch.mean((targ_flat - torch.mean(targ_flat)) ** 2)
        metrics['r2'] = metrics['mse'] / (ss_tot + 1e-8)

        return metrics

    def compute_weighted_metric_loss(self, metrics, weights):
        """计算加权指标损失"""
        device = next(self.parameters()).device
        weighted_loss = torch.tensor(0.0, device=device)
        for metric_name, weight in weights.items():
            if metric_name in metrics and weight > 0:
                weighted_loss += weight * metrics[metric_name]
        return weighted_loss

    def compute_joint_loss(self, predictions, targets, features=None,
                           adj_matrix=None, valid_indices=None, verbose=False):
        """计算联合损失 - 完全保持原有实现"""
        device = predictions.device

        # 1. 计算所有预测指标
        metrics = self.compute_all_metrics(predictions, targets)

        # 2. 计算预测损失组件
        if self.use_metric_loss:
            weighted_metric_loss = self.compute_weighted_metric_loss(
                metrics, self.metric_weights
            )
            pred_loss_component = 0.8 * weighted_metric_loss + 0.2 * metrics['mse']
        else:
            pred_loss_component = metrics['mse']

        # 3. 获取聚类约束损失
        constraint_loss = torch.tensor(0.0, device=device)
        constraint_info = {}

        if hasattr(self, 'constraint') and self.constraint is not None:
            if self.last_assignments is not None:
                constraint_info = self.constraint.compute_constraint_loss(
                    assignments=self.last_assignments,
                    adj_matrix=adj_matrix,
                    valid_indices=valid_indices
                )
                constraint_loss = constraint_info['total_constraint_loss']

        # 4. 计算总损失
        total_loss = pred_loss_component + 0.1 * constraint_loss

        return {
            'total_loss': total_loss,
            'prediction_loss': pred_loss_component,
            'metric_loss': weighted_metric_loss if self.use_metric_loss else torch.tensor(0.0, device=device),
            'constraint_loss': constraint_loss,
            'metrics': metrics,
            'constraint_info': constraint_info
        }

    def _aggregate_to_coarse(self, flow_data, assignments):
        """将细粒度流量聚合到粗粒度"""
        B, T, N = flow_data.shape
        K = assignments.shape[-1]

        if assignments.dim() == 3:
            assignments_T = assignments.transpose(1, 2)
        else:
            assignments_T = assignments

        coarse_flow = torch.einsum('bkn,btn->btk', assignments_T, flow_data)
        return coarse_flow

    def _build_coarse_adjacency(self, assignments, fine_adj=None):
        """构建粗粒度邻接矩阵"""
        B, N, K = assignments.shape

        if fine_adj is None:
            C = torch.eye(K, device=assignments.device)
            C = C + 0.1 * (1 - torch.eye(K, device=assignments.device))
            return C

        hard_assignments = torch.argmax(assignments, dim=-1)
        cluster_ids = hard_assignments[0]

        C = torch.zeros(K, K, device=assignments.device)

        if fine_adj.dim() == 2:
            for i in range(N):
                for j in range(N):
                    if fine_adj[i, j] > 0:
                        ci = cluster_ids[i]
                        cj = cluster_ids[j]
                        C[ci, cj] += fine_adj[i, j].item()
        else:
            fine_adj_batch = fine_adj[0]
            for i in range(N):
                for j in range(N):
                    if fine_adj_batch[i, j] > 0:
                        ci = cluster_ids[i]
                        cj = cluster_ids[j]
                        C[ci, cj] += fine_adj_batch[i, j].item()

        for i in range(K):
            row_sum = C[i].sum()
            if row_sum > 0:
                C[i] = C[i] / row_sum
            else:
                C[i, i] = 1.0

        C = (C + C.T) / 2
        return C

    def _evaluate_clustering_quality(self, assignments):
        """评估聚类质量"""
        B, N, K = assignments.shape

        quality_metrics = {}

        balance_scores = []
        for b in range(B):
            cluster_sizes = assignments[b].sum(dim=0)
            if cluster_sizes.sum() > 0:
                size_dist = cluster_sizes / cluster_sizes.sum()
                entropy = -torch.sum(size_dist * torch.log(size_dist + 1e-8))
                max_entropy = torch.log(torch.tensor(K, dtype=torch.float))
                balance_score = entropy / max_entropy
                balance_scores.append(balance_score.item())

        quality_metrics['balance_score'] = np.mean(balance_scores) if balance_scores else 0.0

        confidence_scores = []
        for b in range(B):
            max_probs = assignments[b].max(dim=1).values
            confidence_scores.append(max_probs.mean().item())

        quality_metrics['confidence_score'] = np.mean(confidence_scores) if confidence_scores else 0.0

        quality_metrics['overall_quality'] = (
                0.6 * quality_metrics['balance_score'] +
                0.4 * quality_metrics['confidence_score']
        )

        return quality_metrics