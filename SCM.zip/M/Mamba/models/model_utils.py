import os
import math
import numpy as np
import torch
import torch.nn as nn
from typing import Optional, List, Tuple

from torch.utils.data import TensorDataset


class StackingEnsemble(nn.Module):
    def __init__(self, num_predictors: int = 2, hidden_dim: int = 32):
        super().__init__()
        self.ensemble_net = nn.Sequential(
            nn.Linear(num_predictors, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, predictions: List[torch.Tensor]) -> torch.Tensor:
        stacked = torch.stack(predictions, dim=-1)
        B, _, G, num_pred = stacked.shape
        stacked_flat = stacked.view(B * G, num_pred)
        final_flat = self.ensemble_net(stacked_flat)
        return final_flat.view(B, 1, G)

class CorrelationGrangerCausal:
    def __init__(self, lag: int = 2, threshold: float = 0.05,
                 use_poi: bool = True, use_spatial: bool = True,
                 alpha: float = 0.7):
        self.lag = lag
        self.threshold = threshold
        self.use_poi = use_poi
        self.use_spatial = use_spatial
        self.alpha = alpha  # Granger vs CMI权重

    def compute(self, flow_data: torch.Tensor,
                poi_data: Optional[torch.Tensor] = None,
                road_adj: Optional[torch.Tensor] = None,
                prex_adj: Optional[torch.Tensor] = None,
                poi_adj: Optional[torch.Tensor] = None,
                mask: Optional[torch.Tensor] = None,
                grid_shape: Optional[Tuple[int, int]] = None) -> torch.Tensor:
        """
        增强的多源数据因果发现
        """
        # 修复：处理不同形状的输入数据
        if flow_data.dim() == 4:  # (B, T, H, W) 形状
            B, T, H, W = flow_data.shape
            flow_flat = flow_data.reshape(B, T, H * W)  # 展平为 (B, T, K)
            K = H * W
        elif flow_data.dim() == 3:  # (B, T, K) 形状
            B, T, K = flow_data.shape
            flow_flat = flow_data
        else:
            raise ValueError(f"Unsupported flow_data shape: {flow_data.shape}")

        flow_np = flow_flat.detach().cpu().numpy()

        # 阶段1: 基础Granger因果检验
        granger_matrix = self._basic_granger_causality(flow_np, B, T, K)

        # 如果只提供流量数据，返回基础结果
        if poi_data is None and road_adj is None and poi_adj is None:
            return self._postprocess_matrix(granger_matrix)

        # 阶段2: CMI非线性因果发现
        cmi_matrix = self._cmi_causality_phase(flow_np, poi_data, B, T, K)

        # 阶段3: 多源信息融合
        combined_matrix = self._multisource_fusion(
            granger_matrix, cmi_matrix,
            road_adj, prex_adj, poi_adj,
            poi_data, mask, grid_shape
        )

        return self._postprocess_matrix(combined_matrix)

    def _basic_granger_causality(self, flow_np: np.ndarray, B: int, T: int, K: int) -> np.ndarray:
        """基础Granger因果检验，优化计算效率"""
        C = np.zeros((K, K), dtype=np.float32)

        # 限制计算数量，避免内存问题
        max_nodes = min(K, 100)  # 最多计算100个节点

        for i in range(max_nodes):
            for j in range(max_nodes):
                if i == j:
                    continue
                causality, count = 0.0, 0
                for lag_val in range(1, self.lag + 1):
                    if T > lag_val:
                        try:
                            source_lag = flow_np[:, :-lag_val, i]
                            target_current = flow_np[:, lag_val:, j]

                            # 检查数据是否有效
                            if (np.std(source_lag) > 1e-8 and
                                    np.std(target_current) > 1e-8 and
                                    not np.any(np.isnan(source_lag)) and
                                    not np.any(np.isnan(target_current))):
                                corr = self._batch_correlation(
                                    source_lag.reshape(B, -1),
                                    target_current.reshape(B, -1)
                                )
                                causality += np.mean(corr)
                                count += 1
                        except:
                            continue

                if count > 0:
                    C[i, j] = max(0.0, causality / count)

        return C

    def _cmi_causality_phase(self, flow_np: np.ndarray,
                             poi_data: Optional[torch.Tensor],
                             B: int, T: int, K: int) -> np.ndarray:
        """条件互信息CMI因果发现，优化计算"""
        if poi_data is None:
            return np.zeros((K, K), dtype=np.float32)

        # 处理POI数据的形状
        poi_np = poi_data.detach().cpu().numpy()
        if poi_np.ndim == 3:  # (H, W, P)格式
            H, W, P = poi_np.shape
            poi_np = poi_np.reshape(H * W, P)
            # 确保POI节点数与流量节点数匹配
            if poi_np.shape[0] != K:
                if poi_np.shape[0] > K:
                    poi_np = poi_np[:K, :]
                else:
                    pad_rows = K - poi_np.shape[0]
                    pad = np.zeros((pad_rows, poi_np.shape[1]))
                    poi_np = np.vstack([poi_np, pad])

        cmi_matrix = np.zeros((K, K), dtype=np.float32)

        # 限制计算数量，避免内存问题
        max_nodes = min(K, 50)

        for i in range(max_nodes):
            for j in range(max_nodes):
                if i == j:
                    continue
                if T > self.lag:
                    try:
                        source_series = flow_np[:, :-self.lag, i]
                        target_series = flow_np[:, self.lag:, j]

                        # 检查数据有效性
                        if (np.std(source_series) > 1e-8 and
                                np.std(target_series) > 1e-8 and
                                not np.any(np.isnan(source_series)) and
                                not np.any(np.isnan(target_series)) and
                                i < poi_np.shape[0] and j < poi_np.shape[0]):
                            poi_i = poi_np[i]
                            poi_j = poi_np[j]
                            poi_condition = np.concatenate([poi_i, poi_j])

                            cmi_approx = self._approximate_cmi(
                                source_series, target_series, poi_condition
                            )
                            cmi_matrix[i, j] = max(0.0, cmi_approx)
                    except Exception as e:
                        cmi_matrix[i, j] = 0.0

        return cmi_matrix

    def _approximate_cmi(self, X: np.ndarray, Y: np.ndarray, Z: np.ndarray) -> float:
        """简化的CMI近似计算，修复数值问题"""
        try:
            # 检查数据有效性
            if (np.std(X) < 1e-8 or np.std(Y) < 1e-8 or
                    np.any(np.isnan(X)) or np.any(np.isnan(Y))):
                return 0.0

            # 计算无条件相关性
            mi_xy = np.corrcoef(X.flatten(), Y.flatten())[0, 1]
            if np.isnan(mi_xy):
                mi_xy = 0.0

            # 简单的条件相关性估计
            mi_xy_z = 0.0
            count = 0

            # 按Z的不同维度计算条件相关性
            for dim in range(min(len(Z), 10)):  # 限制维度数量
                z_val = Z[dim]
                if abs(z_val) > 1e-8:  # 只处理有意义的Z值
                    # 使用Z值作为权重
                    weight = abs(z_val) / (np.sum(np.abs(Z)) + 1e-8)
                    try:
                        conditional_corr = np.corrcoef(X.flatten(), Y.flatten())[0, 1] * (1 - weight)
                        if not np.isnan(conditional_corr):
                            mi_xy_z += conditional_corr
                            count += 1
                    except:
                        continue

            if count > 0:
                mi_xy_z = mi_xy_z / count
            else:
                mi_xy_z = 0.0

            cmi_estimate = max(0, abs(mi_xy) - abs(mi_xy_z))
            return cmi_estimate

        except:
            return 0.0

    def _multisource_fusion(self, granger_matrix: np.ndarray, cmi_matrix: np.ndarray,
                            road_adj: Optional[torch.Tensor], prex_adj: Optional[torch.Tensor],
                            poi_adj: Optional[torch.Tensor], poi_data: Optional[torch.Tensor],
                            mask: Optional[torch.Tensor], grid_shape: Optional[Tuple[int, int]]) -> np.ndarray:
        """多源信息融合 - 修复形状匹配问题"""
        # 基础融合: Granger + CMI
        combined = self.alpha * granger_matrix + (1 - self.alpha) * cmi_matrix

        # 空间一致性调整
        if self.use_spatial and road_adj is not None:
            road_adj_np = road_adj.detach().cpu().numpy()

            # 确保形状匹配
            if combined.shape == road_adj_np.shape:
                combined = self._spatial_adjustment(combined, road_adj_np)
            else:
                print(
                    f"DEBUG: Skipping spatial adjustment due to shape mismatch - causal: {combined.shape}, road: {road_adj_np.shape}")
                # 可以选择使用插值或其他方法，但为了简单先跳过

        # POI语义调整
        if self.use_poi:
            if poi_adj is not None:
                poi_adj_np = poi_adj.detach().cpu().numpy()
                if combined.shape == poi_adj_np.shape:
                    combined = self._semantic_adjustment(combined, poi_adj_np)
                else:
                    print(
                        f"DEBUG: Skipping semantic adjustment due to shape mismatch - causal: {combined.shape}, poi_adj: {poi_adj_np.shape}")
            elif poi_data is not None:
                # 从POI数据计算相似度
                poi_sim = self._compute_poi_similarity(poi_data)
                if combined.shape == poi_sim.shape:
                    combined = self._semantic_adjustment(combined, poi_sim)
                else:
                    print(
                        f"DEBUG: Skipping semantic adjustment due to shape mismatch - causal: {combined.shape}, poi_sim: {poi_sim.shape}")

        return combined

    def _spatial_adjustment(self, causal_matrix: np.ndarray, road_adj: np.ndarray) -> np.ndarray:
        """基于空间邻接关系的调整"""
        # 增强空间邻近区域的因果关系
        spatial_weight = 0.3 + 0.7 * road_adj  # 基础权重 + 道路连接增强
        adjusted_matrix = causal_matrix * spatial_weight

        # 确保对角线为零
        np.fill_diagonal(adjusted_matrix, 0)
        return adjusted_matrix

    def _semantic_adjustment(self, causal_matrix: np.ndarray, poi_sim: np.ndarray) -> np.ndarray:
        """基于POI语义相似度的调整"""
        # 增强POI功能相似区域的因果关系
        semantic_weight = 0.4 + 0.6 * poi_sim  # 基础权重 + POI相似度增强
        adjusted_matrix = causal_matrix * semantic_weight
        return adjusted_matrix

    def _compute_poi_similarity(self, poi_data: torch.Tensor) -> np.ndarray:
        """计算POI相似度矩阵"""
        poi_np = poi_data.detach().cpu().numpy()
        if poi_np.ndim == 3:
            H, W, P = poi_np.shape
            poi_np = poi_np.reshape(H * W, P)

        # 归一化POI特征
        poi_norm = poi_np / (np.linalg.norm(poi_np, axis=1, keepdims=True) + 1e-8)
        # 计算余弦相似度
        similarity = poi_norm @ poi_norm.T
        return similarity

    def _postprocess_matrix(self, matrix: np.ndarray) -> torch.Tensor:
        """后处理：阈值过滤和归一化"""
        # 应用阈值
        matrix[matrix < self.threshold] = 0.0

        # 行归一化
        row_sums = matrix.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        normalized_matrix = matrix / row_sums

        return torch.from_numpy(normalized_matrix.astype(np.float32))

    def _batch_correlation(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """批量计算相关性，修复除零错误"""
        try:
            # 修复：添加更严格的数值检查
            x_std = x.std(axis=1, keepdims=True)
            y_std = y.std(axis=1, keepdims=True)

            # 修复：检查标准差是否接近零
            valid_mask = (x_std > 1e-8) & (y_std > 1e-8)

            # 初始化结果为零
            corr = np.zeros(x.shape[0])

            # 只计算有效的数据
            valid_indices = np.where(valid_mask.flatten())[0]
            if len(valid_indices) > 0:
                x_valid = x[valid_indices]
                y_valid = y[valid_indices]
                x_std_valid = x_std[valid_indices]
                y_std_valid = y_std[valid_indices]

                x_norm = (x_valid - x_valid.mean(axis=1, keepdims=True)) / x_std_valid
                y_norm = (y_valid - y_valid.mean(axis=1, keepdims=True)) / y_std_valid

                corr_valid = (x_norm * y_norm).mean(axis=1)
                corr[valid_indices] = np.clip(corr_valid, -1, 1)

            return corr

        except Exception as e:
            # 如果计算失败，返回零
            return np.zeros(x.shape[0])

def load_city_data(city_name: str, data_dir: str, device: torch.device):
    """加载单个城市的数据"""
    city_data_dir = os.path.join(data_dir, city_name)

    # 读取数据
    flow_np = np.load(os.path.join(city_data_dir, "train_x.npy"))
    target_np = np.load(os.path.join(city_data_dir, "train_y.npy"))
    poi_np = np.load(os.path.join(city_data_dir, "poi.npy"))
    time_np = np.load(os.path.join(city_data_dir, "train_t.npy"))
    poi_adj_np = np.load(os.path.join(city_data_dir, "poi_adj.npy"))
    prox_adj_np = np.load(os.path.join(city_data_dir, "prox_adj.npy"))
    road_adj_np = np.load(os.path.join(city_data_dir, "road_adj.npy"))
    mask_np = np.load(os.path.join(city_data_dir, "mask.npy"))

    # 转 torch
    flow_t = torch.from_numpy(flow_np).float()
    target_t = torch.from_numpy(target_np).float()
    poi_t = torch.from_numpy(poi_np).float()
    time_t = torch.from_numpy(time_np).float()

    # 处理掩码
    if mask_np.ndim == 3 and mask_np.shape[0] == 1:
        mask_np = mask_np[0]
    mask = torch.from_numpy(mask_np).bool().to(device)

    # 生成因果邻接矩阵
    print(f"Generating causal adjacency matrix for {city_name}...")
    causal_discoverer = CorrelationGrangerCausal(
        lag=2, threshold=0.05, use_poi=True, use_spatial=True, alpha=0.7
    )

    # 使用前几个批次的数据生成因果矩阵
    sample_flow = flow_t[:min(32, len(flow_t))]  # 使用前32个样本

    # 修复：确保传递正确的网格形状
    if mask_np.ndim == 2:
        grid_shape = (mask_np.shape[0], mask_np.shape[1])
    else:
        grid_shape = None

    causal_adj = causal_discoverer.compute(
        flow_data=sample_flow,
        poi_data=poi_t,
        road_adj=torch.from_numpy(road_adj_np).float(),
        poi_adj=torch.from_numpy(poi_adj_np).float(),
        mask=mask,
        grid_shape=grid_shape
    ).to(device)

    # 邻接矩阵字典
    adj_dict = {
        'poi_adj': torch.from_numpy(poi_adj_np).float().to(device),
        'prox_adj': torch.from_numpy(prox_adj_np).float().to(device),
        'road_adj': torch.from_numpy(road_adj_np).float().to(device),
        'causal_adj': causal_adj,  # 新增因果邻接矩阵
        'mask': mask
    }

    # 创建数据集
    def create_custom_dataset(flow_t, poi_t, time_t, target_t):
        dummy_poi = torch.zeros(1)
        poi_references = dummy_poi.expand(flow_t.shape[0], 1)
        return TensorDataset(flow_t, poi_references, time_t, target_t)

    dataset = create_custom_dataset(flow_t, poi_t, time_t, target_t)

    return {
        'dataset': dataset,
        'poi': poi_t,
        'adj_dict': adj_dict,
        'mask': mask,
        'data_shapes': {
            'flow': flow_t.shape,
            'target': target_t.shape,
            'poi': poi_t.shape
        },
        'data_dir': city_data_dir
    }
