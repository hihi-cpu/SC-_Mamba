import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
import numpy as np
import os
from typing import Dict, Tuple
from tqdm import tqdm
import copy
import matplotlib.pyplot as plt

# 需要导入模型定义
import sys

sys.path.append('/mnt/d/python_study/ST-Mamba/file')
class TargetDomainFinetuner:
    """目标域微调器"""

    def __init__(self,
                 model,
                 device: str = 'cuda:0',
                 learning_rate: float = 5e-5,
                 weight_decay: float = 1e-5):
        """
        Args:
            model: 预训练的目标域模型
            device: 训练设备
            learning_rate: 学习率（微调时使用较小学习率）
            weight_decay: 权重衰减
        """
        self.device = device
        self.model = model.to(device)

        # 损失函数 - 使用多个损失的组合
        self.mse_criterion = nn.MSELoss()
        self.mae_criterion = nn.L1Loss()
        self.smooth_l1_criterion = nn.SmoothL1Loss()

        # 优化器 - 微调时使用较小学习率
        self.optimizer = optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay,
            betas=(0.9, 0.999)
        )

        # 学习率调度器 - 余弦退火
        self.scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=10,
            T_mult=2,
            eta_min=1e-6
        )

        # 训练状态
        self.best_val_mae = float('inf')
        self.best_val_r2 = -float('inf')
        self.best_model_state = None

        # 历史记录
        self.history = {
            'train_loss': [],
            'train_mae': [],
            'train_rmse': [],
            'val_mae': [],
            'val_rmse': [],
            'val_r2': [],
            'val_loss': [],
            'learning_rate': []
        }

    def compute_r2_score(self, predictions: torch.Tensor, targets: torch.Tensor) -> float:
        """
        计算R²分数
        Args:
            predictions: 预测值 [N, D]
            targets: 真实值 [N, D]
        Returns:
            r2_score: R²分数
        """
        # 计算总平方和 (TSS)
        mean_target = targets.mean()
        tss = ((targets - mean_target) ** 2).sum()

        # 计算残差平方和 (RSS)
        rss = ((targets - predictions) ** 2).sum()

        # R² = 1 - RSS/TSS
        r2 = 1 - (rss / (tss + 1e-8))

        return r2.item()

    def train_epoch(self, train_loader: DataLoader, epoch: int) -> Dict:
        """训练一个epoch"""
        self.model.train()

        total_loss = 0.0
        all_preds = []
        all_targets = []

        pbar = tqdm(train_loader, desc=f'Epoch {epoch}')

        for batch_idx, (flow, _, _, target) in enumerate(pbar):
            # 数据准备
            if flow.dim() == 4:  # [B, T, H, W]
                flow = flow.view(flow.size(0), flow.size(1), -1)

            flow = flow.to(self.device)
            target = target.to(self.device).view(target.size(0), -1)

            # 前向传播
            outputs = self.model(flow)

            # 获取预测
            if isinstance(outputs, dict):
                predictions = outputs.get('fine_predictions')
                if predictions is None:
                    predictions = list(outputs.values())[0]
            else:
                predictions = outputs

            if predictions.dim() == 3:
                predictions = predictions.squeeze(1)

            # 确保维度匹配
            min_dim = min(predictions.size(1), target.size(1))
            predictions = predictions[:, :min_dim]
            target = target[:, :min_dim]

            # 计算复合损失 - 结合MAE, MSE和Smooth L1
            mae_loss = self.mae_criterion(predictions, target)
            mse_loss = self.mse_criterion(predictions, target)
            smooth_l1_loss = self.smooth_l1_criterion(predictions, target)

            # 加权组合
            loss = 0.4 * mae_loss + 0.3 * mse_loss + 0.3 * smooth_l1_loss

            # 反向传播
            self.optimizer.zero_grad()
            loss.backward()

            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()

            # 记录
            total_loss += loss.item()
            all_preds.append(predictions.detach().cpu())
            all_targets.append(target.detach().cpu())

            # 更新进度条
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'mae': f'{mae_loss.item():.4f}',
                'lr': f'{self.optimizer.param_groups[0]["lr"]:.2e}'
            })

        # 计算epoch统计
        avg_loss = total_loss / len(train_loader)

        all_preds = torch.cat(all_preds, dim=0)
        all_targets = torch.cat(all_targets, dim=0)

        train_mae = F.l1_loss(all_preds, all_targets).item()
        train_mse = F.mse_loss(all_preds, all_targets).item()
        train_rmse = np.sqrt(train_mse)

        return {
            'loss': avg_loss,
            'mae': train_mae,
            'rmse': train_rmse
        }

    def validate(self, val_loader: DataLoader) -> Dict:
        """验证"""
        self.model.eval()

        all_preds = []
        all_targets = []
        total_loss = 0.0

        with torch.no_grad():
            for flow, _, _, target in tqdm(val_loader, desc='验证中', leave=False):
                # 数据准备
                if flow.dim() == 4:
                    flow = flow.view(flow.size(0), flow.size(1), -1)

                flow = flow.to(self.device)
                target = target.to(self.device).view(target.size(0), -1)

                # 前向传播
                outputs = self.model(flow)

                # 获取预测
                if isinstance(outputs, dict):
                    predictions = outputs.get('fine_predictions')
                    if predictions is None:
                        predictions = list(outputs.values())[0]
                else:
                    predictions = outputs

                if predictions.dim() == 3:
                    predictions = predictions.squeeze(1)

                # 确保维度匹配
                min_dim = min(predictions.size(1), target.size(1))
                predictions = predictions[:, :min_dim]
                target = target[:, :min_dim]

                # 计算损失
                loss = self.mae_criterion(predictions, target)
                total_loss += loss.item()

                # 收集预测和目标
                all_preds.append(predictions.cpu())
                all_targets.append(target.cpu())

        # 计算指标
        all_preds = torch.cat(all_preds, dim=0)
        all_targets = torch.cat(all_targets, dim=0)

        val_mae = F.l1_loss(all_preds, all_targets).item()
        val_mse = F.mse_loss(all_preds, all_targets).item()
        val_rmse = np.sqrt(val_mse)
        val_r2 = self.compute_r2_score(all_preds, all_targets)
        avg_loss = total_loss / len(val_loader)

        return {
            'loss': avg_loss,
            'mae': val_mae,
            'rmse': val_rmse,
            'r2': val_r2
        }

    def train(self,
              train_loader: DataLoader,
              val_loader: DataLoader,
              epochs: int = 50,
              patience: int = 15,
              save_dir: str = './checkpoints') -> Dict:
        """
        完整训练流程
        Args:
            train_loader: 训练数据加载器
            val_loader: 验证数据加载器
            epochs: 训练轮次
            patience: 早停耐心值
            save_dir: 模型保存目录
        """
        os.makedirs(save_dir, exist_ok=True)

        print(f"\n{'=' * 60}")
        print(f"🚀 开始目标域微调")
        print(f"{'=' * 60}")
        print(f"训练轮次: {epochs}")
        print(f"早停耐心: {patience}")
        print(f"学习率: {self.optimizer.param_groups[0]['lr']:.2e}")
        print(f"设备: {self.device}")
        print(f"{'=' * 60}\n")

        patience_counter = 0

        for epoch in range(1, epochs + 1):
            # 训练
            train_stats = self.train_epoch(train_loader, epoch)

            # 验证
            val_stats = self.validate(val_loader)

            # 更新学习率
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]['lr']

            # 记录历史
            self.history['train_loss'].append(train_stats['loss'])
            self.history['train_mae'].append(train_stats['mae'])
            self.history['train_rmse'].append(train_stats['rmse'])
            self.history['val_loss'].append(val_stats['loss'])
            self.history['val_mae'].append(val_stats['mae'])
            self.history['val_rmse'].append(val_stats['rmse'])
            self.history['val_r2'].append(val_stats['r2'])
            self.history['learning_rate'].append(current_lr)

            # 打印统计
            print(f"\n{'=' * 60}")
            print(f"Epoch {epoch}/{epochs} 总结")
            print(f"{'=' * 60}")
            print(f"📊 训练指标:")
            print(f"   Loss: {train_stats['loss']:.6f}")
            print(f"   MAE: {train_stats['mae']:.4f}")
            print(f"   RMSE: {train_stats['rmse']:.4f}")

            print(f"\n📊 验证指标:")
            print(f"   Loss: {val_stats['loss']:.6f}")
            print(f"   MAE: {val_stats['mae']:.4f} {'✨' if val_stats['mae'] < self.best_val_mae else ''}")
            print(f"   RMSE: {val_stats['rmse']:.4f}")
            print(f"   R²: {val_stats['r2']:.4f} {'✨' if val_stats['r2'] > self.best_val_r2 else ''}")
            print(f"   学习率: {current_lr:.2e}")

            # 保存最佳模型（基于MAE）
            if val_stats['mae'] < self.best_val_mae:
                self.best_val_mae = val_stats['mae']
                self.best_val_r2 = val_stats['r2']
                self.best_model_state = copy.deepcopy(self.model.state_dict())

                # 保存检查点
                checkpoint_path = os.path.join(save_dir, 'best_finetuned_model.pth')
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': self.best_model_state,
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'scheduler_state_dict': self.scheduler.state_dict(),
                    'best_val_mae': self.best_val_mae,
                    'best_val_r2': self.best_val_r2,
                    'val_rmse': val_stats['rmse'],
                    'history': self.history
                }, checkpoint_path)

                print(f"\n✅ 保存最佳模型 (MAE: {self.best_val_mae:.4f}, R²: {self.best_val_r2:.4f})")
                patience_counter = 0
            else:
                patience_counter += 1
                print(f"\n⏳ 早停计数: {patience_counter}/{patience}")

                if patience_counter >= patience:
                    print(f"\n🛑 早停于 epoch {epoch}")
                    break

        # 恢复最佳模型
        if self.best_model_state:
            self.model.load_state_dict(self.best_model_state)
            print(f"\n✅ 已恢复最佳模型")

        # 保存最终模型
        final_checkpoint_path = os.path.join(save_dir, 'final_finetuned_model.pth')
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'best_val_mae': self.best_val_mae,
            'best_val_r2': self.best_val_r2,
            'history': self.history
        }, final_checkpoint_path)

        print(f"\n{'=' * 60}")
        print(f"🎯 微调完成!")
        print(f"{'=' * 60}")
        print(f"最佳验证MAE: {self.best_val_mae:.4f}")
        print(f"最佳验证R²: {self.best_val_r2:.4f}")
        print(f"最终验证RMSE: {min(self.history['val_rmse']):.4f}")
        print(f"{'=' * 60}\n")

        return self.history


def prepare_target_data_splits(target_data: Dict,
                               train_ratio: float = 0.7,
                               val_ratio: float = 0.15,
                               batch_size: int = 16) -> Tuple:
    """
    准备目标域的训练、验证和测试集
    Args:
        target_data: 目标域数据字典
        train_ratio: 训练集比例
        val_ratio: 验证集比例
        batch_size: 批次大小
    Returns:
        train_loader, val_loader, test_loader
    """
    dataset = target_data['dataset']
    total_size = len(dataset)

    # 计算分割大小
    train_size = int(total_size * train_ratio)
    val_size = int(total_size * val_ratio)
    test_size = total_size - train_size - val_size

    # 随机分割
    train_dataset, val_dataset, test_dataset = random_split(
        dataset,
        [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    print(f"\n📊 数据集划分:")
    print(f"   训练集: {len(train_dataset)} ({train_ratio * 100:.0f}%)")
    print(f"   验证集: {len(val_dataset)} ({val_ratio * 100:.0f}%)")
    print(f"   测试集: {len(test_dataset)} ({(1 - train_ratio - val_ratio) * 100:.0f}%)")
    print(f"   批次大小: {batch_size}")

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=2,
        pin_memory=True,
        drop_last=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    print(f"\n📊 数据加载器:")
    print(f"   训练批次数: {len(train_loader)}")
    print(f"   验证批次数: {len(val_loader)}")
    print(f"   测试批次数: {len(test_loader)}")

    return train_loader, val_loader, test_loader


def evaluate_on_test_set(model, test_loader, device='cuda:0') -> Dict:
    """
    在测试集上评估模型
    Args:
        model: 训练好的模型
        test_loader: 测试数据加载器
        device: 设备
    Returns:
        test_metrics: 测试指标字典
    """
    model.eval()
    model.to(device)

    all_preds = []
    all_targets = []

    print(f"\n{'=' * 60}")
    print(f"📊 测试集评估")
    print(f"{'=' * 60}")

    with torch.no_grad():
        for flow, _, _, target in tqdm(test_loader, desc='测试中'):
            # 数据准备
            if flow.dim() == 4:
                flow = flow.view(flow.size(0), flow.size(1), -1)

            flow = flow.to(device)
            target = target.to(device).view(target.size(0), -1)

            # 前向传播
            outputs = model(flow)

            # 获取预测
            if isinstance(outputs, dict):
                predictions = outputs.get('fine_predictions')
                if predictions is None:
                    predictions = list(outputs.values())[0]
            else:
                predictions = outputs

            if predictions.dim() == 3:
                predictions = predictions.squeeze(1)

            # 确保维度匹配
            min_dim = min(predictions.size(1), target.size(1))
            predictions = predictions[:, :min_dim]
            target = target[:, :min_dim]

            # 收集结果
            all_preds.append(predictions.cpu())
            all_targets.append(target.cpu())

    # 合并所有预测
    all_preds = torch.cat(all_preds, dim=0)
    all_targets = torch.cat(all_targets, dim=0)

    # 计算指标
    test_mae = F.l1_loss(all_preds, all_targets).item()
    test_mse = F.mse_loss(all_preds, all_targets).item()
    test_rmse = np.sqrt(test_mse)

    # 计算R²
    mean_target = all_targets.mean()
    tss = ((all_targets - mean_target) ** 2).sum()
    rss = ((all_targets - all_preds) ** 2).sum()
    test_r2 = (1 - (rss / (tss + 1e-8))).item()

    # 计算MAPE
    mape = (torch.abs((all_targets - all_preds) / (all_targets + 1e-8))).mean().item() * 100

    test_metrics = {
        'MAE': test_mae,
        'RMSE': test_rmse,
        'MSE': test_mse,
        'R2': test_r2,
        'MAPE': mape
    }

    print(f"\n📊 测试集指标:")
    print(f"   MAE:  {test_mae:.4f}")
    print(f"   RMSE: {test_rmse:.4f}")
    print(f"   MSE:  {test_mse:.6f}")
    print(f"   R²:   {test_r2:.4f}")
    print(f"   MAPE: {mape:.2f}%")
    print(f"{'=' * 60}\n")

    return test_metrics


def plot_training_history(history: Dict, save_path: str = None):
    """
    绘制训练历史
    Args:
        history: 训练历史字典
        save_path: 图片保存路径
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    epochs = range(1, len(history['train_loss']) + 1)

    # Loss曲线
    axes[0, 0].plot(epochs, history['train_loss'], 'b-', label='Train Loss', linewidth=2)
    axes[0, 0].plot(epochs, history['val_loss'], 'r-', label='Val Loss', linewidth=2)
    axes[0, 0].set_xlabel('Epoch', fontsize=12)
    axes[0, 0].set_ylabel('Loss', fontsize=12)
    axes[0, 0].set_title('Loss Curves', fontsize=14, fontweight='bold')
    axes[0, 0].legend(fontsize=10)
    axes[0, 0].grid(True, alpha=0.3)

    # MAE曲线
    axes[0, 1].plot(epochs, history['train_mae'], 'b-', label='Train MAE', linewidth=2)
    axes[0, 1].plot(epochs, history['val_mae'], 'r-', label='Val MAE', linewidth=2)
    axes[0, 1].set_xlabel('Epoch', fontsize=12)
    axes[0, 1].set_ylabel('MAE', fontsize=12)
    axes[0, 1].set_title('MAE Curves', fontsize=14, fontweight='bold')
    axes[0, 1].legend(fontsize=10)
    axes[0, 1].grid(True, alpha=0.3)

    # RMSE曲线
    axes[1, 0].plot(epochs, history['train_rmse'], 'b-', label='Train RMSE', linewidth=2)
    axes[1, 0].plot(epochs, history['val_rmse'], 'r-', label='Val RMSE', linewidth=2)
    axes[1, 0].set_xlabel('Epoch', fontsize=12)
    axes[1, 0].set_ylabel('RMSE', fontsize=12)
    axes[1, 0].set_title('RMSE Curves', fontsize=14, fontweight='bold')
    axes[1, 0].legend(fontsize=10)
    axes[1, 0].grid(True, alpha=0.3)

    # R²曲线
    axes[1, 1].plot(epochs, history['val_r2'], 'g-', label='Val R²', linewidth=2)
    axes[1, 1].set_xlabel('Epoch', fontsize=12)
    axes[1, 1].set_ylabel('R² Score', fontsize=12)
    axes[1, 1].set_title('R² Score Curve', fontsize=14, fontweight='bold')
    axes[1, 1].legend(fontsize=10)
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.3)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"📊 训练曲线已保存到: {save_path}")

    plt.show()
