import numpy as np
import os


def inspect_npy_files(data_dir="/mnt/d/python_study/ST-Mamba/data/processed/CHI/"):
    """检查 .npy 文件的信息"""
    print("=" * 60)
    print("检查 .npy 文件信息")
    print("=" * 60)

    # 要检查的文件列表
    files_to_check = [
        "max_val.npy",
        "min_val.npy",
        "train_x.npy",
        "train_y.npy",
        "mask.npy"
    ]

    for filename in files_to_check:
        file_path = os.path.join(data_dir, filename)
        if os.path.exists(file_path):
            print(f"\n📂 文件: {filename}")
            print(f"   路径: {file_path}")
            print(f"   文件大小: {os.path.getsize(file_path) / 1024:.2f} KB")

            try:
                # 加载数据
                data = np.load(file_path, allow_pickle=True)

                # 打印基本信息
                print(f"   dtype: {data.dtype}")
                print(f"   shape: {data.shape}")
                print(f"   ndim: {data.ndim}")

                # 对于小文件，打印实际内容
                if data.size <= 10:
                    print(f"   数据内容: {data}")
                    # 如果是标量数组，提取值
                    if data.shape == (1,):
                        print(f"   标量值: {data[0]}")
                        print(f"   标量类型: {type(data[0])}")

                # 对于大文件，打印统计信息
                else:
                    print(f"   min: {data.min():.4f}")
                    print(f"   max: {data.max():.4f}")
                    print(f"   mean: {data.mean():.4f}")
                    print(f"   std: {data.std():.4f}")

                # 检查是否包含元数据
                if hasattr(data, '__array_interface__'):
                    print(f"   array_interface: 是")

            except Exception as e:
                print(f"   ❌ 读取错误: {e}")
        else:
            print(f"\n❌ 文件不存在: {filename}")

    print("\n" + "=" * 60)
    print("检查完成")
    print("=" * 60)


def load_and_print_npy_details(file_path):
    """详细加载并打印 .npy 文件信息"""
    print(f"\n🔍 详细检查: {os.path.basename(file_path)}")

    if not os.path.exists(file_path):
        print(f"   文件不存在")
        return

    try:
        # 尝试不同的加载方式
        print("   尝试加载方式 1: np.load()")
        data = np.load(file_path, allow_pickle=True)
        print(f"   成功加载")
        print(f"   shape: {data.shape}")
        print(f"   dtype: {data.dtype}")

        # 如果是单个值的数组，提取它
        if data.shape == (1,) or data.size == 1:
            print(f"   这是单值数组，提取值: {data.item()}")
            scalar_value = data.item()
            print(f"   提取的值: {scalar_value}")
            print(f"   提取值类型: {type(scalar_value)}")

        # 打印原始二进制内容（前100字节）
        with open(file_path, 'rb') as f:
            first_100 = f.read(100)
            print(f"   二进制前100字节: {first_100}")

    except Exception as e:
        print(f"   加载方式1失败: {e}")

        try:
            # 尝试其他加载方式
            print("   尝试加载方式 2: np.load() with mmap_mode")
            data = np.load(file_path, allow_pickle=True, mmap_mode='r')
            print(f"   成功加载 (mmap)")
            print(f"   shape: {data.shape}")
            print(f"   dtype: {data.dtype}")
        except Exception as e2:
            print(f"   加载方式2失败: {e2}")


if __name__ == "__main__":
    # 检查多个城市的文件
    cities = ["NY", "CHI", "DC"]
    base_dir = "/mnt/d/python_study/ST-Mamba/data/processed/"

    for city in cities:
        city_dir = os.path.join(base_dir, city)
        print(f"\n{'=' * 60}")
        print(f"检查城市: {city}")
        print(f"{'=' * 60}")

        if os.path.exists(city_dir):
            inspect_npy_files(city_dir)

            # 特别检查 max_val 和 min_val
            max_val_path = os.path.join(city_dir, "max_val.npy")
            min_val_path = os.path.join(city_dir, "min_val.npy")

            if os.path.exists(max_val_path):
                load_and_print_npy_details(max_val_path)

            if os.path.exists(min_val_path):
                load_and_print_npy_details(min_val_path)
        else:
            print(f"❌ 城市目录不存在: {city_dir}")

    # 额外的调试：查看原始文件的创建方式
    print("\n" + "=" * 60)
    print("调试信息")
    print("=" * 60)

    # 创建一个测试文件来理解格式
    test_dir = "/tmp/test_npy"
    os.makedirs(test_dir, exist_ok=True)

    # 测试不同的保存方式
    test_values = [
        (100.5, "float_single"),
        (np.array([100.5]), "array_float"),
        (np.array([100]), "array_int"),
        (100, "int_single")  # 这会出错，因为np.save期望数组
    ]

    for value, name in test_values:
        try:
            file_path = os.path.join(test_dir, f"{name}.npy")
            np.save(file_path, value)
            data = np.load(file_path)
            print(f"{name}: 保存 {value} -> 加载 {data}, shape: {data.shape}, dtype: {data.dtype}")
        except Exception as e:
            print(f"{name}: 保存失败: {e}")