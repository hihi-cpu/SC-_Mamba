import torch
import numpy as np
import pandas as pd
import os
import sys
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
from sklearn.feature_extraction.text import TfidfTransformer
from typing import Tuple, Optional, Dict, List
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

try:
    from configs.config import Config

    USE_CONFIG = True
    logger.info("成功导入配置文件")
except ImportError as e:
    USE_CONFIG = False
    logger.warning(f"未找到配置文件，使用默认路径: {e}")


class TrafficDataProcessor:
    def __init__(self, base_dir: Optional[str] = None, processed_root_dir: Optional[str] = None):
        """
        初始化数据处理器
        :param base_dir: 原始数据根目录（包含NY/DC/CHI子文件夹）
        :param processed_root_dir: 处理后数据根目录（会自动创建NY/DC/CHI子文件夹）
        """
        # 原始数据根目录配置
        if USE_CONFIG and base_dir is None:
            self.base_dir = Config.RAW_DATA_DIR
        else:
            self.base_dir = Path(base_dir).absolute() if base_dir else PROJECT_ROOT / "data" / "raw"

        # 处理后数据根目录配置（重点：根目录+城市子目录）
        if USE_CONFIG and processed_root_dir is None:
            self.processed_root_dir = Config.PROCESSED_DATA_DIR
        else:
            self.processed_root_dir = Path(
                processed_root_dir).absolute() if processed_root_dir else PROJECT_ROOT / "data" / "processed"

        # 验证原始数据根目录存在（必须包含NY/DC/CHI三个城市子文件夹）
        self._validate_raw_data_dir()

        logger.info(f"数据处理器初始化完成:")
        logger.info(f"  原始数据根目录: {self.base_dir}")
        logger.info(f"  处理后数据根目录: {self.processed_root_dir}")

    def _validate_raw_data_dir(self):
        """验证原始数据根目录是否存在，且包含NY/DC/CHI三个城市子文件夹"""
        if not self.base_dir.exists():
            raise FileNotFoundError(f"原始数据根目录不存在: {self.base_dir}")

        required_cities = ['NY', 'DC', 'CHI']
        missing_cities = [city for city in required_cities if not (self.base_dir / city).exists()]
        if missing_cities:
            error_msg = f"""
原始数据根目录缺少以下城市的子文件夹: {missing_cities}
期望的原始数据目录结构:
{self.base_dir}/
├── NY/
│   ├── BikeNY_pickup.npy
│   ├── NY_poi.npy
│   ├── NY_prox_adj.npy
│   ├── NY_road_adj.npy
│   └── NY_poi_adj.npy
├── DC/
│   └── ... (同NY目录结构)
└── CHI/
    └── ... (同NY目录结构)
"""
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

    def _get_city_processed_dir(self, city: str) -> Path:
        """获取某个城市的专属处理后数据目录（自动创建）"""
        city_dir = self.processed_root_dir / city
        city_dir.mkdir(parents=True, exist_ok=True)  # 不存在则创建
        return city_dir

    def norm_adj(self, adj: np.ndarray) -> np.ndarray:
        node_num = adj.shape[0]
        adj = adj.copy()
        np.fill_diagonal(adj, 0)
        col_sum = np.sum(adj, axis=0, keepdims=True)
        adj = adj / (col_sum + 1e-6)
        np.fill_diagonal(adj, 1)
        return adj

    def min_max_normalize(self, data: np.ndarray, percentile: float = 0.999, city: str = "") -> Tuple[
        np.ndarray, float, float, float, float]:
        """
        数据归一化，返回归一化数据、截断最大值、截断最小值、实际最大值、实际最小值
        """
        data = data.copy()
        sorted_data = np.sort(data.flatten())

        # 1. 计算截断值（用于归一化）
        max_val_truncated = sorted_data[int(len(sorted_data) * percentile)]
        min_val_truncated = max(0, sorted_data[0])

        # 2. 计算实际值（用于分析）
        actual_max = data.max()
        actual_min = data.min()

        # 3. 归一化（使用截断值）
        data = np.clip(data, min_val_truncated, max_val_truncated)
        data = (data - min_val_truncated) / (max_val_truncated - min_val_truncated + 1e-8)

        logger.info(f"数据归一化完成 (城市{city}):")
        logger.info(f"  截断范围: [{min_val_truncated:.2f}, {max_val_truncated:.2f}]")
        logger.info(f"  实际范围: [{actual_min:.2f}, {actual_max:.2f}]")
        logger.info(f"  截断比例: {(actual_max - max_val_truncated) / actual_max * 100:.2f}% (仅最大值)")

        return data, max_val_truncated, min_val_truncated, actual_max, actual_min

    def extract_temporal_features(self, start_date: str = '2016-01-01',
                                  end_date: str = '2017-01-01',
                                  freq: str = 'h') -> Tuple[np.ndarray, np.ndarray]:
        time_idx = pd.date_range(start_date, end_date, freq=freq)[:-1]
        dayofweek_onehot = np.eye(7)[time_idx.dayofweek.values]
        hour_onehot = np.eye(24)[time_idx.hour.values]
        return dayofweek_onehot, hour_onehot

    def create_sequences_all_data(self, data: np.ndarray,
                                  lag: list,
                                  dayofweek: np.ndarray,
                                  hour: np.ndarray,
                                  city: str = "") -> Dict[str, np.ndarray]:
        """
        为所有数据创建序列，不划分训练集、验证集、测试集
        全部数据都放在train开头的文件中
        """
        num_samples = data.shape[0]
        train_x, train_y, train_t = [], [], []
        min_lag = -int(min(lag))

        for i in range(min_lag, num_samples):
            x_idx = [int(_ + i) for _ in lag]
            y_idx = [i]
            x_ = data[x_idx, :, :]
            y_ = data[y_idx, :, :]
            time_feat = np.concatenate([dayofweek[i], hour[i]]).reshape(1, -1)

            train_x.append(x_)
            train_y.append(y_)
            train_t.append(time_feat)

        logger.info(f"数据序列创建完成 (城市{city}): 总序列数={len(train_x)}")

        return {
            'train_x': np.stack(train_x, axis=0),
            'train_y': np.stack(train_y, axis=0),
            'train_t': np.stack(train_t, axis=0),
            'val_x': None,  # 为兼容性保留，设为None
            'val_y': None,
            'val_t': None,
            'test_x': None,  # 为兼容性保留，设为None
            'test_y': None,
            'test_t': None
        }

    def process_poi_features(self, city: str) -> Optional[np.ndarray]:
        poi_path = self.base_dir / city / f"{city}_poi.npy"
        if not poi_path.exists():
            logger.warning(f"POI文件不存在 (城市{city}): {poi_path}")
            return None
        poi = np.load(poi_path)
        lng, lat, poi_dim = poi.shape
        poi = poi.reshape(lng * lat, poi_dim)
        transformer = TfidfTransformer()
        norm_poi = np.array(transformer.fit_transform(poi).todense())
        logger.info(f"POI特征处理完成 (城市{city}): shape={norm_poi.shape}")
        return norm_poi

    def load_adjacency_matrices(self, city: str) -> Dict[str, np.ndarray]:
        adj_types = ['prox', 'road', 'poi']
        adj_dict = {}
        for adj_type in adj_types:
            adj_path = self.base_dir / city / f"{city}_{adj_type}_adj.npy"
            if not adj_path.exists():
                logger.warning(f"邻接矩阵文件不存在 (城市{city}): {adj_path}")
                continue
            adj = np.load(adj_path)
            adj_dict[f"{adj_type}_adj"] = self.norm_adj(adj)
            logger.info(f"加载邻接矩阵 (城市{city}): {adj_type}_adj, shape={adj.shape}")
        return adj_dict

    def create_mask(self, data: np.ndarray, city: str = "") -> np.ndarray:
        """创建空间掩码"""
        mask = data.sum(axis=0) > 0
        lng, lat = mask.shape
        mask = mask.reshape(1, lng, lat).astype(np.float32)  # 转为float32，统一数据类型
        logger.info(f"掩码创建完成 (城市{city}): 有效区域比例={mask.sum() / (lng * lat) * 100:.2f}%")
        return mask

    def save_single_npy(self, data: np.ndarray, city: str, filename: str):
        """保存单个npy文件到对应城市的专属文件夹"""
        city_dir = self._get_city_processed_dir(city)
        save_path = city_dir / filename
        np.save(save_path, data)
        logger.info(f"已保存: {save_path}")

    def process_single_city(self, city: str, data_type: str = 'pickup',
                            pred_lag: int = 1) -> Tuple:
        """
        处理单个城市的数据，全部数据都放在train开头的文件中
        不再划分训练集、验证集、测试集
        """
        logger.info(f"\n===== 开始处理城市: {city}, 数据类型: {data_type} =====")

        # 1. 加载原始交通数据
        data_path = self.base_dir / city / f"Bike{city}_{data_type}.npy"
        if not data_path.exists():
            raise FileNotFoundError(f"交通数据文件不存在 (城市{city}): {data_path}")
        data = np.load(data_path)
        logger.info(f"加载原始数据 (城市{city}): shape={data.shape}")

        # 2. 数据预处理流程
        norm_data, max_val_truncated, min_val_truncated, actual_max, actual_min = self.min_max_normalize(data,
                                                                                                         city=city)

        dayofweek, hour = self.extract_temporal_features()
        lag = self._get_lag_sequence(pred_lag)

        # 使用新的方法，不划分数据集
        split_data = self.create_sequences_all_data(norm_data, lag, dayofweek, hour, city=city)

        mask = self.create_mask(norm_data, city=city)
        norm_poi = self.process_poi_features(city)
        adj_dict = self.load_adjacency_matrices(city)

        # 3. 逐个保存npy文件
        # 3.1 交通流数据（全部放在train开头的文件中）
        self.save_single_npy(norm_data, city, "norm_data.npy")
        self.save_single_npy(split_data['train_x'], city, "train_x.npy")
        self.save_single_npy(split_data['train_y'], city, "train_y.npy")
        self.save_single_npy(split_data['train_t'], city, "train_t.npy")

        # 3.2 归一化参数
        # 截断值（用于反归一化）
        self.save_single_npy(np.array([max_val_truncated]), city, "max_val_truncated.npy")
        self.save_single_npy(np.array([min_val_truncated]), city, "min_val_truncated.npy")

        # 实际值（用于分析）
        self.save_single_npy(np.array([actual_max]), city, "actual_max.npy")
        self.save_single_npy(np.array([actual_min]), city, "actual_min.npy")

        # 3.3 空间掩码
        self.save_single_npy(mask, city, "mask.npy")

        # 3.4 POI特征（若存在）
        if norm_poi is not None:
            self.save_single_npy(norm_poi, city, "norm_poi.npy")

        # 3.5 邻接矩阵（逐个保存）
        for adj_name, adj_data in adj_dict.items():
            self.save_single_npy(adj_data, city, f"{adj_name}.npy")

        # 4. 创建数据集（全部数据作为训练集）
        train_dataset = TensorDataset(
            torch.Tensor(split_data['train_x']),
            torch.Tensor(split_data['train_y']),
            torch.Tensor(split_data['train_t'])
        )

        logger.info(f"城市{city}数据处理完成:")
        logger.info(f"  - 总序列数: {len(train_dataset)}")
        logger.info(f"  - 所有npy文件已保存至: {self._get_city_processed_dir(city)}")

        return (
            train_dataset,  # 全部数据作为训练集
            None,  # 无验证集
            None,  # 无测试集
            mask,
            max_val_truncated,  # 截断最大值（用于反归一化）
            min_val_truncated,  # 截断最小值（用于反归一化）
            actual_max,  # 实际最大值（用于分析）
            actual_min,  # 实际最小值（用于分析）
            norm_poi,
            adj_dict.get('prox_adj'),
            adj_dict.get('road_adj'),
            adj_dict.get('poi_adj')
        )

    def process_all_cities(self, cities: List[str] = None, data_type: str = 'pickup',
                           pred_lag: int = 1) -> Dict[str, Tuple]:
        """批量处理多个城市的数据"""
        if cities is None:
            cities = ['NY', 'DC', 'CHI']  # 默认处理三个城市
        all_results = {}
        for city in cities:
            try:
                result = self.process_single_city(city, data_type, pred_lag)
                all_results[city] = result
                logger.info(f"===== 城市 {city} 处理完成 =====")
            except Exception as e:
                logger.error(f"===== 城市 {city} 处理失败: {e} =====")
                all_results[city] = None
        return all_results

    def _get_lag_sequence(self, pred_lag: int) -> list:
        lag_dict = {
            -1: list(range(-169, -2)),
            1: [-6, -5, -4, -3, -2, -1],
            3: [-9, -8, -7, -6, -5, -4, -3, -2, -1],
            5: [-11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1]
        }
        return lag_dict.get(pred_lag, [-6, -5, -4, -3, -2, -1])

    def load_single_city_npy(self, city: str) -> Dict[str, np.ndarray]:
        """加载某个城市的所有npy文件，返回字典"""
        city_dir = self._get_city_processed_dir(city)
        data_dict = {}
        # 列出所有需要加载的文件名
        filenames = [
            "norm_data.npy", "train_x.npy", "train_y.npy", "train_t.npy",
            "max_val_truncated.npy", "min_val_truncated.npy",
            "actual_max.npy", "actual_min.npy",
            "mask.npy", "norm_poi.npy",
            "prox_adj.npy", "road_adj.npy", "poi_adj.npy"
        ]
        for filename in filenames:
            load_path = city_dir / filename
            if load_path.exists():
                data_dict[filename.replace(".npy", "")] = np.load(load_path)
                logger.info(f"已加载: {load_path}")
            else:
                logger.warning(f"文件不存在，跳过: {load_path}")
        return data_dict


# 使用示例：批量处理三个城市
if __name__ == "__main__":
    # 初始化处理器（自动识别路径）
    processor = TrafficDataProcessor()

    # 批量处理NY、DC、CHI三个城市
    all_city_results = processor.process_all_cities(
        cities=['NY', 'DC', 'CHI'],
        data_type='pickup',
        pred_lag=1
    )

    # 打印所有城市的处理结果摘要
    print("\n===== 所有城市处理结果摘要 =====")
    for city, result in all_city_results.items():
        if result is not None:
            train_dataset, _, _, _, max_val_truncated, min_val_truncated, actual_max, actual_min, _, _, _, _ = result
            print(f"城市 {city}:")
            print(f"  - 总数据量: {len(train_dataset) if train_dataset else 0} 个序列")
            print(f"  - 截断范围: [{min_val_truncated:.2f}, {max_val_truncated:.2f}]")
            print(f"  - 实际范围: [{actual_min:.2f}, {actual_max:.2f}]")
            print(f"  - 所有npy文件已保存至: {processor._get_city_processed_dir(city)}")
        else:
            print(f"城市 {city}: 处理失败")