import os
import torch.nn as nn
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
from typing import Tuple, Optional, Dict, List
from sklearn.metrics import adjusted_rand_score
from tqdm import tqdm
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import random

# 读入预先处理好的数据，主要有三种
class MultiViewClusteringDataset(Dataset):
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.load_data()

    def load_data(self):
        self.poi_features = np.load(os.path.join(self.data_dir, "norm_poi.npy"))
        # self.poi_features = self.poi_features.reshape(self.poi_features.shape[0], -1)
        self.adj1 = np.load(os.path.join(self.data_dir, "road_adj.npy"))
        self.adj2 = np.load(os.path.join(self.data_dir, "poi_adj.npy"))
        self.adj3 = np.load(os.path.join(self.data_dir, "prox_adj.npy"))
        self.num_nodes = self.poi_features.shape[0]
        self.poi_dim = self.poi_features.shape[1]

        print("聚类数据加载完成:")
        print(f"  POI特征: {self.poi_features.shape}")
        print(f"  道路邻接矩阵: {self.adj1.shape}")
        print(f"  POI相似度矩阵: {self.adj2.shape}")
        print(f"  邻近度矩阵: {self.adj3.shape}")

    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return {
            'poi_features': torch.FloatTensor(self.poi_features),
            'adj1': torch.FloatTensor(self.adj1),
            'adj2': torch.FloatTensor(self.adj2),
            'adj3': torch.FloatTensor(self.adj3),
        }

class GCNLayer(nn.Module):
    def __init__(self, in_dim, out_dim, dropout=0.1):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(out_dim)
        nn.init.xavier_uniform_(self.linear.weight)

    def forward(self, x, adj):
        x = self.dropout(x)
        x = torch.bmm(adj, x)
        x = self.linear(x)
        x = self.layer_norm(x)
        return F.relu(x)

# 利用学习三个不同的融合
class ImprovedMultiViewGNNEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, dropout: float = 0.1):
        super().__init__()

        self.gcn1 = GCNLayer(input_dim, hidden_dim, dropout)
        self.gcn2 = GCNLayer(input_dim, hidden_dim, dropout)
        self.gcn3 = GCNLayer(input_dim, hidden_dim, dropout)

        self.view_attention = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 3),
            nn.Softmax(dim=-1)
        )

        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 3, output_dim),
            nn.ReLU(),
            nn.LayerNorm(output_dim)
        )

        self.residual = nn.Linear(input_dim, output_dim)

    def forward(self, x, adj1, adj2, adj3):
        h1 = self.gcn1(x, adj1)
        h2 = self.gcn2(x, adj2)
        h3 = self.gcn3(x, adj3)

        # 视图注意力权重
        view_feat = torch.cat([h1.mean(1), h2.mean(1), h3.mean(1)], dim=-1)
        view_weights = self.view_attention(view_feat).unsqueeze(1).unsqueeze(1)

        h1 = h1 * view_weights[..., 0]
        h2 = h2 * view_weights[..., 1]
        h3 = h3 * view_weights[..., 2]

        fused = torch.cat([h1, h2, h3], dim=-1)
        return self.fusion(fused) + self.residual(x)

class ImprovedHighDimProjectionClustering(nn.Module):
    def __init__(self, input_dim, hidden_dims, output_dim, num_clusters=14):
        super().__init__()
        self.num_clusters = num_clusters
        self.output_dim = output_dim

        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([
                nn.Linear(prev, h),
                nn.BatchNorm1d(h),
                nn.LeakyReLU(0.2),
                nn.Dropout(0.1)  # 降低dropout
            ])
            prev = h
        layers.append(nn.Linear(prev, output_dim))
        self.projection = nn.Sequential(*layers)
        self.projection_norm = nn.LayerNorm(output_dim)

        # 14个聚类中心
        self.cluster_centers = nn.Parameter(torch.randn(num_clusters, output_dim))
        self.centers_initialized = False
        self.temperature = 1.5  # 提高温度，使分配更平滑
# 通过这个里面的初始化变化这里可以更好的给出初始化结果方便之后给出更正确的结果，通过让初始化的聚类中心不要太过于集中给出一个更好的聚类最终结果
    def initialize_centers(self, features):
        """使用更好的初始化策略"""
        X = features.detach().cpu().numpy()

        # 使用K-means++（更好的初始化）
        kmeans = KMeans(n_clusters=self.num_clusters, n_init=10,
                        init='k-means++', random_state=42)  # k-means++ 初始化
        kmeans.fit(X)
        labels = kmeans.labels_


        for i in range(self.num_clusters):
            if np.sum(labels == i) > 0:
                self.cluster_centers.data[i] = torch.tensor(
                    X[labels == i].mean(axis=0), device=features.device
                )
    def forward(self, features):
        B, N, D = features.shape

        proj = self.projection(features.reshape(-1, D))
        proj = self.projection_norm(proj).reshape(B, N, -1)

        self.initialize_centers(proj.reshape(-1, proj.shape[-1]))

        f_norm = F.normalize(proj, dim=-1)
        c_norm = F.normalize(self.cluster_centers, dim=-1)

        sim = torch.matmul(f_norm, c_norm.t())
        assignment = F.softmax(sim / self.temperature, dim=-1)

        coarse_features = torch.matmul(assignment.transpose(1, 2), features)
        coarse_adj = torch.matmul(assignment.transpose(1, 2), assignment)
        coarse_adj = F.normalize(coarse_adj, p=1, dim=-1)

        return {
            "assignment": assignment,
            "coarse_features": coarse_features,
            "coarse_adj": coarse_adj,
            "projected_features": proj,
            "cluster_centers": self.cluster_centers,
            "temperature": torch.tensor(self.temperature),
            "num_clusters": self.num_clusters
        }

class StableClusteringLoss(nn.Module):
    def __init__(self, compact_weight=0.5,
                 ortho_weight=0.001,
                 diversity_weight=0.01,
                 entropy_weight=0.005):
        super().__init__()
        self.compact_weight = compact_weight
        self.ortho_weight = ortho_weight
        self.diversity_weight = diversity_weight  # 进一步降低
        self.entropy_weight = entropy_weight

    def forward(self, features, A, centers, temperature):
        compact = self.compactness_loss(features, A, centers)
        ortho = self.orthogonality_loss(centers)
        diversity = self.balanced_diversity_loss(A)
        entropy = self.entropy_regularization(A)

        total = (self.compact_weight * compact +
                 self.ortho_weight * ortho +
                 self.diversity_weight * diversity +
                 self.entropy_weight * entropy)

        return total, {
            "total": total.item(),
            "compact": compact.item(),
            "ortho": ortho.item(),
            "diversity": diversity.item(),
            "entropy": entropy.item()
        }

    def balanced_diversity_loss(self, A):
        B, N, K = A.shape
        hard = A.argmax(dim=-1)

        # 计算每个聚类的节点数
        counts = torch.zeros(K, device=A.device)
        for i in range(K):
            counts[i] = (hard == i).sum()

        # 更温和的约束
        min_req = N / K * 0.2  # 从0.3降到0.2
        under = torch.relu(min_req - counts)
        util = (under ** 2).mean()  # 使用mean而不是sum

        return util  # 不乘以100
    def strong_diversity_loss(self, A):
        B, N, K = A.shape
        hard = A.argmax(dim=-1)

        # 计算每个聚类的节点数
        counts = torch.zeros(K, device=A.device)
        for i in range(K):
            counts[i] = (hard == i).sum()

        # 强力约束：每个聚类至少要有 N/K * 0.3 个节点
        min_req = N / K * 0.3
        under = torch.relu(min_req - counts)
        util = (under ** 2).sum() / N

        return util * 100  # 放大损失值
    def compactness_loss(self, features, A, centers):
        f = features.unsqueeze(2)
        c = centers.unsqueeze(0).unsqueeze(0)
        dist = ((f - c) ** 2).sum(-1)
        return (A * dist).sum() / (features.size(0) * features.size(1))

    def orthogonality_loss(self, centers):
        if centers.size(0) <= 1:
            return torch.tensor(0.0)
        nc = F.normalize(centers, dim=-1)
        corr = torch.mm(nc, nc.t())
        mask = ~torch.eye(centers.size(0), dtype=bool, device=centers.device)
        return (corr[mask] ** 2).mean()

    def entropy_regularization(self, A):
        ent = -torch.sum(A * torch.log(A + 1e-8), dim=-1)
        return ent.mean()

class ImprovedSpatialSemanticCluster(nn.Module):
    def __init__(self, poi_dim=14, gnn_hidden_dim=64, gnn_output_dim=32,
                 projection_dims=[128, 256], clustering_dim=64, num_clusters=14):
        super().__init__()
        self.gnn_encoder = ImprovedMultiViewGNNEncoder(
            input_dim=poi_dim,
            hidden_dim=gnn_hidden_dim,
            output_dim=gnn_output_dim
        )

        self.clustering_module = ImprovedHighDimProjectionClustering(
            input_dim=gnn_output_dim,
            hidden_dims=projection_dims,
            output_dim=clustering_dim,
            num_clusters=num_clusters
        )

    def forward(self, poi, adj1, adj2, adj3):
        gnn = self.gnn_encoder(poi, adj1, adj2, adj3)
        return self.clustering_module(gnn)

def save_clustering_results(assignment, features, epoch, stage, save_dir="../data/processed/DC_clustering_results"):
    """保存聚类结果到文件"""
    os.makedirs(save_dir, exist_ok=True)

    # 转换为numpy
    assignment_np = assignment.detach().cpu().numpy()[0]  # [420, K]
    features_np = features.detach().cpu().numpy()[0]  # [420, D]

    # 硬分配
    hard_assignment = np.argmax(assignment_np, axis=1)
    num_clusters = len(np.unique(hard_assignment))

    # 统计信息
    cluster_counts = np.bincount(hard_assignment)

    # 保存统计信息
    with open(os.path.join(save_dir, f"{stage}_epoch{epoch}_summary.txt"), 'w') as f:
        f.write(f"阶段: {stage}\n")
        f.write(f"轮次: {epoch}\n")
        f.write(f"聚类数量: {num_clusters}\n")
        f.write(f"各聚类节点数: {cluster_counts}\n")
        f.write(f"聚类分布: {dict(zip(range(len(cluster_counts)), cluster_counts))}\n")

    print(f" 保存{stage}第{epoch}轮聚类结果: {num_clusters}个聚类")

    return hard_assignment, cluster_counts

def train_stage1_poi_only(poi_features, model, num_epochs=100, lr=0.001):
    """阶段1：仅使用 POI 特征进行14类聚类"""

    device = next(model.parameters()).device
    # 阶段1只训练聚类模块
    optimizer = torch.optim.Adam(model.clustering_module.parameters(), lr=lr)
    criterion = StableClusteringLoss()

    print("\n" + "=" * 20)
    print("阶段1：POI-only 14类聚类")
    print("=" * 20)

    poi = poi_features.to(device).float().unsqueeze(0)

    # 直接使用POI特征，但需要映射到聚类模块的输入维度
    mapper = nn.Linear(14, 32).to(device)  # 14维POI -> 32维GNN输出

    best_loss = float('inf')
    best_k = 0
    best_state = model.state_dict()  # 初始化
    patience = 0

    for ep in range(num_epochs):
        optimizer.zero_grad()

        # 映射POI特征到正确维度
        gnn_out = mapper(poi)  # [1, 420, 32]

        result = model.clustering_module(gnn_out)

        loss, loss_dict = criterion(
            result["projected_features"],
            result["assignment"],
            result["cluster_centers"],
            result["temperature"]
        )

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        hard = result["assignment"].argmax(-1)
        k = len(torch.unique(hard))

        if ep % 5 == 0:
            print(f"[Stage1][Epoch {ep + 1}] Loss={loss.item():.4f}, K={k}, "
                  f"Compact={loss_dict['compact']:.4f}, Diversity={loss_dict['diversity']:.4f}")

        # 保存最佳模型（基于损失和聚类数）
        if loss < best_loss and k >= 12:  # 要求至少12个聚类
            best_loss = loss
            best_k = k
            best_state = model.state_dict()
            torch.save(best_state, "../models/stage1_best.pth")
            print(f" 当前Stage1最佳模型 (K={k}, Loss={loss:.4f})")
            patience = 0

        else:
            patience += 1

        if patience >= 15:  # 早停
            print(f" Stage1 早停，当前K={k}")
            break

    # 加载最佳模型
    model.load_state_dict(best_state)

    # 验证最终聚类数
    with torch.no_grad():
        gnn_out = mapper(poi)
        result = model.clustering_module(gnn_out)
        final_k = len(torch.unique(result["assignment"].argmax(-1)))

        # 🔥 保存最终结果
        hard_assignment, cluster_counts = save_clustering_results(
            result["assignment"],
            result["projected_features"],
            "final", "Stage1"
        )

    print(f"加载Stage1最佳模型，最终聚类数: {final_k}")
    print(f"最终聚类分布: {cluster_counts}")

    return model

def train_stage2_multiview(model, dataloader, num_epochs=150, lr=0.0003):
    """阶段2：多视图精调 - 使用更低的学习率"""
    device = next(model.parameters()).device
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = StableClusteringLoss()

    print("\n" + "=" * 20)
    print("阶段2：多视图精调")
    print("=" * 20)

    best_loss = float('inf')
    best_k = 0
    best_state = model.state_dict()  # 初始化！
    patience = 0

    for ep in range(num_epochs):
        epoch_loss = 0
        for batch in dataloader:
            optimizer.zero_grad()

            poi = batch["poi_features"].to(device)
            adj1 = batch["adj1"].to(device)
            adj2 = batch["adj2"].to(device)
            adj3 = batch["adj3"].to(device)

            result = model(poi, adj1, adj2, adj3)

            loss, loss_dict = criterion(result["projected_features"],
                                        result["assignment"],
                                        result["cluster_centers"],
                                        result["temperature"])

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            epoch_loss += loss.item()

        hard = result["assignment"].argmax(-1)
        k = len(torch.unique(hard))

        if ep % 5 == 0:
            print(f"[Stage2][Epoch {ep + 1}] Loss={epoch_loss:.4f}, K={k}")

        # 保存最佳模型
        if epoch_loss < best_loss and k >= 10:
            best_loss = epoch_loss
            best_k = k
            best_state = model.state_dict()
            torch.save(best_state, "./stage2_best.pth")
            print(f" 当前Stage2最佳模型 (K={k}, Loss={epoch_loss:.4f})")
            patience = 0
        else:
            patience += 1

        if patience >= 20:
            print(f" Stage2 早停，当前K={k}")
            break

    # 加载最佳模型
    model.load_state_dict(best_state)

    # 验证最终聚类数
    with torch.no_grad():
        for batch in dataloader:
            poi = batch["poi_features"].to(device)
            adj1 = batch["adj1"].to(device)
            adj2 = batch["adj2"].to(device)
            adj3 = batch["adj3"].to(device)
            result = model(poi, adj1, adj2, adj3)
            final_k = len(torch.unique(result["assignment"].argmax(-1)))

            # 🔥 保存最终结果
            hard_assignment, cluster_counts = save_clustering_results(
                result["assignment"],
                result["projected_features"],
                "final", "Stage2"
            )
            break

    print(f"加载Stage2最佳模型，最终聚类数: {final_k}")
    print(f"最终聚类分布: {cluster_counts}")

    return model

def analyze_final_results(model, dataloader, save_dir="../data/processed/CHI_clustering_results"):
    """分析最终聚类结果"""
    os.makedirs(save_dir, exist_ok=True)

    device = next(model.parameters()).device

    with torch.no_grad():
        for batch in dataloader:
            poi = batch["poi_features"].to(device)
            adj1 = batch["adj1"].to(device)
            adj2 = batch["adj2"].to(device)
            adj3 = batch["adj3"].to(device)

            result = model(poi, adj1, adj2, adj3)

            # 获取结果
            assignment = result["assignment"].cpu().numpy()[0]  # [420, K]
            features = result["projected_features"].cpu().numpy()[0]  # [420, D]
            hard_assignment = np.argmax(assignment, axis=1)

            # 保存最终聚类结果
            np.save(os.path.join(save_dir, "final_hard_assignment.npy"), hard_assignment)
            np.save(os.path.join(save_dir, "final_soft_assignment.npy"), assignment)
            np.save(os.path.join(save_dir, "final_features.npy"), features)

            # 详细分析
            cluster_counts = np.bincount(hard_assignment)
            num_clusters = len(cluster_counts)

            print(f"\n🎯 最终聚类分析:")
            print(f"聚类数量: {num_clusters}")
            print(f"聚类分布: {cluster_counts}")
            print(f"各聚类占比: {[f'{count / 460 * 100:.1f}%' for count in cluster_counts]}")

            # 保存详细报告
            with open(os.path.join(save_dir, "final_analysis_report.txt"), 'w') as f:
                f.write("最终聚类分析报告\n")
                f.write("=" * 50 + "\n")
                f.write(f"总节点数: 460\n")
                f.write(f"聚类数量: {num_clusters}\n")
                f.write(f"各聚类节点数: {cluster_counts}\n")
                f.write(f"各聚类占比: {[f'{count / 460 * 100:.1f}%' for count in cluster_counts]}\n")
                f.write("\n详细分布:\n")
                for i, count in enumerate(cluster_counts):
                    f.write(f"聚类 {i}: {count} 节点 ({count / 460 * 100:.1f}%)\n")

            break

def train_two_stage():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    dataset = MultiViewClusteringDataset("processed/CHI")
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False)

    # 创建模型，指定14个聚类
    model = ImprovedSpatialSemanticCluster(num_clusters=14).to(device)

    poi_features = torch.tensor(dataset.poi_features)

    # 阶段1：POI-only 14类聚类
    model = train_stage1_poi_only(poi_features, model)

    # 阶段2：多视图精调
    model = train_stage2_multiview(model, dataloader)

    # 🔥 分析最终结果
    analyze_final_results(model, dataloader)

    return model, dataset

def set_random_seed(seed=42):
    """固定所有随机种子"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# 在 main 函数开始调用
if __name__ == "__main__":
    set_random_seed(42)  # 🔥 添加这行
    model, dataset = train_two_stage()
    print("\n两阶段14类聚类训练完成！")