import torch
import numpy as np
import os

from sklearn.datasets.tests.test_base import test_loader
from torch_geometric.data import DataLoader

from file.Domain import get_city_node_info, prepare_models, prepare_data_loaders, MMDDomainAdaptationTrainerSimple
from file.Pretrain import pretrain_source_city_joint
from models.Softclustering import ClusterGuidedPredictor
from models.model_utils import load_city_data
from models.targetfinetune import prepare_target_data_splits, plot_training_history, TargetDomainFinetuner

import torch
import numpy as np
import os


def simple_stage1_training():
    """
    只运行第一阶段训练，查看训练过程，不保存模型
    """
    print("=" * 80)
    print("🚀 第一阶段训练 - 查看训练过程")
    print("=" * 80)

    # 1. 设置随机种子
    seed = 42
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.backends.cudnn.deterministic = True

    # 2. 设备设置
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"📱 使用设备: {device}")
    if torch.cuda.is_available():
        print(f"   GPU: {torch.cuda.get_device_name(0)}")

    # 3. 数据路径
    base_data_dir = "/mnt/d/python_study/ST-Mamba/data/processed/"

    # 4. 只加载源城市数据（不需要目标城市数据）
    print(f"\n📂 加载源城市数据...")
    source_city = "DC"
    source_data = load_city_data(source_city, base_data_dir, device)

    print(f"📊 数据统计:")
    print(f"   数据集大小: {len(source_data['dataset'])} 样本")
    print(f"   掩码形状: {source_data['mask'].shape}")

    # 5. 直接运行训练，不保存
    print(f"\n" + "=" * 80)
    print(f"🎯 开始第一阶段训练（不保存模型）")
    print("=" * 80)

    # 训练参数
    epochs = 30
    learning_rate = 1e-4

    print(f"训练配置:")
    print(f"   训练轮数: {epochs}")
    print(f"   学习率: {learning_rate}")
    print(f"   使用指标损失: True")
    print("-" * 60)

    # 直接调用你的训练函数
    # 它会打印训练过程的所有信息
    integrated_model, best_val_mae = pretrain_source_city_joint(
        source_data=source_data,
        device=device,
        epochs=epochs,
        lrs=learning_rate,
        use_metric_loss=True
    )

    print(f"\n" + "=" * 80)
    print(f"✅ 第一阶段训练完成！")
    print("=" * 80)
    print(f"📊 训练结果:")
    print(f"   最佳验证MAE: {best_val_mae:.4f}")
    print(f"   训练完成，模型未保存")

    # 6. 快速测试一下模型是否能预测
    print(f"\n🔍 快速测试模型预测...")
    if len(source_data['dataset']) > 0:
        # 取一个样本测试
        sample_batch = next(iter(DataLoader(source_data['dataset'], batch_size=2, shuffle=True)))
        flow_data = sample_batch[0].to(device)  # 假设第一个是流量数据
        target = sample_batch[2].to(device)  # 假设第三个是目标

        # 获取掩码
        mask = source_data['mask']
        grid_h, grid_w = mask.shape
        mask_flat = mask.view(-1)
        valid_indices = torch.where(mask_flat)[0]

        # 应用掩码
        B, T, H, W = flow_data.shape
        flow_flat = flow_data.view(B, T, H * W)
        flow_masked = flow_flat[:, :, valid_indices]

        # 模型预测
        integrated_model.eval()
        with torch.no_grad():
            outputs = integrated_model(flow_data=flow_masked, adj_matrix=None)
            if 'fine_predictions' in outputs:
                predictions = outputs['fine_predictions']
                print(f"   预测形状: {predictions.shape}")
                print(f"   目标形状: {target.shape}")

                # 计算这个批次的MAE
                target_masked = target.view(B, 1, H * W)[:, :, valid_indices]
                batch_mae = torch.abs(predictions - target_masked).mean().item()
                print(f"   批次MAE: {batch_mae:.4f}")

    print(f"\n" + "=" * 80)
    print(f"🎯 只查看训练完成！")
    print("=" * 80)

    return integrated_model, best_val_mae


if __name__ == "__main__":
    # 最简单调用 - 只查看训练
    print("开始运行第一阶段训练（只查看，不保存）...")
    model, best_mae = simple_stage1_training()

    print(f"\n🔚 程序结束")