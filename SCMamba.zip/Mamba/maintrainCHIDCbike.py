import torch
import numpy as np
import os
import random
from torch.utils.data import TensorDataset, DataLoader, random_split

from file.Pretrain import pretrain_source_city_joint
from file.Domain import MMDDomainAdaptationTrainerSimple, prepare_models, get_city_node_info
from models.targetfinetune import TargetDomainFinetuner, plot_training_history
from models.Softclustering import ClusterGuidedPredictor
from models.model_utils import load_city_data, CorrelationGrangerCausal


def set_random_seed(seed=42):
    """Unified setting of all random seeds to ensure experiment reproducibility"""
    print(f"Setting random seed: {seed}")

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    print(f"Random seed setup completed")


def load_normalization_params(city_name, base_data_dir):
    """Load normalization parameters for specified city"""
    city_dir = os.path.join(base_data_dir, city_name)

    max_path = os.path.join(city_dir, 'max_val.npy')
    min_path = os.path.join(city_dir, 'min_val.npy')

    if not os.path.exists(max_path) or not os.path.exists(min_path):
        raise FileNotFoundError(f"Normalization parameter files do not exist: {city_dir}")

    max_val = np.load(max_path).item()
    min_val = np.load(min_path).item()

    print(f"{city_name} normalization parameters:")
    print(f"   Maximum: {max_val}")
    print(f"   Minimum: {min_val}")
    print(f"   Range: [{min_val}, {max_val}]")

    return {'max': max_val, 'min': min_val}


def denormalize(normalized_data, norm_params):
    """Inverse normalization: restore from [0,1] to original scale"""
    max_val = norm_params['max']
    min_val = norm_params['min']

    return normalized_data * (max_val - min_val) + min_val


def calculate_metrics_original_scale_4d(predictions, targets, norm_params):
    """Calculate original scale metrics for 4D data"""
    # Ensure it's 4D
    if len(predictions.shape) != 4 or len(targets.shape) != 4:
        raise ValueError(f"Require 4D input, but got predictions: {predictions.shape}, targets: {targets.shape}")

    # Flatten to 1D
    pred_flat = predictions.reshape(-1)
    target_flat = targets.reshape(-1)

    print(f"Statistics before inverse normalization:")
    print(f"  Prediction range: [{pred_flat.min():.4f}, {pred_flat.max():.4f}]")
    print(f"  Target range: [{target_flat.min():.4f}, {target_flat.max():.4f}]")

    # Inverse normalization
    pred_original = denormalize(pred_flat, norm_params)
    target_original = denormalize(target_flat, norm_params)

    print(f"Statistics after inverse normalization:")
    print(f"  Prediction range: [{pred_original.min():.4f}, {pred_original.max():.4f}]")
    print(f"  Target range: [{target_original.min():.4f}, {target_original.max():.4f}]")

    # Convert to numpy
    pred_np = pred_original.cpu().numpy() if torch.is_tensor(pred_original) else pred_original
    target_np = target_original.cpu().numpy() if torch.is_tensor(target_original) else target_original

    # Calculate metrics
    mae = np.mean(np.abs(pred_np - target_np))
    rmse = np.sqrt(np.mean((pred_np - target_np) ** 2))

    ss_res = np.sum((target_np - pred_np) ** 2)
    ss_tot = np.sum((target_np - np.mean(target_np)) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    mask = target_np != 0
    if np.any(mask):
        mape = np.mean(np.abs((target_np[mask] - pred_np[mask]) / target_np[mask])) * 100
    else:
        mape = 0

    return {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'MAPE': mape,
        'predictions_count': len(pred_np),
        'predictions_mean': float(np.mean(pred_np)),
        'targets_mean': float(np.mean(target_np)),
        'predictions_std': float(np.std(pred_np)),
        'targets_std': float(np.std(target_np))
    }


def evaluate_on_test_set_with_denorm(model, test_loader, device, norm_params):
    """Simplified evaluation function - directly extract fine_predictions"""
    model.eval()
    all_preds_4d = []  # Store 4D predictions [B, 1, H, W]
    all_targets_4d = []  # Store 4D targets [B, 1, H, W]

    print("Starting test set evaluation...")
    print("Directly extracting 'fine_predictions' - this is already fused results")

    with torch.no_grad():
        for batch_idx, batch in enumerate(test_loader):
            # Parse batch
            flow_data_4d = batch[0].to(device)  # [B, 6, H, W]
            target_4d = batch[3].to(device)  # [B, 1, H, W]

            # Get grid dimensions
            B, T_in, H, W = flow_data_4d.shape

            # Convert input format: [B, 6, H, W] -> [B, 6, H*W]
            flow_data_3d = flow_data_4d.reshape(B, T_in, H * W)

            # Model prediction
            outputs = model(flow_data_3d)  # Returns dictionary

            # ✅ Directly extract fine_predictions - this is already fused results
            y_pred_3d = outputs['fine_predictions']  # [B, 1, N]

            # Convert back to 4D: [B, 1, N] -> [B, 1, H, W]
            y_pred_4d = y_pred_3d.reshape(B, 1, H, W)

            # Add to list
            all_preds_4d.append(y_pred_4d)
            all_targets_4d.append(target_4d)

            if (batch_idx + 1) % 20 == 0:
                print(f"  Processing batch {batch_idx + 1}/{len(test_loader)}")

    # Combine all batches
    all_preds = torch.cat(all_preds_4d, dim=0)
    all_targets = torch.cat(all_targets_4d, dim=0)

    print(f"\nFinal shapes:")
    print(f"  Predictions: {all_preds.shape}")
    print(f"  Targets: {all_targets.shape}")

    # Calculate normalized scale metrics
    pred_norm = all_preds.cpu().numpy().reshape(-1)
    target_norm = all_targets.cpu().numpy().reshape(-1)

    mae_norm = np.mean(np.abs(pred_norm - target_norm))
    rmse_norm = np.sqrt(np.mean((pred_norm - target_norm) ** 2))
    ss_res = np.sum((target_norm - pred_norm) ** 2)
    ss_tot = np.sum((target_norm - np.mean(target_norm)) ** 2)
    r2_norm = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    # Original scale metrics
    metrics_original = calculate_metrics_original_scale_4d(all_preds, all_targets, norm_params)

    return {
        'normalized': {
            'MAE': mae_norm,
            'RMSE': rmse_norm,
            'R2': r2_norm,
        },
        'original': metrics_original,
        'predictions_shape': all_preds.shape,
        'targets_shape': all_targets.shape,
        'samples_count': len(pred_norm)
    }


def load_target_data_with_partial(city_name, data_dir, device, use_percentage=0.5):
    """Modified version: only load the last 50% of target domain data"""
    city_data_dir = os.path.join(data_dir, city_name)

    # Read data
    flow_np = np.load(os.path.join(city_data_dir, "train_x.npy"))
    target_np = np.load(os.path.join(city_data_dir, "train_y.npy"))
    poi_np = np.load(os.path.join(city_data_dir, "poi.npy"))
    time_np = np.load(os.path.join(city_data_dir, "train_t.npy"))
    poi_adj_np = np.load(os.path.join(city_data_dir, "poi_adj.npy"))
    prox_adj_np = np.load(os.path.join(city_data_dir, "prox_adj.npy"))
    road_adj_np = np.load(os.path.join(city_data_dir, "road_adj.npy"))
    mask_np = np.load(os.path.join(city_data_dir, "mask.npy"))

    # Calculate amount of data to use
    total_samples = len(flow_np)
    use_samples = int(total_samples * use_percentage)
    start_idx = total_samples - use_samples  # Start from the end

    print(f"Target domain data usage strategy:")
    print(f"   Total samples: {total_samples}")
    print(f"   Usage percentage: {use_percentage * 100}%")
    print(f"   Samples to use: {use_samples}")
    print(f"   Start index: {start_idx} (using last {use_percentage * 100}% of data)")
    print(f"   End index: {total_samples - 1}")

    # Only take the last 50% of data
    flow_np = flow_np[start_idx:]
    target_np = target_np[start_idx:]
    time_np = time_np[start_idx:]

    # Convert to torch
    flow_t = torch.from_numpy(flow_np).float()
    target_t = torch.from_numpy(target_np).float()
    poi_t = torch.from_numpy(poi_np).float()
    time_t = torch.from_numpy(time_np).float()

    # Process mask
    if mask_np.ndim == 3 and mask_np.shape[0] == 1:
        mask_np = mask_np[0]
    mask = torch.from_numpy(mask_np).bool().to(device)

    # Generate causal adjacency matrix
    print(f"Generating causal adjacency matrix for {city_name}...")
    causal_discoverer = CorrelationGrangerCausal(
        lag=2, threshold=0.05, use_poi=True, use_spatial=True, alpha=0.7
    )

    # Use partial data to generate causal matrix
    sample_flow = flow_t[:min(32, len(flow_t))]

    # Fix: Ensure correct grid shape is passed
    if mask_np.ndim == 2:
        grid_shape = (mask_np.shape[0], mask_np.shape[1])
    else:
        grid_shape = None

    causal_adj = causal_discoverer.compute(
        flow_data=sample_flow,
        poi_data=poi_t,
        road_adj=torch.from_numpy(road_adj_np).float(),
        poi_adj=torch.from_numpy(poi_adj_np).float(),
        mask=mask,
        grid_shape=grid_shape
    ).to(device)

    # Adjacency matrix dictionary
    adj_dict = {
        'poi_adj': torch.from_numpy(poi_adj_np).float().to(device),
        'prox_adj': torch.from_numpy(prox_adj_np).float().to(device),
        'road_adj': torch.from_numpy(road_adj_np).float().to(device),
        'causal_adj': causal_adj,
        'mask': mask
    }

    # Create dataset
    def create_custom_dataset(flow_t, poi_t, time_t, target_t):
        dummy_poi = torch.zeros(1)
        poi_references = dummy_poi.expand(flow_t.shape[0], 1)
        return TensorDataset(flow_t, poi_references, time_t, target_t)

    dataset = create_custom_dataset(flow_t, poi_t, time_t, target_t)

    return {
        'dataset': dataset,
        'poi': poi_t,
        'adj_dict': adj_dict,
        'mask': mask,
        'data_shapes': {
            'flow': flow_t.shape,
            'target': target_t.shape,
            'poi': poi_t.shape
        },
        'data_dir': city_data_dir,
        'start_idx': start_idx,
        'use_samples': use_samples
    }


def complete_cross_city_training_pipeline(seed=42):
    """
    Complete cross-city training pipeline (source city: CHI, target city: DC)
    All models saved to CHIDCbike folder
    """
    print("=" * 80)
    print("Complete cross-city training pipeline (CHI → DC transfer)")
    print("=" * 80)
    print("Training configuration:")
    print("   Source city: CHI (Chicago)")
    print("   Target city: DC (Washington DC)")
    print("   Target domain data strategy: Only use last 50% of data")
    print("   Model save: CHIDCbike folder")
    print("=" * 80)

    set_random_seed(seed=seed)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    if torch.cuda.is_available():
        print(f"   GPU: {torch.cuda.get_device_name(0)}")
        torch.cuda.set_per_process_memory_fraction(0.7, device=device)
        torch.cuda.empty_cache()

    base_data_dir = "/home/zc/ST-Mamba/data/processed/"

    # ========== Key modification: Create dedicated save folder ==========
    experiment_name = "CHIDCbike"
    save_dir = f'/home/zc/ST-Mamba/{experiment_name}'
    os.makedirs(save_dir, exist_ok=True)

    print(f"Experiment name: {experiment_name}")
    print(f"Model save directory: {save_dir}")

    # Load normalization parameters
    print(f"Loading normalization parameters...")
    source_city = "CHI"
    target_city = "DC"

    # Load normalization parameters for both source and target cities
    source_norm_params = load_normalization_params(source_city, base_data_dir)
    target_norm_params = load_normalization_params(target_city, base_data_dir)

    # Load data
    print(f"Loading source city data ({source_city})...")
    source_data = load_city_data(source_city, base_data_dir, device)

    # Modify here: Target domain only loads last 50% of data
    print(f"Loading target domain data ({target_city}, last 50% only)...")
    target_data = load_target_data_with_partial(target_city, base_data_dir, device, use_percentage=0.5)

    source_info = get_city_node_info(source_data, source_city)
    target_info = get_city_node_info(target_data, target_city)

    print(f"City information:")
    print(f"   Source city ({source_city}): {source_info['fine_nodes']} valid nodes")
    print(f"   Target city ({target_city}): {target_info['fine_nodes']} valid nodes")

    # ============ Key modification: Unified data split ============
    print(f"\n" + "=" * 80)
    print("Unified data split strategy")
    print("=" * 80)

    dataset = target_data['dataset']  # This is the last 50% data
    total_samples = len(dataset)

    # Split within the last 50% data
    split_point = total_samples // 2  # Midpoint
    train_indices = range(0, split_point)  # First half (for training)
    test_indices = range(split_point, total_samples)  # Second half (for final testing)

    print(f"   Total samples ({target_city} last 50%): {total_samples}")
    print(f"   Training set ({target_city} middle 25%): {split_point} samples")
    print(f"   Test set ({target_city} last 25%): {total_samples - split_point} samples")

    # Create datasets
    train_dataset = torch.utils.data.Subset(dataset, train_indices)
    test_dataset = torch.utils.data.Subset(dataset, test_indices)

    # ==================== Phase 1 ====================
    print("\n" + "=" * 80)
    print(f"Phase 1: Integrated model pre-training (source city: {source_city})")
    print("=" * 80)

    stage1_config = {
        'epochs': 30,
        'learning_rate': 1e-4,
        'use_metric_loss': True,
        'metric_cycle_epochs': 7,
        'seed': seed,
        'source_city': source_city,
        'target_city': target_city,
    }

    integrated_model, best_mae_stage1 = pretrain_source_city_joint(
        source_data=source_data,
        device=device,
        epochs=stage1_config['epochs'],
        lrs=stage1_config['learning_rate'],
        use_metric_loss=stage1_config['use_metric_loss']
    )

    # ========== Key modification: Save to CHIDCbike folder ==========
    stage1_save_path = os.path.join(save_dir, f'stage1_{source_city}_{target_city}_simple.pth')
    torch.save(integrated_model.state_dict(), stage1_save_path)

    print(f"Phase 1 completed! Best MAE: {best_mae_stage1:.4f}")
    print(f"Model saved to: {stage1_save_path}")

    # ==================== Phase 2 ====================
    print("\n" + "=" * 80)
    print(f"Phase 2: MMD domain adaptation training ({source_city} → {target_city})")
    print("=" * 80)

    source_model, target_model = prepare_models(
        source_info,
        target_info,
        device,
        pretrained_path=stage1_save_path  # Pass correct path
    )
    batch_size = 16

    print(f"Phase 2 data usage:")
    print(f"   Source domain: All {source_city} data ({len(source_data['dataset'])} samples)")
    print(f"   Target domain: First half of {target_city} last 50% ({len(train_dataset)} samples)")

    # Split training set into training and validation sets
    train_size = len(train_dataset)
    val_size = max(1, train_size // 5)  # 20% as validation set
    real_train_size = train_size - val_size

    # Random split training and validation sets
    train_subset, val_subset = random_split(
        train_dataset,
        [real_train_size, val_size],
        generator=torch.Generator().manual_seed(seed)
    )

    print(f"     → Training set: {real_train_size} samples")
    print(f"     → Validation set: {val_size} samples")

    # Create data loaders
    source_loader = DataLoader(source_data['dataset'], batch_size=batch_size, shuffle=True)
    target_train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True)
    target_val_loader = DataLoader(val_subset, batch_size=batch_size, shuffle=False)

    stage2_config = {
        'epochs': 30,
        'batch_size': batch_size,
        'patience': 15,
        'feature_dim': 32,
        'mmd_weight': 0.3,
        'causal_weight': 0.2,
        'metric_cycle_epochs': 10,
        'seed': seed,
        'source_city': source_city,
        'target_city': target_city,
    }

    trainer = MMDDomainAdaptationTrainerSimple(
        source_model=source_model,
        target_model=target_model,
        feature_dim=stage2_config['feature_dim'],
        device=device,
        mmd_weight=stage2_config['mmd_weight'],
        causal_weight=stage2_config['causal_weight'],
        metric_cycle_epochs=stage2_config['metric_cycle_epochs'],
    )

    # Set city information (for mask processing)
    trainer.set_city_info(source_info, target_info)

    # Train phase 2
    history_stage2 = trainer.train(
        source_loader=source_loader,
        target_loader=target_train_loader,
        target_val_loader=target_val_loader,
        epochs=stage2_config['epochs'],
        patience=stage2_config['patience']
    )

    # ========== Key modification: Save to CHIDCbike folder ==========
    stage2_save_dir = os.path.join(save_dir, 'stage2_checkpoints')
    os.makedirs(stage2_save_dir, exist_ok=True)

    final_metrics = trainer.validate(target_val_loader)
    stage2_model_path = os.path.join(stage2_save_dir, f'stage2_{source_city}_{target_city}_final_model.pth')
    torch.save({
        'target_model_state': target_model.state_dict(),
        'metrics': final_metrics,
        'history': history_stage2,
        'config': stage2_config,
        'source_city': source_city,
        'target_city': target_city,
    }, stage2_model_path)

    print(f"Phase 2 completed! Final R²: {final_metrics['R2']:.4f}")
    print(f"Model saved to: {stage2_model_path}")

    # ==================== Phase 3 ====================
    print("\n" + "=" * 80)
    print(f"Phase 3: Target domain fine-tuning ({target_city})")
    print("=" * 80)

    mask = target_data['mask']
    grid_h, grid_w = mask.shape
    fine_nodes = torch.where(mask.view(-1))[0].shape[0]

    print(f"Phase 3 data usage:")
    print(f"   Training set: {real_train_size} samples (same as phase 2)")
    print(f"   Validation set: {val_size} samples (same as phase 2)")
    print(f"   Test set: {len(test_dataset)} samples (completely new data, not used in any phase)")

    # Phase 3 uses same training data as phase 2
    finetune_train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True)
    finetune_val_loader = DataLoader(val_subset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # Create fine-tuning model
    finetune_model = ClusterGuidedPredictor(
        fine_nodes=fine_nodes,
        grid_size=(grid_h, grid_w),
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    )

    # Load phase 2 model
    finetune_model.load_state_dict(target_model.state_dict())
    finetune_model = finetune_model.to(device)

    # Simplified model check
    print("Quick check model output format:")
    sample_batch = next(iter(finetune_train_loader))
    sample_input_4d = sample_batch[0].to(device)
    sample_input_3d = sample_input_4d.reshape(sample_input_4d.shape[0],
                                              sample_input_4d.shape[1],
                                              sample_input_4d.shape[2] * sample_input_4d.shape[3])

    finetune_model.eval()
    with torch.no_grad():
        outputs = finetune_model(sample_input_3d[:2])
        print("Model output keys:", list(outputs.keys()))
        print("fine_predictions shape:", outputs['fine_predictions'].shape)
        print("coarse_predictions shape:", outputs['coarse_predictions'].shape)

    stage3_config = {
        'epochs': 30,
        'batch_size': batch_size,
        'learning_rate': 5e-5,
        'weight_decay': 1e-5,
        'patience': 15,
        'seed': seed,
        'source_city': source_city,
        'target_city': target_city,
    }

    finetuner = TargetDomainFinetuner(
        model=finetune_model,
        device=device,
        learning_rate=stage3_config['learning_rate'],
        weight_decay=stage3_config['weight_decay']
    )

    # ========== Key modification: Save to CHIDCbike folder ==========
    finetune_save_dir = os.path.join(save_dir, 'finetuned_checkpoints')
    os.makedirs(finetune_save_dir, exist_ok=True)

    # Fine-tune training (use same training/validation data as phase 2)
    history_stage3 = finetuner.train(
        train_loader=finetune_train_loader,
        val_loader=finetune_val_loader,
        epochs=stage3_config['epochs'],
        patience=stage3_config['patience'],
        save_dir=finetune_save_dir
    )

    # ==================== Final test (with inverse normalization) ====================
    print(f"\n" + "=" * 80)
    print(f"Final test set evaluation (inverse normalization to original scale)")
    print("=" * 80)
    print(f"Important: Test set is the last 25% of target domain original data")
    print(f"Ensure model has never seen this data in any phase")
    print("=" * 80)

    # Final evaluation
    print("Starting final test set evaluation...")
    test_results = evaluate_on_test_set_with_denorm(
        model=finetuner.model,
        test_loader=test_loader,
        device=device,
        norm_params=target_norm_params
    )

    print(f"\n【Normalized scale metrics】[0, 1] range:")
    print(f"  Sample count: {test_results['samples_count']}")
    print(f"  MAE:  {test_results['normalized']['MAE']:.6f}")
    print(f"  RMSE: {test_results['normalized']['RMSE']:.6f}")
    print(f"  R²:   {test_results['normalized']['R2']:.6f}")

    print(f"\n【Original scale metrics】[{target_norm_params['min']:.1f}, {target_norm_params['max']:.1f}] range:")
    print(f"  MAE:  {test_results['original']['MAE']:.4f}")
    print(f"  RMSE: {test_results['original']['RMSE']:.4f}")
    print(f"  R²:   {test_results['original']['R2']:.6f}")
    print(f"  MAPE: {test_results['original']['MAPE']:.2f}%")

    print(f"\nStatistical information:")
    print(f"  Prediction mean: {test_results['original']['predictions_mean']:.2f}")
    print(f"  Target mean: {test_results['original']['targets_mean']:.2f}")
    print(f"  Prediction std: {test_results['original']['predictions_std']:.2f}")
    print(f"  Target std: {test_results['original']['targets_std']:.2f}")

    # Plot training curves
    plot_path = os.path.join(finetune_save_dir, f'training_curves_{source_city}_{target_city}.png')
    plot_training_history(history_stage3, save_path=plot_path)

    print(f"\nPhase 3 completed!")

    # Save complete results
    final_results = {
        'experiment_name': experiment_name,
        'stage1': {
            'best_mae': best_mae_stage1,
            'config': stage1_config,
        },
        'stage2': {
            'history': history_stage2,
            'final_metrics': final_metrics,
            'config': stage2_config,
        },
        'stage3': {
            'history': history_stage3,
            'config': stage3_config,
        },
        'test_results': test_results,
        'normalization_params': {
            'source': source_norm_params,
            'target': target_norm_params
        },
        'seed': seed,
        'cities': {
            'source': source_city,
            'target': target_city,
        },
        'data_strategy': {
            'target_original_samples': len(source_data['dataset']),
            # Assume source and target domains have same original data amount
            'target_used_percentage': 0.5,
            'target_used_samples': total_samples,
            'train_samples': split_point,
            'test_samples': total_samples - split_point,
            'train_val_split': f'{real_train_size}/{val_size}',
            'test_data_note': f'Last 25% of {target_city} original data, ensuring no data leakage'
        }
    }

    # ========== Key modification: Save to CHIDCbike folder ==========
    final_results_path = os.path.join(save_dir, f'complete_results_{source_city}_{target_city}.pth')
    torch.save(final_results, final_results_path)

    # Also save a JSON version for easier viewing
    import json
    json_results_path = os.path.join(save_dir, f'complete_results_{source_city}_{target_city}.json')

    # Convert tensor to Python basic types
    def convert_to_serializable(obj):
        if isinstance(obj, (np.integer, np.floating)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, torch.Tensor):
            return obj.cpu().numpy().tolist()
        elif isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        else:
            return obj

    serializable_results = convert_to_serializable(final_results)
    with open(json_results_path, 'w') as f:
        json.dump(serializable_results, f, indent=2, ensure_ascii=False)

    print(f"\nAll models and results saved to {experiment_name} folder:")
    print(f"   Phase 1 model: {stage1_save_path}")
    print(f"   Phase 2 model: {stage2_model_path}")
    print(f"   Phase 3 model: {finetune_save_dir}/")
    print(f"   Complete results (PTH): {final_results_path}")
    print(f"   Complete results (JSON): {json_results_path}")

    print(f"\n{'=' * 80}")
    print(f"Improved training pipeline completed!")
    print(f"Data usage summary:")
    print(f"   Source domain ({source_city}): 100% data used for training")
    print(f"   Target domain ({target_city}):")
    print(f"     - First 50%: Not used")
    print(f"     - Middle 25%: Used for domain adaptation and fine-tuning training")
    print(f"     - Last 25%: Used for final testing (completely new data)")
    print(f"Experiment name: {experiment_name}")
    print(f"Model save location: {save_dir}")
    print(f"{'=' * 80}\n")

    return final_results


def load_chidc_model(checkpoint_path, device):
    """
    Load trained model from CHIDCbike folder
    """
    print(f"Loading model from {checkpoint_path}...")

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Model file does not exist: {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=device)

    # Create corresponding model based on model type
    if 'target_model_state' in checkpoint:
        # Phase 2 model
        model_state = checkpoint['target_model_state']
        config = checkpoint.get('config', {})
        source_city = config.get('source_city', 'CHI')
        target_city = config.get('target_city', 'DC')

        print(f"Loading phase 2 model: {source_city} → {target_city}")

        # Need to create model based on actual model structure
        # Example code, adjust according to actual situation
        mask = torch.ones((10, 10)).bool()  # Example mask, need to replace with actual value
        grid_h, grid_w = mask.shape
        fine_nodes = torch.where(mask.view(-1))[0].shape[0]

        model = ClusterGuidedPredictor(
            fine_nodes=fine_nodes,
            grid_size=(grid_h, grid_w),
            hidden_dim=32,
            num_clusters=5,
            use_metric_loss=True,
            use_stacking_fusion=True
        )

        model.load_state_dict(model_state)
        model.to(device)

        return {
            'model': model,
            'checkpoint': checkpoint,
            'type': 'stage2',
            'source_city': source_city,
            'target_city': target_city
        }

    elif 'model_state' in checkpoint:
        # Phase 1 model
        model_state = checkpoint['model_state']
        config = checkpoint.get('config', {})
        source_city = config.get('source_city', 'CHI')
        target_city = config.get('target_city', 'DC')

        print(f"Loading phase 1 model: {source_city}")
        # Need to create model based on actual model structure
        # Adjust according to actual situation

        return {
            'model': None,  # Need to implement based on actual situation
            'checkpoint': checkpoint,
            'type': 'stage1',
            'source_city': source_city,
            'target_city': target_city
        }

    else:
        # Might be result file
        print("Loading result file")
        return {
            'checkpoint': checkpoint,
            'type': 'results'
        }


if __name__ == "__main__":
    # Run complete training pipeline
    print("Starting complete cross-city training pipeline (CHI → DC)...")
    results = complete_cross_city_training_pipeline(seed=42)

    if results and 'test_results' in results:
        test_results = results['test_results']
        print(f"\nFinal test results:")
        print(f"   Original scale MAE: {test_results['original']['MAE']:.4f}")
        print(f"   Original scale RMSE: {test_results['original']['RMSE']:.4f}")
        print(f"   Original scale R²: {test_results['original']['R2']:.6f}")

    print(f"Program completed")