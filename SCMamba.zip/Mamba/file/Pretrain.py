import os
from torch.utils.data import DataLoader
from models.Softclustering import ClusterGuidedPredictor
import torch.nn.functional as F
from sklearn.metrics import r2_score
import random
import numpy as np
import torch

def set_deterministic(seed=42):
    """Set fully deterministic environment"""
    # 1. Python random seed
    random.seed(seed)

    # 2. Numpy random seed
    np.random.seed(seed)

    # 3. PyTorch random seed
    torch.manual_seed(seed)

    # 4. CUDA random seed
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

        # Fully deterministic CUDA operations
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

        # Set environment variables
        os.environ['PYTHONHASHSEED'] = str(seed)
        os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'

        # PyTorch 1.8+ deterministic algorithms
        torch.use_deterministic_algorithms(True)

    print(f"Deterministic mode enabled (seed={seed})")


def apply_mask_to_batch(flow, target, mask, device):
    """Apply mask to batch"""
    B, T, H, W = flow.shape
    grid_nodes = H * W

    # Flatten
    flow_flat = flow.view(B, T, grid_nodes)
    mask_flat = mask.view(grid_nodes)
    valid_indices = torch.where(mask_flat)[0]
    fine_nodes = len(valid_indices)

    # Apply mask
    flow_masked = flow_flat[:, :, valid_indices]

    if target.dim() == 4:
        target_flat = target.view(B, 1, grid_nodes)
        target_masked = target_flat[:, :, valid_indices]
    else:
        target_masked = target

    return flow_masked, target_masked, valid_indices, fine_nodes


def validate_integrated_model(model, val_loader, source_data, device, mask):
    """Validate integrated model"""
    model.eval()
    all_predictions = []
    all_targets = []

    # Prepare valid node indices in advance
    grid_h, grid_w = mask.shape
    grid_nodes = grid_h * grid_w
    mask_flat = mask.view(grid_nodes)
    valid_indices = torch.where(mask_flat)[0]
    fine_nodes = len(valid_indices)

    # Get adjacency matrix (pre-processed)
    adj_matrix = None
    if 'poi_adj' in source_data['adj_dict']:
        adj_full = source_data['adj_dict']['poi_adj']
        if adj_full.shape[0] == grid_nodes:
            adj_matrix = adj_full[valid_indices][:, valid_indices]

    with torch.no_grad():
        for flow, poi, time_feat, target in val_loader:
            flow, target = flow.to(device), target.to(device)

            # Apply mask (simplified version)
            B, T, H, W = flow.shape
            flow_flat = flow.view(B, T, grid_nodes)
            flow_masked = flow_flat[:, :, valid_indices]

            if target.dim() == 4:
                target_flat = target.view(B, 1, grid_nodes)
                target_masked = target_flat[:, :, valid_indices]
            else:
                target_masked = target

            # Forward pass
            outputs = model(
                flow_data=flow_masked,
                adj_matrix=adj_matrix,
                return_causal_matrix=True  # New parameter
            )
            predictions = outputs['fine_predictions']

            # Ensure dimensions match
            min_len = min(predictions.shape[2], target_masked.shape[2])
            predictions = predictions[:, :, :min_len]
            target_masked = target_masked[:, :, :min_len]

            all_predictions.append(predictions.cpu())
            all_targets.append(target_masked.cpu())

    model.train()

    # Calculate metrics
    if all_predictions:
        all_predictions = torch.cat(all_predictions, dim=0)
        all_targets = torch.cat(all_targets, dim=0)

        mae = F.l1_loss(all_predictions, all_targets).item()
        mse = F.mse_loss(all_predictions, all_targets).item()
        rmse = np.sqrt(mse)

        # Calculate R² (fixed: using sklearn's r2_score)
        pred_np = all_predictions.numpy()
        target_np = all_targets.numpy()
        r2 = r2_score(target_np.flatten(), pred_np.flatten())

        return {'MAE': mae, 'RMSE': rmse, 'R2': r2}
    else:
        return {'MAE': float('inf'), 'RMSE': float('inf'), 'R2': -float('inf')}


def pretrain_source_city_joint(source_data, device,
                               epochs=20, lrs=1e-5, use_metric_loss=True):
    """Pretrain source city model - using phased metric weight optimization"""

    # Prepare source domain data
    source_dataset = source_data['dataset']
    source_train_size = int(0.8 * len(source_dataset))
    source_val_size = len(source_dataset) - source_train_size
    source_train_dataset, source_val_dataset = torch.utils.data.random_split(
        source_dataset, [source_train_size, source_val_size]
    )

    source_train_loader = DataLoader(source_train_dataset, batch_size=32, shuffle=True)
    source_val_loader = DataLoader(source_val_dataset, batch_size=32, shuffle=False)

    best_val_mae = float('inf')
    patience = 15
    patience_counter = 0
    mask = source_data['mask']

    # Get grid information
    grid_h, grid_w = mask.shape
    grid_nodes = grid_h * grid_w
    mask_flat = mask.view(grid_nodes)
    valid_indices = torch.where(mask_flat)[0]
    fine_nodes = len(valid_indices)

    print(f"Grid info: Size({grid_h}x{grid_w})={grid_nodes}, Valid nodes={fine_nodes}")

    # Create integrated predictor (initial weights)
    integrated_predictor = ClusterGuidedPredictor(
        fine_nodes=fine_nodes,
        grid_size=(grid_h, grid_w),
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=use_metric_loss,
        metric_weights={
            'mae': 1.0,
            'rmse': 0.0,
            'r2': 0.0
        }
    ).to(device)

    # Optimizer
    integrated_optimizer = torch.optim.Adam(
        integrated_predictor.parameters(),
        lr=lrs,
        weight_decay=1e-5
    )

    # Learning rate scheduler
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        integrated_optimizer,
        mode='min',
        factor=0.5,
        patience=2
    )

    # Gradient scaler
    scaler = torch.amp.GradScaler('cuda')

    print(f"\nStarting integrated model pretraining (Use metric loss: {use_metric_loss})")
    print(f"   Training data: {len(source_train_dataset)} samples")
    print(f"   Validation data: {len(source_val_dataset)} samples")
    print(f"   Using metric loss: {use_metric_loss}")

    # Define phased weights
    phase_weights = [
        {'mae': 0.7, 'rmse': 0.1, 'r2': 0.0},  # Phase 1: Balanced start
        {'mae': 0.7, 'rmse': 0.1, 'r2': 0.2},  # Phase 2: Focus on R²
        {'mae': 0.6, 'rmse': 0.2, 'r2': 0.3},  # Phase 3: Mainly optimize R²
        {'mae': 0.1, 'rmse': 0.1, 'r2': 0.8}   # Phase 4: Almost only focus on R²
    ]

    for epoch in range(epochs):
        # Determine current phase
        if epoch < epochs // 2:
            current_weights = phase_weights[0]
            phase_name = "Phase 1: MAE Focus"
            phase_start = 1
            phase_end = epochs // 2
        elif epoch < 4*epochs // 6:
            current_weights = phase_weights[1]
            phase_name = "Phase 2: MAE+RMSE"
            phase_start = epochs // 2 + 1
            phase_end = 4*epochs // 6
        elif epoch < 5*epochs // 5:
            current_weights = phase_weights[2]
            phase_name = "Phase 3: Balanced Optimization"
            phase_start = 4*epochs // 6
            phase_end = 5*epochs // 6
        else:
            current_weights = phase_weights[3]
            phase_name = "Phase 4: R² Focus"
            phase_start = 5*epochs // 6
            phase_end = epochs

        # Update model weights
        if use_metric_loss:
            integrated_predictor.metric_weights = current_weights

            # Only print once at the beginning of each phase
            if epoch == 0 or epoch == epochs // 4 or epoch == epochs // 2 or epoch == 3 * epochs // 4:
                print(f"\n{'=' * 60}")
                print(f"Entering {phase_name}")
                print(f"   Weight configuration: MAE={current_weights['mae']}, "
                      f"RMSE={current_weights['rmse']}, R²={current_weights['r2']}")
                print(f"   Time range: Epoch {phase_start}-{phase_end}")
                print(f"{'=' * 60}")

        # Print current phase information each epoch
        print(f"\nEpoch {epoch + 1}/{epochs} [{phase_name}]")
        print(f"   Current weights: MAE={current_weights['mae']}, "
              f"RMSE={current_weights['rmse']}, R²={current_weights['r2']}")

        integrated_predictor.train()

        epoch_train_losses = {
            'total_loss': 0.0,
            'prediction_loss': 0.0,
            'metric_loss': 0.0,
            'cluster_constraint_loss': 0.0,
            'mae': 0.0,
            'rmse': 0.0,
            'r2': 0.0
        }
        num_batches = 0

        # Training phase
        for batch_idx, (flow, poi, time_feat, target) in enumerate(source_train_loader):
            flow, target = flow.to(device), target.to(device)

            # Apply mask
            flow_masked, target_masked, batch_valid_indices, batch_fine_nodes = apply_mask_to_batch(
                flow, target, mask, device
            )

            # Prepare adjacency matrix
            adj_matrix = None
            if 'poi_adj' in source_data['adj_dict']:
                adj_full = source_data['adj_dict']['poi_adj']
                if adj_full.shape[0] == grid_nodes:
                    adj_matrix = adj_full[batch_valid_indices][:, batch_valid_indices].to(device)

            # Forward pass
            with torch.amp.autocast('cuda', enabled=True):
                integrated_outputs = integrated_predictor(
                    flow_data=flow_masked,
                    adj_matrix=adj_matrix,
                    return_cluster_info=True,
                    valid_indices=batch_valid_indices,
                    return_causal_matrix=True  # New parameter
                )
                integrated_pred = integrated_outputs['fine_predictions']

                # Only use ClusterGuidedPredictor's compute_joint_loss method
                integrated_loss_dict = integrated_predictor.compute_joint_loss(
                    predictions=integrated_pred,
                    targets=target_masked,
                    adj_matrix=adj_matrix,
                    valid_indices=batch_valid_indices,
                )

                total_loss = integrated_loss_dict['total_loss']

            # Backward pass
            integrated_optimizer.zero_grad()
            scaler.scale(total_loss).backward()

            # Gradient clipping
            scaler.unscale_(integrated_optimizer)
            torch.nn.utils.clip_grad_norm_(integrated_predictor.parameters(), max_norm=1.0)

            scaler.step(integrated_optimizer)
            scaler.update()

            # Accumulate losses
            epoch_train_losses['total_loss'] += total_loss.item()
            epoch_train_losses['prediction_loss'] += integrated_loss_dict['prediction_loss'].item()

            if use_metric_loss and 'metric_loss' in integrated_loss_dict:
                epoch_train_losses['metric_loss'] += integrated_loss_dict['metric_loss'].item()

            if 'cluster_constraint_loss' in integrated_loss_dict:
                epoch_train_losses['cluster_constraint_loss'] += integrated_loss_dict['cluster_constraint_loss'].item()

            # Accumulate metric values
            if 'metrics' in integrated_loss_dict:
                metrics = integrated_loss_dict['metrics']
                epoch_train_losses['mae'] += metrics['mae'].item()
                epoch_train_losses['rmse'] += metrics['rmse'].item()
                epoch_train_losses['r2'] += metrics['r2'].item()

            num_batches += 1

            # Output every 50 batches
            if batch_idx % 50 == 0 and batch_idx > 0:
                avg_loss = epoch_train_losses['total_loss'] / num_batches
                print(f'  Batch {batch_idx}: Average total loss={avg_loss:.6f}')
                if use_metric_loss:
                    avg_mae = epoch_train_losses['mae'] / num_batches
                    avg_rmse = epoch_train_losses['rmse'] / num_batches
                    avg_r2 = epoch_train_losses['r2'] / num_batches
                    print(f'          Training MAE={avg_mae:.4f}, RMSE={avg_rmse:.4f}, R² loss={avg_r2:.4f}')

        # Validation phase
        if num_batches > 0:
            avg_train_losses = {key: value / num_batches for key, value in epoch_train_losses.items()}
        else:
            avg_train_losses = epoch_train_losses

        # Validation
        val_metrics = validate_integrated_model(
            integrated_predictor, source_val_loader, source_data, device, mask
        )

        val_mae = val_metrics['MAE']
        val_rmse = val_metrics['RMSE']
        val_r2 = val_metrics['R2']

        # Update learning rate
        scheduler.step(val_mae)

        # Print training information
        print(f'\n Epoch {epoch + 1}/{epochs}:')
        print(f'   Training total loss: {avg_train_losses["total_loss"]:.6f}')

        if use_metric_loss:
            print(f'   Metric loss: {avg_train_losses["metric_loss"]:.6f}')
            print(f'   Training metrics: MAE={avg_train_losses["mae"]:.4f}, '
                  f'RMSE={avg_train_losses["rmse"]:.4f}, R² loss={avg_train_losses["r2"]:.4f}')

        print(f'   Prediction loss: {avg_train_losses["prediction_loss"]:.6f}')
        print(f'   Cluster constraint loss: {avg_train_losses["cluster_constraint_loss"]:.6f}')

        print(f'   Validation metrics: VAL_MAE={val_mae:.4f}, VAL_RMSE={val_rmse:.4f}, VAL_R²={val_r2:.4f}')
        print(f'   Current learning rate: {integrated_optimizer.param_groups[0]["lr"]:.2e}')

        # Early stopping and model saving
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            torch.save(integrated_predictor.state_dict(), 'pretrained_integrated_model.pth')
            print(f"    Saved best model (MAE: {val_mae:.4f})")
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"    Should early stop at epoch {epoch + 1}")
                break
                # break
            else:
                print(f"    Early stopping counter: {patience_counter}/{patience}")

    print(f"\nFirst phase completed! Best validation MAE: {best_val_mae:.4f}")

    # Return integrated model
    return integrated_predictor, best_val_mae