import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from typing import Dict, Tuple
import copy
import os
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm
from models.Softclustering import ClusterGuidedPredictor


class MMDLoss(nn.Module):
    def __init__(self, kernel_type='rbf', kernel_mul=2.0, kernel_num=5):
        super().__init__()
        self.kernel_mul = kernel_mul
        self.kernel_num = kernel_num

    def forward(self, source, target):
        batch_size = min(source.size(0), target.size(0))
        source = source[:batch_size]
        target = target[:batch_size]

        bandwidth = 1.0

        mmd_total = 0.0
        for i in range(self.kernel_num):
            sigma = bandwidth * (self.kernel_mul ** i)

            def compute_kernel(x, y, sigma):
                x_norm = (x ** 2).sum(1).view(-1, 1)
                y_norm = (y ** 2).sum(1).view(1, -1)
                dist = x_norm + y_norm - 2.0 * torch.mm(x, y.t())

                dist = torch.clamp(dist, min=1e-8)

                return torch.exp(-dist / (2.0 * sigma ** 2))

            K_XX = compute_kernel(source, source, sigma)
            K_YY = compute_kernel(target, target, sigma)
            K_XY = compute_kernel(source, target, sigma)

            mmd = K_XX.mean() + K_YY.mean() - 2 * K_XY.mean()

            mmd = torch.clamp(mmd, min=0.0)
            mmd_total += mmd

        return mmd_total / self.kernel_num


class MultiMetricLoss(nn.Module):

    def __init__(self):
        super().__init__()

    def mae_loss(self, pred, target):
        return F.l1_loss(pred, target)

    def rmse_loss(self, pred, target):
        mse = F.mse_loss(pred, target)
        return torch.sqrt(mse + 1e-8)

    def r2_loss(self, pred, target):
        ss_res = torch.sum((target - pred) ** 2)

        target_mean = torch.mean(target)
        ss_tot = torch.sum((target - target_mean) ** 2)

        ss_tot = torch.clamp(ss_tot, min=1e-8)

        r2_loss = ss_res / ss_tot

        return r2_loss

    def forward(self, pred, target, focus_metric='mae', weights=None):

        mae = self.mae_loss(pred, target)
        rmse = self.rmse_loss(pred, target)
        r2 = self.r2_loss(pred, target)

        if weights is not None:
            w_mae = weights.get('mae', 0.33)
            w_rmse = weights.get('rmse', 0.33)
            w_r2 = weights.get('r2', 0.34)
        else:
            if focus_metric == 'mae':
                w_mae, w_rmse, w_r2 = 0.7, 0.15, 0.15
            elif focus_metric == 'rmse':
                w_mae, w_rmse, w_r2 = 0.15, 0.7, 0.15
            elif focus_metric == 'r2':
                w_mae, w_rmse, w_r2 = 0.15, 0.15, 0.7
            else:
                w_mae, w_rmse, w_r2 = 0.33, 0.33, 0.34

        total_loss = w_mae * mae + w_rmse * rmse + w_r2 * r2

        metrics_dict = {
            'mae': mae.item(),
            'rmse': rmse.item(),
            'r2_loss': r2.item(),
            'r2_score': 1.0 - r2.item(),
            'weights': {'mae': w_mae, 'rmse': w_rmse, 'r2': w_r2}
        }

        return total_loss, metrics_dict


class FeatureExtractor:

    def __init__(self, model):
        self.model = model

    def extract(self, x, require_grad=False):
        if require_grad:
            outputs = self.model(x)
        else:
            with torch.no_grad():
                outputs = self.model(x)

        if isinstance(outputs, dict):
            for key in ['features', 'hidden_state', 'encoder_output', 'fine_features']:
                if key in outputs:
                    feat = outputs[key]
                    if feat.dim() == 3:
                        feat = feat.mean(dim=1)
                    return feat
            for key, value in outputs.items():
                if torch.is_tensor(value) and value.dim() in [2, 3]:
                    feat = value
                    if feat.dim() == 3:
                        feat = feat.mean(dim=1)
                    return feat
        else:
            feat = outputs
            if feat.dim() == 3:
                feat = feat.mean(dim=1)
            return feat

        batch_size = x.size(0)
        return torch.randn(batch_size, 32, device=x.device)


class MMDDomainAdaptationTrainerSimple:

    def __init__(self,
                 source_model,
                 target_model,
                 feature_dim: int = 32,
                 device: str = 'cuda:0',
                 mmd_weight: float = 0.3,
                 causal_weight: float = 0.2,
                 metric_cycle_epochs: int = 10):
        self.device = device
        self.feature_dim = feature_dim
        self.mmd_weight = mmd_weight
        self.causal_weight = causal_weight
        self.metric_cycle_epochs = metric_cycle_epochs

        self.source_model = source_model.to(device)
        self.target_model = target_model.to(device)

        for param in self.source_model.parameters():
            param.requires_grad = False
        self.source_model.eval()

        self.mmd_loss = MMDLoss(kernel_type='rbf', kernel_mul=2.0, kernel_num=5)
        self.multi_metric_loss = MultiMetricLoss()

        self.causal_alignment = FastCausalMatrixAlignment(
            target_size=200
        ).to(device)

        self.source_info = None
        self.target_info = None

        self.optimizer = optim.Adam(
            self.target_model.parameters(),
            lr=1e-4,
            weight_decay=1e-5
        )

        self.best_val_loss = float('inf')
        self.best_model_state = None
        self.history = {
            'train_loss': [],
            'pred_loss': [],
            'mmd_loss': [],
            'causal_loss': [],
            'mae': [],
            'rmse': [],
            'r2_loss': [],
            'r2_score': [],
            'val_mae': [],
            'val_rmse': [],
            'val_r2': [],
            'focus_metric': []
        }

    def set_city_info(self, source_info, target_info):
        self.source_info = source_info
        self.target_info = target_info

    def prepare_masks(self, batch_size):
        return None, None
    def get_focus_metric(self, epoch: int) -> str:
        cycle_position = (epoch // self.metric_cycle_epochs) % 3

        if cycle_position == 0:
            return 'mae'
        elif cycle_position == 1:
            return 'rmse'
        else:
            return 'r2'

    def extract_features_fixed(self, model, x, model_type='source'):
        batch_size = x.size(0)

        outputs = model(x)

        if isinstance(outputs, dict):
            if 'features' in outputs:
                feats = outputs['features']
            elif 'encoder_output' in outputs:
                feats = outputs['encoder_output']
            elif 'hidden_state' in outputs:
                feats = outputs['hidden_state']
            else:
                for key, value in outputs.items():
                    if torch.is_tensor(value) and value.dim() in [2, 3]:
                        feats = value
                        break
                else:
                    feats = outputs['fine_predictions'] if 'fine_predictions' in outputs else None
        else:
            feats = outputs

        if feats is None:
            return torch.randn(batch_size, self.feature_dim, device=x.device)

        if feats.dim() == 3:
            if model_type == 'source' and feats.size(-1) == 460:
                feats = feats.mean(dim=1)  # [B, 460]
                if feats.size(1) > self.feature_dim:
                    feats = F.adaptive_avg_pool1d(feats.unsqueeze(1), self.feature_dim).squeeze(1)
            else:
                feats = feats.mean(dim=1)  # [B, N] or [B, D]

        if feats.size(1) > self.feature_dim:
            feats = feats[:, :self.feature_dim]
        elif feats.size(1) < self.feature_dim:
            padding = torch.zeros(
                batch_size,
                self.feature_dim - feats.size(1),
                device=x.device,
                requires_grad=False
            )
            feats = torch.cat([feats, padding], dim=1)

        return feats

    def train_epoch_simple(self, source_loader: DataLoader, target_loader: DataLoader,
                           epoch: int, total_epochs: int) -> Dict:

        self.target_model.train()

        stats = {
            'total_loss': 0.0,
            'pred_loss': 0.0,
            'mmd_loss': 0.0,
            'causal_loss': 0.0,
            'mae': 0.0,
            'rmse': 0.0,
            'r2_loss': 0.0,
            'r2_score': 0.0,
        }
        focus_metric = self.get_focus_metric(epoch)

        min_batches = min(len(source_loader), len(target_loader))
        source_iter = iter(source_loader)
        target_iter = iter(target_loader)

        source_mask, target_mask = self.prepare_masks(min_batches)

        pbar = tqdm(range(min_batches),
                    desc=f'Epoch {epoch + 1}/{total_epochs} [Focus: {focus_metric.upper()}]')

        for batch_idx in pbar:
            try:
                source_batch = next(source_iter)
                target_batch = next(target_iter)

                source_flow, _, _, _ = source_batch
                target_flow, _, _, target_target = target_batch

                if source_flow.dim() == 4:
                    B, T, H, W = source_flow.shape
                    source_flow = source_flow.view(B, T, H * W)
                    if source_mask is not None:
                        source_flow = source_flow[:, :, source_mask]

                if target_flow.dim() == 4:
                    B, T, H, W = target_flow.shape
                    target_flow = target_flow.view(B, T, H * W)
                    if target_mask is not None:
                        target_flow = target_flow[:, :, target_mask]

                source_flow = source_flow.to(self.device)
                target_flow = target_flow.to(self.device)
                target_target = target_target.to(self.device).view(target_target.size(0), -1)

                with torch.no_grad():
                    source_outputs = self.source_model(
                        source_flow,
                        return_cluster_info=False,
                        return_causal_matrix=True
                    )

                target_outputs = self.target_model(
                    target_flow,
                    return_cluster_info=False,
                    return_causal_matrix=True
                )

                source_fine_causal = source_outputs.get('fine_causal_matrix')
                target_fine_causal = target_outputs.get('fine_causal_matrix')

                should_align_causal = (
                        batch_idx % 10 == 0 or
                        batch_idx < 10 or
                        epoch == 0
                )

                if should_align_causal and source_fine_causal is not None and target_fine_causal is not None:

                    if source_fine_causal.shape != target_fine_causal.shape:
                        min_dim = min(source_fine_causal.size(0), target_fine_causal.size(0))

                        if min_dim > 0:
                            source_aligned = source_fine_causal[:min_dim, :min_dim]
                            target_aligned = target_fine_causal[:min_dim, :min_dim]

                            causal_loss, causal_metrics = self.causal_alignment(
                                {'fine_causal_matrix': source_aligned},
                                {'fine_causal_matrix': target_aligned},
                                None, None,
                                debug=False
                            )

                            # 只在前几个批次显示对齐结果
                            if epoch < 2 and batch_idx < 5:
                                print(f"causal_loss: {causal_loss.item():.6f}")
                        else:
                            causal_loss = torch.tensor(0.0, device=self.device)
                else:
                    causal_loss = torch.tensor(0.0, device=self.device)

                target_pred = target_outputs['fine_predictions']
                if target_pred.dim() == 3:
                    target_pred = target_pred.squeeze(1)

                min_dim = min(target_pred.size(1), target_target.size(1))
                pred_loss, metrics = self.multi_metric_loss(
                    target_pred[:, :min_dim],
                    target_target[:, :min_dim],
                    focus_metric=focus_metric
                )

                source_feats = self.extract_features_fixed(
                    self.source_model, source_flow, model_type='source'
                )
                target_feats = self.extract_features_fixed(
                    self.target_model, target_flow, model_type='target'
                )

                batch_size = min(source_feats.size(0), target_feats.size(0))
                source_feats = source_feats[:batch_size]
                target_feats = target_feats[:batch_size]

                mmd_loss = self.mmd_loss(source_feats.detach(), target_feats)

                if epoch < 10:
                    mmd_weight = 0.1
                    causal_weight = 0.1
                elif epoch < 30:
                    mmd_weight = 0.3
                    causal_weight = 0.2
                else:
                    mmd_weight = 0.2
                    causal_weight = 0.3

                if pred_loss.item() < 0.001:
                    mmd_weight *= 0.5
                    causal_weight *= 0.5

                total_loss = (
                        pred_loss +
                        mmd_weight * mmd_loss +
                        causal_weight * causal_loss
                )

                self.optimizer.zero_grad()
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.target_model.parameters(), 1.0)
                self.optimizer.step()

                stats['total_loss'] += total_loss.item()
                stats['pred_loss'] += pred_loss.item()
                stats['mmd_loss'] += mmd_loss.item()
                stats['causal_loss'] += causal_loss.item()
                stats['mae'] += metrics['mae']
                stats['rmse'] += metrics['rmse']
                stats['r2_loss'] += metrics['r2_loss']
                stats['r2_score'] += metrics['r2_score']

                pbar.set_postfix({
                    'pred': f'{pred_loss.item():.4f}',
                    'mmd': f'{mmd_loss.item():.4f}',
                    'causal': f'{causal_loss.item():.4f}',
                    'mae': f'{metrics["mae"]:.4f}',
                    'r2': f'{metrics["r2_score"]:.4f}',
                })

                if batch_idx % 20 == 0:
                    torch.cuda.empty_cache()

            except Exception as e:
                print(f"\natch {batch_idx} Error: {e}")
                continue

        num_batches = batch_idx + 1
        for key in stats:
            if num_batches > 0:
                stats[key] /= num_batches

        stats['focus_metric'] = focus_metric

        return stats
    def get_valid_indices(self):
        if self.source_info is None or self.target_info is None:
            return None, None

        try:
            source_valid = self.source_info['valid_indices']
            target_valid = self.target_info['valid_indices']

            return source_valid, target_valid
        except Exception as e:
            print(f" : {e}")
            return None, None

    def compute_efficient_causal_alignment(self, source_causal, target_causal):
        if source_causal is None or target_causal is None:
            return torch.tensor(0.0, device=self.device)

        if source_causal.size(0) != target_causal.size(1):
            return self.adaptive_causal_alignment(source_causal, target_causal)

        return self.direct_causal_alignment(source_causal, target_causal)

    def adaptive_causal_alignment(self, source_causal, target_causal):
        min_dim = min(source_causal.size(0), target_causal.size(0))

        if min_dim <= 0:
            return torch.tensor(0.0, device=self.device)

        source_sub = source_causal[:min_dim, :min_dim]
        target_sub = target_causal[:min_dim, :min_dim]

        source_features = source_sub.flatten().unsqueeze(0)
        target_features = target_sub.flatten().unsqueeze(0)

        loss = self.mmd_loss(source_features, target_features)

        return loss

    def direct_causal_alignment(self, source_causal, target_causal):
        source_features = source_causal.flatten().unsqueeze(0)
        target_features = target_causal.flatten().unsqueeze(0)

        loss = self.mmd_loss(source_features, target_features)

        return loss

    def train(self,
              source_loader: DataLoader,
              target_loader: DataLoader,
              target_val_loader: DataLoader,
              epochs: int = 50,
              patience: int = 10) -> Dict:
        print(f"\n{'=' * 60}")
        print(f"Starting MMD domain adaptation training (multi-metric version)")
        print(f"{'=' * 60}\n")

        patience_counter = 0

        for epoch in range(epochs):
            train_stats = self.train_epoch_simple(
                source_loader,
                target_loader,
                epoch,
                epochs
            )

            val_metrics = self.validate(target_val_loader)

            self.history['train_loss'].append(train_stats['total_loss'])
            self.history['pred_loss'].append(train_stats['pred_loss'])
            self.history['mmd_loss'].append(train_stats['mmd_loss'])
            self.history['mae'].append(train_stats['mae'])
            self.history['rmse'].append(train_stats['rmse'])
            self.history['r2_loss'].append(train_stats['r2_loss'])
            self.history['r2_score'].append(train_stats['r2_score'])
            self.history['val_mae'].append(val_metrics['MAE'])
            self.history['val_rmse'].append(val_metrics['RMSE'])
            self.history['val_r2'].append(val_metrics['R2'])
            self.history['focus_metric'].append(train_stats['focus_metric'])

            print(f"\n{'=' * 60}")
            print(f"Epoch {epoch + 1}/{epochs} Summary [Primary Metric: {train_stats['focus_metric'].upper()}]")
            print(f"{'=' * 60}")
            print(f" Training Statistics:")
            print(f"   Total Loss: {train_stats['total_loss']:.6f}")
            print(f"   Prediction Loss: {train_stats['pred_loss']:.6f}")
            print(f"   MMD Loss: {train_stats['mmd_loss']:.6f}")

            print(f"\n Training Metrics:")
            print(f"   MAE: {train_stats['mae']:.4f}")
            print(f"   RMSE: {train_stats['rmse']:.4f}")
            print(f"   R² Score: {train_stats['r2_score']:.4f}")

            print(f"\n Validation Metrics:")
            print(f"   MAE: {val_metrics['MAE']:.4f}")
            print(f"   RMSE: {val_metrics['RMSE']:.4f}")
            print(f"   R²: {val_metrics['R2']:.4f}")

            # Save the best model (based on MAE)
            if val_metrics['MAE'] < self.best_val_loss:
                self.best_val_loss = val_metrics['MAE']
                self.best_model_state = copy.deepcopy(self.target_model.state_dict())

                torch.save({
                    'epoch': epoch,
                    'model_state': self.best_model_state,
                    'val_mae': self.best_val_loss,
                    'val_rmse': val_metrics['RMSE'],
                    'val_r2': val_metrics['R2'],
                    'history': self.history,
                }, 'best_mmd_model_multi_metric.pth')

                print(f"\nSaved best model (MAE: {self.best_val_loss:.4f}, R²: {val_metrics['R2']:.4f})")
                patience_counter = 0
            else:
                patience_counter += 1
                print(f"\n Early stopping counter: {patience_counter}/{patience}")

                if patience_counter >= patience:
                    print(f"\nEarly stopping at epoch {epoch + 1}")
                    break

        # Restore the best model
        if self.best_model_state:
            self.target_model.load_state_dict(self.best_model_state)
            print(f"\n Best model restored")

        print(f"\n{'=' * 60}")
        print(f" Training Complete!")
        print(f"{'=' * 60}")
        print(f"Best Validation MAE: {self.best_val_loss:.4f}")
        print(f"Final MMD Loss: {self.history['mmd_loss'][-1]:.6f}")
        print(f"Final R² Score: {self.history['val_r2'][-1]:.4f}")

        # Calculate metric improvements
        if len(self.history['mmd_loss']) > 1:
            mmd_improvement = (self.history['mmd_loss'][0] - self.history['mmd_loss'][-1]) / \
                              self.history['mmd_loss'][0] * 100
            print(f"MMD Improvement: {mmd_improvement:.1f}%")

        print(f"{'=' * 60}\n")

        return self.history
    def validate(self, val_loader: DataLoader) -> Dict:
        self.target_model.eval()

        all_preds = []
        all_targets = []

        with torch.no_grad():
            for flow, _, _, target in tqdm(val_loader, desc='验证中'):
                flow = flow.to(self.device).view(flow.size(0), flow.size(1), -1)
                target = target.to(self.device).view(target.size(0), -1)

                outputs = self.target_model(flow)

                if isinstance(outputs, dict):
                    preds = outputs.get('fine_predictions')
                    if preds is None:
                        preds = list(outputs.values())[0]
                else:
                    preds = outputs

                if preds.dim() == 3:
                    preds = preds.squeeze(1)

                min_dim = min(preds.size(1), target.size(1))
                all_preds.append(preds[:, :min_dim].cpu())
                all_targets.append(target[:, :min_dim].cpu())

        if all_preds:
            all_preds = torch.cat(all_preds, dim=0)
            all_targets = torch.cat(all_targets, dim=0)

            mae = F.l1_loss(all_preds, all_targets).item()

            mse = F.mse_loss(all_preds, all_targets).item()
            rmse = np.sqrt(mse)

            ss_res = torch.sum((all_targets - all_preds) ** 2).item()
            ss_tot = torch.sum((all_targets - torch.mean(all_targets)) ** 2).item()
            r2 = 1 - (ss_res / (ss_tot + 1e-8))

            return {
                'MAE': mae,
                'RMSE': rmse,
                'R2': r2,
                'MSE': mse
            }

        return {
            'MAE': float('inf'),
            'RMSE': float('inf'),
            'R2': -float('inf'),
            'MSE': float('inf')
        }


class FastCausalMatrixAlignment(nn.Module):

    def __init__(self, target_size):
        super().__init__()
        self.target_size = target_size
        self.mmd_loss = MMDLoss(kernel_type='rbf', kernel_mul=2.0, kernel_num=3)

    def forward(self, source_outputs, target_outputs, source_mask=None, target_mask=None, debug=False):
        source_causal = source_outputs.get('fine_causal_matrix')
        target_causal = target_outputs.get('fine_causal_matrix')

        if source_causal is None or target_causal is None:
            return torch.tensor(0.0, device=source_causal.device if source_causal is not None else 'cpu'), {
                'fine_causal_loss': 0.0,
                'coarse_causal_loss': 0.0,
                'total_causal_loss': 0.0
            }

        if source_causal.dim() == 2:
            source_causal = source_causal.unsqueeze(0).unsqueeze(0)
        if target_causal.dim() == 2:
            target_causal = target_causal.unsqueeze(0).unsqueeze(0)

        source_pooled = F.adaptive_avg_pool2d(source_causal, (self.target_size, self.target_size))
        target_pooled = F.adaptive_avg_pool2d(target_causal, (self.target_size, self.target_size))

        source_features = source_pooled.flatten().unsqueeze(0)
        target_features = target_pooled.flatten().unsqueeze(0)

        loss = self.mmd_loss(source_features, target_features)

        return loss, {
            'fine_causal_loss': loss.item(),
            'coarse_causal_loss': 0.0,
            'total_causal_loss': loss.item()
        }
def get_city_node_info(data_dict: Dict, city_name: str) -> Dict:
    mask = data_dict['mask']
    grid_h, grid_w = mask.shape

    mask_flat = mask.view(-1)
    valid_indices = torch.where(mask_flat)[0]
    fine_nodes = len(valid_indices)

    return {
        'city_name': city_name,
        'grid_size': (grid_h, grid_w),
        'total_nodes': grid_h * grid_w,
        'fine_nodes': fine_nodes,
        'valid_indices': valid_indices,
        'mask': mask
    }


def prepare_models(source_info: Dict,
                   target_info: Dict,
                   device: torch.device,
                   pretrained_path: str = None) -> Tuple:

    if pretrained_path is None:
        pretrained_path = os.path.join('/home/zc/ST-Mamba/file',
                                       'pretrained_integrated_model.pth')
    source_model = ClusterGuidedPredictor(
        fine_nodes=source_info['fine_nodes'],
        grid_size=source_info['grid_size'],
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    ).to(device)

    target_model = ClusterGuidedPredictor(
        fine_nodes=target_info['fine_nodes'],
        grid_size=target_info['grid_size'],
        hidden_dim=32,
        num_clusters=5,
        use_metric_loss=True,
        use_stacking_fusion=True
    ).to(device)

    if os.path.exists(pretrained_path):
        print(f" Loading pretrained model: {pretrained_path}")
        try:
            state_dict = torch.load(pretrained_path, map_location=device, weights_only=False)

            # Handle mismatched keys
            model_dict = source_model.state_dict()

            # 1. Filter matching keys
            pretrained_dict = {k: v for k, v in state_dict.items()
                               if k in model_dict and v.size() == model_dict[k].size()}

            # 2. Adjust for mismatched keys
            for k, v in state_dict.items():
                if k not in pretrained_dict:
                    # Try adding underscore prefix
                    if f"_{k}" in model_dict and v.size() == model_dict[f"_{k}"].size():
                        pretrained_dict[f"_{k}"] = v
                    # Try removing prefix
                    elif k.startswith('_') and k[1:] in model_dict and v.size() == model_dict[k[1:]].size():
                        pretrained_dict[k[1:]] = v

            # Update model parameters
            model_dict.update(pretrained_dict)
            source_model.load_state_dict(model_dict)

            print(f" Successfully loaded {len(pretrained_dict)}/{len(model_dict)} parameters to source model")

        except Exception as e:
            print(f" Failed to load pretrained model: {e}")
            print("   Using random initialization")
    else:
        print(f" Pretrained model not found: {pretrained_path}")
        print("   Using random initialization")

    print(f"\n Model initialization completed")
    print(f"   Source model ({source_info['city_name']}): {source_info['fine_nodes']} nodes")
    print(f"   Target model ({target_info['city_name']}): {target_info['fine_nodes']} nodes")

    return source_model, target_model


