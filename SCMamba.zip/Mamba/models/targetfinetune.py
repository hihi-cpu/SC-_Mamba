import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
import numpy as np
import os
from typing import Dict, Tuple
from tqdm import tqdm
import copy
import matplotlib.pyplot as plt

# Need to import model definitions
import sys

sys.path.append('/mnt/d/python_study/ST-Mamba/file')

class TargetDomainFinetuner:
    """Target domain fine-tuner"""

    def __init__(self,
                 model,
                 device: str = 'cuda:0',
                 learning_rate: float = 5e-5,
                 weight_decay: float = 1e-5):
        """
        Args:
            model: Pre-trained target domain model
            device: Training device
            learning_rate: Learning rate (use smaller learning rate for fine-tuning)
            weight_decay: Weight decay
        """
        self.device = device
        self.model = model.to(device)

        # Loss functions - combination of multiple losses
        self.mse_criterion = nn.MSELoss()
        self.mae_criterion = nn.L1Loss()
        self.smooth_l1_criterion = nn.SmoothL1Loss()

        # Optimizer - use smaller learning rate for fine-tuning
        self.optimizer = optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay,
            betas=(0.9, 0.999)
        )

        # Learning rate scheduler - cosine annealing
        self.scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=10,
            T_mult=2,
            eta_min=1e-6
        )

        # Training state
        self.best_val_mae = float('inf')
        self.best_val_r2 = -float('inf')
        self.best_model_state = None

        # History records
        self.history = {
            'train_loss': [],
            'train_mae': [],
            'train_rmse': [],
            'val_mae': [],
            'val_rmse': [],
            'val_r2': [],
            'val_loss': [],
            'learning_rate': []
        }

    def compute_r2_score(self, predictions: torch.Tensor, targets: torch.Tensor) -> float:
        """
        Calculate R² score
        Args:
            predictions: Predicted values [N, D]
            targets: True values [N, D]
        Returns:
            r2_score: R² score
        """
        # Calculate total sum of squares (TSS)
        mean_target = targets.mean()
        tss = ((targets - mean_target) ** 2).sum()

        # Calculate residual sum of squares (RSS)
        rss = ((targets - predictions) ** 2).sum()

        # R² = 1 - RSS/TSS
        r2 = 1 - (rss / (tss + 1e-8))

        return r2.item()

    def train_epoch(self, train_loader: DataLoader, epoch: int) -> Dict:
        """Train one epoch"""
        self.model.train()

        total_loss = 0.0
        all_preds = []
        all_targets = []

        pbar = tqdm(train_loader, desc=f'Epoch {epoch}')

        for batch_idx, (flow, _, _, target) in enumerate(pbar):
            # Data preparation
            if flow.dim() == 4:  # [B, T, H, W]
                flow = flow.view(flow.size(0), flow.size(1), -1)

            flow = flow.to(self.device)
            target = target.to(self.device).view(target.size(0), -1)

            # Forward pass
            outputs = self.model(flow)

            # Get predictions
            if isinstance(outputs, dict):
                predictions = outputs.get('fine_predictions')
                if predictions is None:
                    predictions = list(outputs.values())[0]
            else:
                predictions = outputs

            if predictions.dim() == 3:
                predictions = predictions.squeeze(1)

            # Ensure dimensions match
            min_dim = min(predictions.size(1), target.size(1))
            predictions = predictions[:, :min_dim]
            target = target[:, :min_dim]

            # Calculate composite loss - combine MAE, MSE and Smooth L1
            mae_loss = self.mae_criterion(predictions, target)
            mse_loss = self.mse_criterion(predictions, target)
            smooth_l1_loss = self.smooth_l1_criterion(predictions, target)

            # Weighted combination
            loss = 0.4 * mae_loss + 0.3 * mse_loss + 0.3 * smooth_l1_loss

            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()

            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()

            # Record
            total_loss += loss.item()
            all_preds.append(predictions.detach().cpu())
            all_targets.append(target.detach().cpu())

            # Update progress bar
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'mae': f'{mae_loss.item():.4f}',
                'lr': f'{self.optimizer.param_groups[0]["lr"]:.2e}'
            })

        # Calculate epoch statistics
        avg_loss = total_loss / len(train_loader)

        all_preds = torch.cat(all_preds, dim=0)
        all_targets = torch.cat(all_targets, dim=0)

        train_mae = F.l1_loss(all_preds, all_targets).item()
        train_mse = F.mse_loss(all_preds, all_targets).item()
        train_rmse = np.sqrt(train_mse)

        return {
            'loss': avg_loss,
            'mae': train_mae,
            'rmse': train_rmse
        }

    def validate(self, val_loader: DataLoader) -> Dict:
        """Validation"""
        self.model.eval()

        all_preds = []
        all_targets = []
        total_loss = 0.0

        with torch.no_grad():
            for flow, _, _, target in tqdm(val_loader, desc='Validating', leave=False):
                # Data preparation
                if flow.dim() == 4:
                    flow = flow.view(flow.size(0), flow.size(1), -1)

                flow = flow.to(self.device)
                target = target.to(self.device).view(target.size(0), -1)

                # Forward pass
                outputs = self.model(flow)

                # Get predictions
                if isinstance(outputs, dict):
                    predictions = outputs.get('fine_predictions')
                    if predictions is None:
                        predictions = list(outputs.values())[0]
                else:
                    predictions = outputs

                if predictions.dim() == 3:
                    predictions = predictions.squeeze(1)

                # Ensure dimensions match
                min_dim = min(predictions.size(1), target.size(1))
                predictions = predictions[:, :min_dim]
                target = target[:, :min_dim]

                # Calculate loss
                loss = self.mae_criterion(predictions, target)
                total_loss += loss.item()

                # Collect predictions and targets
                all_preds.append(predictions.cpu())
                all_targets.append(target.cpu())

        # Calculate metrics
        all_preds = torch.cat(all_preds, dim=0)
        all_targets = torch.cat(all_targets, dim=0)

        val_mae = F.l1_loss(all_preds, all_targets).item()
        val_mse = F.mse_loss(all_preds, all_targets).item()
        val_rmse = np.sqrt(val_mse)
        val_r2 = self.compute_r2_score(all_preds, all_targets)
        avg_loss = total_loss / len(val_loader)

        return {
            'loss': avg_loss,
            'mae': val_mae,
            'rmse': val_rmse,
            'r2': val_r2
        }

    def train(self,
              train_loader: DataLoader,
              val_loader: DataLoader,
              epochs: int = 50,
              patience: int = 15,
              save_dir: str = './checkpoints') -> Dict:
        """
        Complete training process
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
            epochs: Training epochs
            patience: Early stopping patience value
            save_dir: Model save directory
        """
        os.makedirs(save_dir, exist_ok=True)

        print(f"\n{'=' * 60}")
        print(f" Starting target domain fine-tuning")
        print(f"{'=' * 60}")
        print(f"Training epochs: {epochs}")
        print(f"Early stopping patience: {patience}")
        print(f"Learning rate: {self.optimizer.param_groups[0]['lr']:.2e}")
        print(f"Device: {self.device}")
        print(f"{'=' * 60}\n")

        patience_counter = 0

        for epoch in range(1, epochs + 1):
            # Training
            train_stats = self.train_epoch(train_loader, epoch)

            # Validation
            val_stats = self.validate(val_loader)

            # Update learning rate
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]['lr']

            # Record history
            self.history['train_loss'].append(train_stats['loss'])
            self.history['train_mae'].append(train_stats['mae'])
            self.history['train_rmse'].append(train_stats['rmse'])
            self.history['val_loss'].append(val_stats['loss'])
            self.history['val_mae'].append(val_stats['mae'])
            self.history['val_rmse'].append(val_stats['rmse'])
            self.history['val_r2'].append(val_stats['r2'])
            self.history['learning_rate'].append(current_lr)

            # Print statistics
            print(f"\n{'=' * 60}")
            print(f"Epoch {epoch}/{epochs} Summary")
            print(f"{'=' * 60}")
            print(f" Training metrics:")
            print(f"   Loss: {train_stats['loss']:.6f}")
            print(f"   MAE: {train_stats['mae']:.4f}")
            print(f"   RMSE: {train_stats['rmse']:.4f}")

            print(f"\n Validation metrics:")
            print(f"   Loss: {val_stats['loss']:.6f}")
            print(f"   MAE: {val_stats['mae']:.4f} {'✨' if val_stats['mae'] < self.best_val_mae else ''}")
            print(f"   RMSE: {val_stats['rmse']:.4f}")
            print(f"   R²: {val_stats['r2']:.4f} {'✨' if val_stats['r2'] > self.best_val_r2 else ''}")
            print(f"   Learning rate: {current_lr:.2e}")

            # Save best model (based on MAE)
            if val_stats['mae'] < self.best_val_mae:
                self.best_val_mae = val_stats['mae']
                self.best_val_r2 = val_stats['r2']
                self.best_model_state = copy.deepcopy(self.model.state_dict())

                # Save checkpoint
                checkpoint_path = os.path.join(save_dir, 'best_finetuned_model.pth')
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': self.best_model_state,
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'scheduler_state_dict': self.scheduler.state_dict(),
                    'best_val_mae': self.best_val_mae,
                    'best_val_r2': self.best_val_r2,
                    'val_rmse': val_stats['rmse'],
                    'history': self.history
                }, checkpoint_path)

                print(f"\n Saved best model (MAE: {self.best_val_mae:.4f}, R²: {self.best_val_r2:.4f})")
                patience_counter = 0
            else:
                patience_counter += 1
                print(f"\n Early stopping counter: {patience_counter}/{patience}")

                if patience_counter >= patience:
                    print(f"\n Early stopping at epoch {epoch}")
                    break

        # Restore best model
        if self.best_model_state:
            self.model.load_state_dict(self.best_model_state)
            print(f"\n Restored best model")

        # Save final model
        final_checkpoint_path = os.path.join(save_dir, 'final_finetuned_model.pth')
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'best_val_mae': self.best_val_mae,
            'best_val_r2': self.best_val_r2,
            'history': self.history
        }, final_checkpoint_path)

        print(f"\n{'=' * 60}")
        print(f" Fine-tuning completed!")
        print(f"{'=' * 60}")
        print(f"Best validation MAE: {self.best_val_mae:.4f}")
        print(f"Best validation R²: {self.best_val_r2:.4f}")
        print(f"Final validation RMSE: {min(self.history['val_rmse']):.4f}")
        print(f"{'=' * 60}\n")

        return self.history


def prepare_target_data_splits(target_data: Dict,
                               train_ratio: float = 0.7,
                               val_ratio: float = 0.15,
                               batch_size: int = 16) -> Tuple:
    """
    Prepare training, validation, and test sets for target domain
    Args:
        target_data: Target domain data dictionary
        train_ratio: Training set ratio
        val_ratio: Validation set ratio
        batch_size: Batch size
    Returns:
        train_loader, val_loader, test_loader
    """
    dataset = target_data['dataset']
    total_size = len(dataset)

    # Calculate split sizes
    train_size = int(total_size * train_ratio)
    val_size = int(total_size * val_ratio)
    test_size = total_size - train_size - val_size

    # Random split
    train_dataset, val_dataset, test_dataset = random_split(
        dataset,
        [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    print(f"\n Dataset split:")
    print(f"   Training set: {len(train_dataset)} ({train_ratio * 100:.0f}%)")
    print(f"   Validation set: {len(val_dataset)} ({val_ratio * 100:.0f}%)")
    print(f"   Test set: {len(test_dataset)} ({(1 - train_ratio - val_ratio) * 100:.0f}%)")
    print(f"   Batch size: {batch_size}")

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=2,
        pin_memory=True,
        drop_last=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    print(f"\n Data loaders:")
    print(f"   Training batches: {len(train_loader)}")
    print(f"   Validation batches: {len(val_loader)}")
    print(f"   Test batches: {len(test_loader)}")

    return train_loader, val_loader, test_loader


def evaluate_on_test_set(model, test_loader, device='cuda:0') -> Dict:
    """
    Evaluate model on test set
    Args:
        model: Trained model
        test_loader: Test data loader
        device: Device
    Returns:
        test_metrics: Test metrics dictionary
    """
    model.eval()
    model.to(device)

    all_preds = []
    all_targets = []

    print(f"\n{'=' * 60}")
    print(f" Test set evaluation")
    print(f"{'=' * 60}")

    with torch.no_grad():
        for flow, _, _, target in tqdm(test_loader, desc='Testing'):
            # Data preparation
            if flow.dim() == 4:
                flow = flow.view(flow.size(0), flow.size(1), -1)

            flow = flow.to(device)
            target = target.to(device).view(target.size(0), -1)

            # Forward pass
            outputs = model(flow)

            # Get predictions
            if isinstance(outputs, dict):
                predictions = outputs.get('fine_predictions')
                if predictions is None:
                    predictions = list(outputs.values())[0]
            else:
                predictions = outputs

            if predictions.dim() == 3:
                predictions = predictions.squeeze(1)

            # Ensure dimensions match
            min_dim = min(predictions.size(1), target.size(1))
            predictions = predictions[:, :min_dim]
            target = target[:, :min_dim]

            # Collect results
            all_preds.append(predictions.cpu())
            all_targets.append(target.cpu())

    # Combine all predictions
    all_preds = torch.cat(all_preds, dim=0)
    all_targets = torch.cat(all_targets, dim=0)

    # Calculate metrics
    test_mae = F.l1_loss(all_preds, all_targets).item()
    test_mse = F.mse_loss(all_preds, all_targets).item()
    test_rmse = np.sqrt(test_mse)

    # Calculate R²
    mean_target = all_targets.mean()
    tss = ((all_targets - mean_target) ** 2).sum()
    rss = ((all_targets - all_preds) ** 2).sum()
    test_r2 = (1 - (rss / (tss + 1e-8))).item()

    # Calculate MAPE
    mape = (torch.abs((all_targets - all_preds) / (all_targets + 1e-8))).mean().item() * 100

    test_metrics = {
        'MAE': test_mae,
        'RMSE': test_rmse,
        'MSE': test_mse,
        'R2': test_r2,
        'MAPE': mape
    }

    print(f"\n Test set metrics:")
    print(f"   MAE:  {test_mae:.4f}")
    print(f"   RMSE: {test_rmse:.4f}")
    print(f"   MSE:  {test_mse:.6f}")
    print(f"   R²:   {test_r2:.4f}")
    print(f"   MAPE: {mape:.2f}%")
    print(f"{'=' * 60}\n")

    return test_metrics


def plot_training_history(history: Dict, save_path: str = None):
    """
    Plot training history
    Args:
        history: Training history dictionary
        save_path: Image save path
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    epochs = range(1, len(history['train_loss']) + 1)

    # Loss curve
    axes[0, 0].plot(epochs, history['train_loss'], 'b-', label='Train Loss', linewidth=2)
    axes[0, 0].plot(epochs, history['val_loss'], 'r-', label='Val Loss', linewidth=2)
    axes[0, 0].set_xlabel('Epoch', fontsize=12)
    axes[0, 0].set_ylabel('Loss', fontsize=12)
    axes[0, 0].set_title('Loss Curves', fontsize=14, fontweight='bold')
    axes[0, 0].legend(fontsize=10)
    axes[0, 0].grid(True, alpha=0.3)

    # MAE curve
    axes[0, 1].plot(epochs, history['train_mae'], 'b-', label='Train MAE', linewidth=2)
    axes[0, 1].plot(epochs, history['val_mae'], 'r-', label='Val MAE', linewidth=2)
    axes[0, 1].set_xlabel('Epoch', fontsize=12)
    axes[0, 1].set_ylabel('MAE', fontsize=12)
    axes[0, 1].set_title('MAE Curves', fontsize=14, fontweight='bold')
    axes[0, 1].legend(fontsize=10)
    axes[0, 1].grid(True, alpha=0.3)

    # RMSE curve
    axes[1, 0].plot(epochs, history['train_rmse'], 'b-', label='Train RMSE', linewidth=2)
    axes[1, 0].plot(epochs, history['val_rmse'], 'r-', label='Val RMSE', linewidth=2)
    axes[1, 0].set_xlabel('Epoch', fontsize=12)
    axes[1, 0].set_ylabel('RMSE', fontsize=12)
    axes[1, 0].set_title('RMSE Curves', fontsize=14, fontweight='bold')
    axes[1, 0].legend(fontsize=10)
    axes[1, 0].grid(True, alpha=0.3)

    # R² curve
    axes[1, 1].plot(epochs, history['val_r2'], 'g-', label='Val R²', linewidth=2)
    axes[1, 1].set_xlabel('Epoch', fontsize=12)
    axes[1, 1].set_ylabel('R² Score', fontsize=12)
    axes[1, 1].set_title('R² Score Curve', fontsize=14, fontweight='bold')
    axes[1, 1].legend(fontsize=10)
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.3)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f" Training curves saved to: {save_path}")

    plt.show()