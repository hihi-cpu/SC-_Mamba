from torch.utils.checkpoint import checkpoint
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple
from mamba_ssm import Mamba


class CorrelationGrangerCausal:

    def __init__(self, lag: int = 2, threshold: float = 0.05,
                 use_poi: bool = True, use_spatial: bool = True,
                 alpha: float = 0.7):
        self.lag = lag
        self.threshold = threshold
        self.use_poi = use_poi
        self.use_spatial = use_spatial
        self.alpha = alpha

    def compute(self, flow_data: torch.Tensor,
                poi_data: Optional[torch.Tensor] = None,
                road_adj: Optional[torch.Tensor] = None,
                prex_adj: Optional[torch.Tensor] = None,
                poi_adj: Optional[torch.Tensor] = None,
                mask: Optional[torch.Tensor] = None,
                grid_shape: Optional[Tuple[int, int]] = None) -> torch.Tensor:
        if flow_data.dim() == 4:
            B, T, H, W = flow_data.shape
            flow_flat = flow_data.reshape(B, T, H * W)
            K = H * W
        elif flow_data.dim() == 3:
            B, T, K = flow_data.shape
            flow_flat = flow_data
        else:
            raise ValueError(f"Unsupported flow_data shape: {flow_data.shape}")

        flow_np = flow_flat.detach().cpu().numpy()
        granger_matrix = self._basic_granger_causality(flow_np, B, T, K)

        if poi_data is None and road_adj is None and poi_adj is None:
            return self._postprocess_matrix(granger_matrix)

        return self._postprocess_matrix(granger_matrix)  # Simplified return

    def _basic_granger_causality(self, flow_np: np.ndarray, B: int, T: int, K: int) -> np.ndarray:
        C = np.zeros((K, K), dtype=np.float32)
        max_nodes = min(K, 100)

        for i in range(max_nodes):
            for j in range(max_nodes):
                if i == j:
                    continue
                causality, count = 0.0, 0
                for lag_val in range(1, self.lag + 1):
                    if T > lag_val:
                        try:
                            source_lag = flow_np[:, :-lag_val, i]
                            target_current = flow_np[:, lag_val:, j]

                            if (np.std(source_lag) > 1e-8 and
                                    np.std(target_current) > 1e-8 and
                                    not np.any(np.isnan(source_lag)) and
                                    not np.any(np.isnan(target_current))):
                                corr = self._batch_correlation(
                                    source_lag.reshape(B, -1),
                                    target_current.reshape(B, -1)
                                )
                                causality += np.mean(corr)
                                count += 1
                        except:
                            continue

                if count > 0:
                    C[i, j] = max(0.0, causality / count)

        return C

    def _batch_correlation(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        try:
            x_std = x.std(axis=1, keepdims=True)
            y_std = y.std(axis=1, keepdims=True)
            valid_mask = (x_std > 1e-8) & (y_std > 1e-8)

            corr = np.zeros(x.shape[0])
            valid_indices = np.where(valid_mask.flatten())[0]

            if len(valid_indices) > 0:
                x_valid = x[valid_indices]
                y_valid = y[valid_indices]
                x_std_valid = x_std[valid_indices]
                y_std_valid = y_std[valid_indices]

                x_norm = (x_valid - x_valid.mean(axis=1, keepdims=True)) / x_std_valid
                y_norm = (y_valid - y_valid.mean(axis=1, keepdims=True)) / y_std_valid

                corr_valid = (x_norm * y_norm).mean(axis=1)
                corr[valid_indices] = np.clip(corr_valid, -1, 1)

            return corr
        except Exception as e:
            return np.zeros(x.shape[0])

    def _postprocess_matrix(self, matrix: np.ndarray) -> torch.Tensor:
        matrix[matrix < self.threshold] = 0.0
        row_sums = matrix.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        normalized_matrix = matrix / row_sums
        return torch.from_numpy(normalized_matrix.astype(np.float32))


class CausalMambaBlock(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, state_dim: int,
                 node_batch: int = 16, use_causal_guidance: bool = True,
                 causal_miner_params: Optional[dict] = None):
        """Maintain backward compatibility, but use_causal_guidance is now always True"""
        super().__init__()
        self.hidden_dim = hidden_dim
        self.state_dim = state_dim
        self.node_batch = node_batch
        self._use_causal_guidance = use_causal_guidance

        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.output_proj = nn.Linear(hidden_dim, hidden_dim)
        self.input_norm = nn.LayerNorm(hidden_dim)
        self.mamba_norm = nn.LayerNorm(hidden_dim)

        self.mamba = Mamba(
            d_model=hidden_dim,
            d_state=16,
            d_conv=4,
            expand=2,
        )

        self.state_proj = nn.Linear(hidden_dim, state_dim)
        self.state_to_hidden = nn.Linear(state_dim, hidden_dim)
        self.gate = nn.Linear(2 * hidden_dim, hidden_dim)
        self.activation = nn.ReLU()

        self.causal_attention = nn.MultiheadAttention(
            hidden_dim, num_heads=4, batch_first=True
        )
        self.causal_layer_norm = nn.LayerNorm(hidden_dim)

        if causal_miner_params is None:
            causal_miner_params = {
                'lag': 2,
                'threshold': 0.05,
                'use_poi': False,
                'use_spatial': False,
                'alpha': 0.7
            }

        self.causal_miner = CorrelationGrangerCausal(**causal_miner_params)
        self.external_causal_miner = None

    def set_external_causal_miner(self, miner):
        self.external_causal_miner = miner

    def _extract_causal_patterns(self, x: torch.Tensor) -> torch.Tensor:
        B, T, N, _ = x.shape
        device = x.device

        miner_to_use = self.external_causal_miner if self.external_causal_miner else self.causal_miner

        try:
            flow_data = x.mean(dim=-1)
            causal_matrix = miner_to_use.compute(
                flow_data=flow_data.reshape(B, T, N)
            )

            if causal_matrix.shape[0] != N:
                causal_matrix = F.interpolate(
                    causal_matrix.unsqueeze(0).unsqueeze(0).float(),
                    size=(N, N), mode='bilinear'
                ).squeeze().to(x.dtype)

            return causal_matrix.to(device)

        except Exception as e:
            print(f"Warning: Causal mining failed, using identity matrix: {e}")
            return torch.eye(N, device=device)

    def forward(self, x: torch.Tensor, C: torch.Tensor, h_prev: torch.Tensor,
                causal_adj: Optional[torch.Tensor] = None):

        B, T, N, _ = x.shape
        device = x.device

        if causal_adj is None:
            causal_adj = self._extract_causal_patterns(x)

        x_proj = self.input_proj(x)
        x_proj = self.input_norm(x_proj)
        x_proj = self.activation(x_proj)

        x_reshaped = x_proj.permute(0, 2, 1, 3).contiguous()
        x_reshaped = x_reshaped.view(B * N, T, self.hidden_dim)

        mamba_out = self.mamba(x_reshaped)
        mamba_out = mamba_out.view(B, N, T, self.hidden_dim).permute(0, 2, 1, 3)
        mamba_out = self.mamba_norm(mamba_out)
        mamba_out = self.activation(mamba_out)

        outputs = []
        h_current = h_prev.clone()
        upstream = torch.einsum("ij,bjd->bid", C.to(device), h_current)

        for t in range(T):
            x_t_nodes = mamba_out[:, t, :, :]
            state_update = self.state_proj(x_t_nodes)
            h_current_state = torch.tanh(state_update + 0.1 * upstream)

            h_current_hidden = self.state_to_hidden(h_current_state)
            h_causal_enhanced = self._apply_causal_guidance(
                h_current_hidden, causal_adj
            )
            h_current_hidden = h_current_hidden + 0.2 * h_causal_enhanced
            h_current_state = self.state_proj(h_current_hidden)

            node_out = self.state_to_hidden(h_current_state)

            out_batches = []
            for start in range(0, N, self.node_batch):
                end = min(start + self.node_batch, N)
                x_batch = x_t_nodes[:, start:end, :]
                node_out_batch = node_out[:, start:end, :]

                if self.training and N > self.node_batch * 2:
                    processed_batch = checkpoint(
                        self._process_node_batch, x_batch, node_out_batch,
                        use_reentrant=False
                    )
                else:
                    processed_batch = self._process_node_batch(x_batch, node_out_batch)
                out_batches.append(processed_batch)

            node_out = torch.cat(out_batches, dim=1)
            outputs.append(node_out.unsqueeze(1))

            upstream = torch.einsum("ij,bjd->bid", C.to(device), h_current_state)
            h_current = h_current_state

        final_output = torch.cat(outputs, dim=1)
        final_output = self.output_proj(final_output)

        return final_output, h_current

    def _process_node_batch(self, x_batch, node_out_batch):
        gate_input = torch.cat([x_batch, node_out_batch], dim=-1)
        gate = torch.sigmoid(self.gate(gate_input))
        return gate * node_out_batch

    def _apply_causal_guidance(self, h_current: torch.Tensor, causal_adj: torch.Tensor):

        B, N, D = h_current.shape

        if causal_adj.dim() == 2 and causal_adj.shape[0] != N:
            causal_adj = F.interpolate(
                causal_adj.unsqueeze(0).unsqueeze(0).float(),
                size=(N, N), mode='bilinear'
            ).squeeze().to(h_current.dtype)

        h_enhanced, _ = self.causal_attention(
            h_current, h_current, h_current,
            attn_mask=causal_adj
        )

        h_enhanced = self.causal_layer_norm(h_current + h_enhanced)
        return h_enhanced


class MultiGrainMambaPredictor(nn.Module):
    """Fully backward compatible version"""

    def __init__(self, fine_nodes: int, coarse_nodes: int, hidden_dim: int = 32,
                 state_dim: int = 16, node_batch: int = 16,
                 use_fine_causal: bool = True, use_coarse_causal: bool = True,
                 causal_miner_params: Optional[dict] = None, **kwargs):
        """
        Keep the original interface completely unchanged
        use_fine_causal and use_coarse_causal are now ignored (always True)
        **kwargs: Used to receive other unrelated parameters, ensuring compatibility
        """
        super().__init__()
        self.fine_nodes = fine_nodes
        self.coarse_nodes = coarse_nodes
        # Keep parameters but not use them (for compatibility)
        self._use_fine_causal = use_fine_causal
        self._use_coarse_causal = use_coarse_causal

        # Fine-grained Mamba (always uses causal mining)
        self.fine_mamba = CausalMambaBlock(
            1, hidden_dim, state_dim,
            node_batch=node_batch,
            use_causal_guidance=True,  # Always True
            causal_miner_params=causal_miner_params
        )

        # Coarse-grained Mamba (always uses causal mining)
        self.coarse_mamba = CausalMambaBlock(
            1, hidden_dim, state_dim,
            node_batch=node_batch,
            use_causal_guidance=True,  # Always True
            causal_miner_params=causal_miner_params
        )

        # Output layers (remain unchanged)
        self.fine_output = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

        self.coarse_output = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

        # Initialize weights
        self._initialize_weights()

    def set_external_causal_miners(self, fine_miner=None, coarse_miner=None):
        """Set external causal mining modules (optional)"""
        if fine_miner is not None:
            self.fine_mamba.set_external_causal_miner(fine_miner)
        if coarse_miner is not None:
            self.coarse_mamba.set_external_causal_miner(coarse_miner)

    def _initialize_weights(self):
        """Initialize weights"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, flow_fine: torch.Tensor, flow_coarse: torch.Tensor,
                C_coarse: torch.Tensor, C_fine: Optional[torch.Tensor] = None):
        """
        Modified: Generate and return causal matrices
        """
        B, T, G = flow_fine.shape
        _, _, K = flow_coarse.shape
        device = flow_fine.device

        fine_h = torch.zeros(B, G, self.fine_mamba.state_dim, device=device)
        coarse_h = torch.zeros(B, K, self.coarse_mamba.state_dim, device=device)

        fine_input = flow_fine.unsqueeze(-1)
        coarse_input = flow_coarse.unsqueeze(-1)

        with torch.amp.autocast('cuda', enabled=True):
            # Fine-grained prediction
            fine_out, fine_h_final = self.fine_mamba(
                fine_input,
                torch.eye(G, device=device),
                fine_h,
                causal_adj=C_fine
            )

            fine_last = fine_out[:, -1, :, :]
            pred_fine = self.fine_output(fine_last).squeeze(-1)

            # Coarse-grained prediction
            coarse_out, coarse_h_final = self.coarse_mamba(
                coarse_input,
                C_coarse,
                coarse_h,
                causal_adj=C_coarse
            )

            coarse_last = coarse_out[:, -1, :, :]
            pred_coarse = self.coarse_output(coarse_last).squeeze(-1)

        # ========== New: Generate causal matrices ==========
        # Method 1: Extract from CausalMambaBlock
        fine_causal_matrix = self.fine_mamba._extract_causal_patterns(fine_input)
        coarse_causal_matrix = self.coarse_mamba._extract_causal_patterns(coarse_input)

        # Method 2: If CausalMambaBlock already generates internally, can use directly
        # You need to check if CausalMambaBlock returns causal matrices in forward

        # Ensure correct dimensions
        if fine_causal_matrix.dim() == 2:
            # fine_causal_matrix: [G, G]
            pass
        elif fine_causal_matrix.dim() == 4:
            # If it's [B, 1, G, G], take first batch
            fine_causal_matrix = fine_causal_matrix[0, 0] if fine_causal_matrix.shape[0] > 0 else fine_causal_matrix[0]

        if coarse_causal_matrix.dim() == 2:
            # coarse_causal_matrix: [K, K]
            pass
        elif coarse_causal_matrix.dim() == 4:
            coarse_causal_matrix = coarse_causal_matrix[0, 0] if coarse_causal_matrix.shape[0] > 0 else coarse_causal_matrix[0]

        # Return 4 values
        return pred_fine.unsqueeze(1), pred_coarse.unsqueeze(1), fine_causal_matrix, coarse_causal_matrix