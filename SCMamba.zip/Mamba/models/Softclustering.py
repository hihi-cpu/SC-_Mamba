import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, List, Tuple
import numpy as np
import math

from models.Mam import MultiGrainMambaPredictor


import torch.nn.functional as F
from typing import Optional, List, Tuple, Dict
import math
import numpy as np
import torch
import torch.nn as nn

class SoftCluster(nn.Module):
    """
    Enhanced interface version: Maintains core interface compatibility while supporting semantic and adjacency information
    """

    def __init__(self, input_dim: int, num_clusters: int = 5, hidden_dim: Optional[int] = None,
                 redundancy_threshold: float = 0.1, use_full_metric: bool = False,
                 use_semantic_enhancement: bool = True):
        super().__init__()

        self.input_dim = input_dim
        self.num_clusters = num_clusters
        self.use_semantic_enhancement = use_semantic_enhancement

        # Set hidden dimension
        if hidden_dim is None:
            hidden_dim = input_dim

        # Create improved clustering module
        self.dynamic_cluster = TemporalDynamicSoftCluster(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            max_clusters=num_clusters,
            redundancy_threshold=redundancy_threshold,
            use_full_metric=use_full_metric
        )

        # Output projection to ensure dimension compatibility
        self.output_proj = nn.Linear(hidden_dim, input_dim)

    def forward(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None,
                semantic_features: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Enhanced forward propagation interface
        H: (B, G, d) - Node features
        adjs: List of adjacency matrices (for spatial constraints)
        semantic_features: (B, G, s) or (G, s) - Semantic features (optional)
        returns: (assignments, H_coarse)
        """
        B, G, d = H.shape

        # Fuse semantic features (if provided)
        if semantic_features is not None and self.use_semantic_enhancement:
            if semantic_features.dim() == 2:  # (G, s)
                semantic_features = semantic_features.unsqueeze(0).expand(B, -1, -1)

            # Check semantic feature dimensions and adjust
            if semantic_features.shape[1] != G:
                # If semantic feature dimensions don't match, interpolate or project
                if semantic_features.shape[1] < G:
                    # Upsample
                    semantic_features = F.interpolate(
                        semantic_features.transpose(1, 2),
                        size=G,
                        mode='linear',
                        align_corners=False
                    ).transpose(1, 2)
                else:
                    # Downsample
                    semantic_features = semantic_features[:, :G, :]

            # Concatenate semantic features
            H_enhanced = torch.cat([H, semantic_features], dim=-1)
            enhanced_dim = H_enhanced.shape[-1]

            # Dynamically adjust clustering module input dimension
            if hasattr(self.dynamic_cluster.gnn_encoder[0], 'in_features'):
                if self.dynamic_cluster.gnn_encoder[0].in_features != enhanced_dim:
                    # Recreate GNN encoder to adapt to new input dimension
                    self.dynamic_cluster.gnn_encoder = nn.Sequential(
                        nn.Linear(enhanced_dim, self.dynamic_cluster.hidden_dim),
                        nn.ReLU(),
                        nn.Linear(self.dynamic_cluster.hidden_dim, self.dynamic_cluster.hidden_dim),
                        nn.LayerNorm(self.dynamic_cluster.hidden_dim)
                    ).to(H.device)
        else:
            H_enhanced = H
            enhanced_dim = d

        # Extract main adjacency matrix (if available)
        adj = adjs[0] if adjs and len(adjs) > 0 else None

        # Call improved clustering module
        cluster_output = self.dynamic_cluster(H_enhanced, adj=adj)

        # Extract outputs compatible with original system
        assignments = cluster_output['assignment']  # (B, G, K)
        H_coarse = cluster_output['zone_features']  # (B, K, d)

        # Ensure output dimensions are compatible with original system
        H_coarse = self.output_proj(H_coarse)  # (B, K, d)

        return assignments, H_coarse

    def forward_original(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Maintain interface fully compatible with original system
        """
        return self.forward(H, adjs, semantic_features=None)

    def get_cluster_analysis(self, H: torch.Tensor, adjs: Optional[List[torch.Tensor]] = None,
                             semantic_features: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """Get clustering analysis information"""
        adj = adjs[0] if adjs and len(adjs) > 0 else None

        # Fuse semantic features
        if semantic_features is not None and self.use_semantic_enhancement:
            B, G, d = H.shape
            if semantic_features.dim() == 2:
                semantic_features = semantic_features.unsqueeze(0).expand(B, -1, -1)

            # Check semantic feature dimensions and adjust
            if semantic_features.shape[1] != G:
                if semantic_features.shape[1] < G:
                    semantic_features = F.interpolate(
                        semantic_features.transpose(1, 2),
                        size=G,
                        mode='linear',
                        align_corners=False
                    ).transpose(1, 2)
                else:
                    semantic_features = semantic_features[:, :G, :]

            H_enhanced = torch.cat([H, semantic_features], dim=-1)
            enhanced_dim = H_enhanced.shape[-1]

            # Dynamically adjust GNN encoder
            if hasattr(self.dynamic_cluster.gnn_encoder[0], 'in_features'):
                if self.dynamic_cluster.gnn_encoder[0].in_features != enhanced_dim:
                    self.dynamic_cluster.gnn_encoder = nn.Sequential(
                        nn.Linear(enhanced_dim, self.dynamic_cluster.hidden_dim),
                        nn.ReLU(),
                        nn.Linear(self.dynamic_cluster.hidden_dim, self.dynamic_cluster.hidden_dim),
                        nn.LayerNorm(self.dynamic_cluster.hidden_dim)
                    ).to(H.device)
        else:
            H_enhanced = H

        cluster_output = self.dynamic_cluster(H_enhanced, adj=adj)

        analysis = {
            'hard_assignment': torch.argmax(cluster_output['assignment'], dim=-1),
            'active_cluster_count': cluster_output['active_cluster_count'],
            'gate_weights': cluster_output['gate_weights'],
            'static_similarity': cluster_output['static_similarity'],
            'dynamic_similarity': cluster_output['dynamic_similarity']
        }

        return analysis

class TemporalDynamicSoftCluster(nn.Module):
    """
    Improved temporal dynamic soft clustering module (internal implementation)
    """

    def __init__(self, input_dim: int, hidden_dim: int, max_clusters: int = 100,
                 redundancy_threshold: float = 0.1, temp_init: float = 1.0,
                 use_full_metric: bool = False, device: Optional[str] = None):
        super().__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.max_clusters = int(max_clusters)
        self.redundancy_threshold = redundancy_threshold
        self.temperature = float(temp_init)
        self.use_full_metric = bool(use_full_metric)
        self.device = device

        # ==================== GNN Encoder ====================
        # Use dynamic input dimension
        self.gnn_encoder = self._create_gnn_encoder(input_dim, hidden_dim)

        # ==================== Semantic-Aware Cluster Centers ====================
        # Static semantic centers (learning city functional zones)
        self.static_centers = nn.Parameter(torch.randn(self.max_clusters, hidden_dim) * 0.1)

        # Dynamic semantic centers (adapting to spatiotemporal changes)
        self.dynamic_centers_init = nn.Parameter(torch.randn(self.max_clusters, hidden_dim) * 0.1)
        self.center_evolution = nn.GRUCell(hidden_dim, hidden_dim)

        # ==================== Semantic Gating Mechanism ====================
        self.semantic_gate = nn.Sequential(
            nn.Linear(hidden_dim, max(16, hidden_dim // 4)),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(max(16, hidden_dim // 4), self.max_clusters),
            nn.Sigmoid()
        )

        # ==================== Semantic Metric Learning ====================
        if self.use_full_metric:
            # Full semantic metric matrix
            self.semantic_metric = nn.Parameter(torch.eye(hidden_dim))
        else:
            # Diagonal semantic metric (more efficient)
            self.semantic_weights = nn.Parameter(torch.ones(hidden_dim))

        # ==================== Spatial Relationship Encoding ====================
        # Fixed spatial relationship encoder, input dimension should be cluster count
        self.spatial_encoder = nn.Sequential(
            nn.Linear(self.max_clusters, hidden_dim // 2),  # Input is cluster count
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, hidden_dim)
        )

        # ==================== Multi-Granularity Semantic Output ====================
        self.semantic_node_proj = nn.Linear(hidden_dim, hidden_dim)
        self.semantic_zone_proj = nn.Linear(hidden_dim, hidden_dim)

        # Initialize parameters
        self.reset_parameters()

    def _create_gnn_encoder(self, input_dim: int, hidden_dim: int) -> nn.Sequential:
        """Create GNN encoder"""
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )

    def reset_parameters(self):
        """Initialize semantic-aware parameters"""
        nn.init.xavier_uniform_(self.static_centers)
        nn.init.xavier_uniform_(self.dynamic_centers_init)
        if self.use_full_metric:
            nn.init.orthogonal_(self.semantic_metric)
        else:
            nn.init.ones_(self.semantic_weights)

    def compute_semantic_distance(self, features: torch.Tensor, centers: torch.Tensor) -> torch.Tensor:
        """
        Semantic-aware distance calculation
        Consider semantic similarity and functional correlation between nodes
        """
        B, N, D = features.shape
        device = features.device

        if centers.dim() == 2:
            K = centers.shape[0]
            centers_b = centers.unsqueeze(0).expand(B, -1, -1).to(device)
        else:
            centers_b = centers.to(device)
            K = centers_b.shape[1]

        if not self.use_full_metric:
            # Semantic weighted distance
            semantic_weights = torch.sigmoid(self.semantic_weights).to(device)
            f_weighted = features * semantic_weights.view(1, 1, D)
            c_weighted = centers_b * semantic_weights.view(1, 1, D)

            # Semantic-aware Euclidean distance
            f_sq = (f_weighted ** 2).sum(dim=-1, keepdim=True)
            c_sq = (c_weighted ** 2).sum(dim=-1).unsqueeze(1)
            cross = torch.matmul(f_weighted, c_weighted.transpose(1, 2))
            semantic_dist = f_sq + c_sq - 2.0 * cross
        else:
            # Full semantic metric distance
            M = torch.matmul(self.semantic_metric.t(), self.semantic_metric).to(device)
            xMx = torch.einsum('bnd,df,bnf->bn', features, M, features)
            cMc = torch.einsum('bkd,df,bkf->bk', centers_b, M, centers_b)
            xMc = torch.einsum('bnd,df,bkf->bnk', features, M, centers_b)
            semantic_dist = xMx.unsqueeze(-1) + cMc.unsqueeze(1) - 2.0 * xMc

        semantic_dist = torch.clamp(semantic_dist, min=0.0)
        return semantic_dist

    def compute_semantic_redundancy(self, features: torch.Tensor) -> torch.Tensor:
        """Calculate semantic feature redundancy"""
        B, N, D = features.shape
        device = features.device

        # Normalize semantic features
        semantic_norm = F.normalize(features, p=2, dim=-1)

        # Semantic similarity matrix
        semantic_sim = torch.matmul(semantic_norm, semantic_norm.transpose(1, 2))

        # Exclude self-similarity
        eye = torch.eye(N, device=device, dtype=semantic_sim.dtype).unsqueeze(0)
        semantic_sim = semantic_sim * (1.0 - eye)

        # Semantic redundancy
        redundancy = semantic_sim.sum(dim=(1, 2)) / (N * (N - 1) + 1e-8)

        return redundancy

    def evolve_semantic_centers(self, features: torch.Tensor,
                                prev_centers: Optional[torch.Tensor]) -> torch.Tensor:
        """
        Semantic center evolution
        Update dynamic centers based on current semantic features
        """
        B, N, D = features.shape
        K = self.max_clusters
        device = features.device

        if prev_centers is None:
            return self.dynamic_centers_init.unsqueeze(0).expand(B, -1, -1).to(device)

        if prev_centers.dim() == 2:
            prev = prev_centers.unsqueeze(0).expand(B, -1, -1).to(device)
        else:
            prev = prev_centers.to(device)

        # Semantic feature aggregation
        semantic_agg = features.mean(dim=1)  # (B, D)
        semantic_agg_exp = semantic_agg.unsqueeze(1).expand(-1, K, -1).reshape(B * K, D)
        prev_flat = prev.reshape(B * K, D)

        # Semantic center evolution
        updated_flat = self.center_evolution(semantic_agg_exp, prev_flat)
        updated = updated_flat.view(B, K, D)

        return updated

    def compute_semantic_assignment(self, features: torch.Tensor,
                                    centers: torch.Tensor,
                                    gate_weights: torch.Tensor) -> tuple:
        """
        Semantic-aware soft assignment calculation
        """
        device = features.device

        # Static semantic similarity (long-term functional similarity)
        static_centers = self.static_centers.to(device)
        static_dist = self.compute_semantic_distance(features, static_centers)
        static_sim = torch.exp(-static_dist / (self.temperature + 1e-9))

        # Dynamic semantic similarity (short-term spatiotemporal similarity)
        dynamic_dist = self.compute_semantic_distance(features, centers)
        dynamic_sim = torch.exp(-dynamic_dist / (self.temperature + 1e-9))

        # Semantic gating fusion
        gated_dynamic = dynamic_sim * gate_weights.unsqueeze(1)

        # Dual semantic channel fusion
        semantic_fused = 0.6 * static_sim + 0.4 * gated_dynamic

        # Semantic soft assignment
        assignment = F.softmax(semantic_fused / (self.temperature + 1e-9), dim=-1)

        return assignment, static_sim, dynamic_sim

    def apply_semantic_constraints(self, assignment: torch.Tensor,
                                   adj: Optional[torch.Tensor]) -> torch.Tensor:
        """
        Apply semantic spatial constraints
        Smooth semantic assignments based on adjacency relationships
        """
        if adj is None:
            return assignment

        device = assignment.device

        if adj.dim() == 2:
            adj_b = adj.unsqueeze(0).expand(assignment.shape[0], -1, -1).to(device)
        else:
            adj_b = adj.to(device)

        # Spatial relationship encoding - fixed dimension handling
        # assignment shape: [B, N, K]
        B, N, K = assignment.shape

        # Reshape assignment for processing through spatial encoder
        assignment_flat = assignment.reshape(B * N, K)
        spatial_weights_flat = self.spatial_encoder(assignment_flat)
        spatial_weights = spatial_weights_flat.reshape(B, N, -1)

        # Semantic-aware graph convolution
        deg = adj_b.sum(dim=-1, keepdim=True)
        adj_norm = adj_b / (deg + 1e-8)

        # Semantic spatial smoothing
        semantic_smoothed = torch.bmm(adj_norm, assignment)
        assignment = 0.8 * assignment + 0.2 * semantic_smoothed

        return assignment

    def semantic_coarsening(self, features: torch.Tensor,
                            assignment: torch.Tensor) -> torch.Tensor:
        """
        Semantic feature coarsening
        Aggregate features based on semantic assignments
        """
        # Semantic feature aggregation
        # assignment shape: [B, N, K]
        # features shape: [B, N, D]
        semantic_clusters = torch.matmul(assignment.transpose(1, 2), features)  # [B, K, D]

        # Fixed dimension operation
        assign_sum = assignment.sum(dim=1, keepdim=True).transpose(1, 2)  # [B, K, 1]
        semantic_clusters = semantic_clusters / (assign_sum + 1e-8)

        return semantic_clusters

    def forward(self, x: torch.Tensor,
                adj: Optional[torch.Tensor] = None,
                prev_dynamic_centers: Optional[torch.Tensor] = None,
                time_step: int = 0) -> Dict[str, torch.Tensor]:
        """
        Semantic-enhanced forward propagation
        """
        B, N, F = x.shape
        device = x.device

        # 1. Semantic feature extraction
        semantic_features = self.gnn_encoder(x)

        # 2. Semantic center evolution
        dynamic_centers = self.evolve_semantic_centers(semantic_features, prev_dynamic_centers)

        # 3. Semantic redundancy analysis
        semantic_redundancy = self.compute_semantic_redundancy(semantic_features)
        semantic_ratio = 1.0 - semantic_redundancy * self.redundancy_threshold

        time_decay = 1.0 / (1.0 + 0.01 * float(time_step))
        active_ratio = semantic_ratio * time_decay
        active_count = torch.clamp(
            (active_ratio * float(self.max_clusters)).long(),
            min=3, max=self.max_clusters
        )

        # 4. Semantic gating calculation
        semantic_agg = semantic_features.max(dim=1)[0]
        semantic_gate = self.semantic_gate(semantic_agg)

        # 5. Semantic assignment calculation
        assignment, static_sim, dynamic_sim = self.compute_semantic_assignment(
            semantic_features, dynamic_centers, semantic_gate
        )

        # 6. Semantic spatial constraints
        if adj is not None:
            assignment = self.apply_semantic_constraints(assignment, adj)

        # 7. Semantic feature coarsening
        semantic_clusters = self.semantic_coarsening(semantic_features, assignment)

        # Multi-granularity semantic output
        node_semantic = self.semantic_node_proj(semantic_features)
        zone_semantic = self.semantic_zone_proj(semantic_clusters)

        # 8. Semantic-enhanced output
        output_dict = {
            'node_features': node_semantic,
            'zone_features': zone_semantic,
            'assignment': assignment,
            'dynamic_centers': dynamic_centers,
            'gate_weights': semantic_gate,
            'active_cluster_count': active_count,
            'static_similarity': static_sim,
            'dynamic_similarity': dynamic_sim,
            'semantic_features': semantic_features,
            'semantic_redundancy': semantic_redundancy
        }

        return output_dict

class ClusterQualityTracker:
    """Cluster quality tracker - fixed version"""

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.assignment_histories = []
        self.prediction_losses = []
        self.quality_metrics = {
            'balance_score': [],
            'confidence_score': [],
            'coherence_score': []
        }

    def update_metrics(self, assignments: torch.Tensor, pred_loss: float, actual_clusters: int):
        """Update quality metrics - fixed version"""
        if assignments is None:
            return

        B, N, K = assignments.shape

        # 1. Balance score - cluster size distribution
        balance_scores = []
        for b in range(B):
            cluster_sizes = assignments[b].sum(dim=0)
            if cluster_sizes.sum() > 0:
                size_dist = cluster_sizes / cluster_sizes.sum()
                entropy = -torch.sum(size_dist * torch.log(size_dist + 1e-8))
                max_entropy = math.log(K)
                balance_score = entropy / max_entropy if max_entropy > 0 else 0.0
                balance_scores.append(balance_score.item())

        balance_score = np.mean(balance_scores) if balance_scores else 0.0

        # 2. Confidence score - assignment confidence
        confidence_scores = []
        for b in range(B):
            max_probs = assignments[b].max(dim=1).values
            confidence_score = max_probs.mean().item()
            confidence_scores.append(confidence_score)

        confidence_score = np.mean(confidence_scores) if confidence_scores else 0.0

        # 3. Coherence score - based on prediction loss (inverse indicator, lower loss is better)
        coherence_score = 1.0 / (1.0 + pred_loss)  # Convert loss to score

        # Update history
        self.quality_metrics['balance_score'].append(balance_score)
        self.quality_metrics['confidence_score'].append(confidence_score)
        self.quality_metrics['coherence_score'].append(coherence_score)

        # Maintain window size
        for key in self.quality_metrics:
            if len(self.quality_metrics[key]) > self.window_size:
                self.quality_metrics[key] = self.quality_metrics[key][-self.window_size:]

    def get_overall_quality(self) -> float:
        """Get overall quality score - fixed version"""
        if not self.quality_metrics['balance_score']:
            return 0.5  # Default medium quality

        # Calculate average of each score
        balance_avg = np.mean(self.quality_metrics['balance_score'][-10:])  # Last 10 batches
        confidence_avg = np.mean(self.quality_metrics['confidence_score'][-10:])
        coherence_avg = np.mean(self.quality_metrics['coherence_score'][-10:])

        # Weighted composite score
        overall_quality = (
                0.4 * balance_avg +  # Balance weight 40%
                0.3 * confidence_avg +  # Confidence weight 30%
                0.3 * coherence_avg  # Coherence weight 30%
        )

        return float(overall_quality)

    def get_optimization_advice(self) -> Dict[str, str]:
        """Get optimization advice - fixed version"""
        quality = self.get_overall_quality()

        if quality > 0.7:
            return {"focus": "maintain_quality", "weight_suggestion": "stable"}
        elif quality > 0.4:
            return {"focus": "improve_balance", "weight_suggestion": "moderate"}
        else:
            return {"focus": "enhance_clustering", "weight_suggestion": "increase"}


class JointClusterConstraint:
    """Joint clustering constraint - only computes clustering constraints"""

    def __init__(self, num_clusters: int = 5,
                 spatial_weight: float = 0.01,
                 balance_weight: float = 0.01):
        self.num_clusters = num_clusters
        self.spatial_weight = spatial_weight
        self.balance_weight = balance_weight

    def compute_constraint_loss(self, assignments: torch.Tensor,
                                adj_matrix: torch.Tensor = None,
                                valid_indices: torch.Tensor = None) -> Dict[str, torch.Tensor]:
        """
        Only compute clustering constraint loss, without any prediction metrics
        """
        device = assignments.device

        # 1. Spatial consistency loss
        spatial_loss = self._compute_simple_spatial_loss(assignments, adj_matrix, valid_indices)
        weighted_spatial = self.spatial_weight * spatial_loss

        # 2. Balance constraint loss
        balance_loss = self._compute_simple_balance_loss(assignments)
        weighted_balance = self.balance_weight * balance_loss

        # 3. Total constraint loss
        total_constraint = weighted_spatial + weighted_balance

        return {
            'total_constraint_loss': total_constraint,
            'spatial_loss': spatial_loss,
            'balance_loss': balance_loss,
            'weighted_spatial': weighted_spatial,
            'weighted_balance': weighted_balance
        }

    def _compute_simple_spatial_loss(self, assignments: torch.Tensor,
                                     adj_matrix: torch.Tensor,
                                     valid_indices: torch.Tensor = None) -> torch.Tensor:
        """
        Simplified spatial consistency loss
        """
        B, N, K = assignments.shape

        # Ensure dimensions match
        if adj_matrix.size(0) != N:
            if valid_indices is not None and len(valid_indices) == N:
                # If adj_matrix is full size, need to extract valid nodes
                if adj_matrix.size(0) > N:
                    adj_matrix = adj_matrix[valid_indices][:, valid_indices]
            else:
                # Mismatch, return 0 loss
                return torch.tensor(0.0, device=assignments.device)

        spatial_loss = 0.0

        for b in range(min(B, 4)):  # Limit batch count
            # Neighbor assignments
            neighbor_assign = torch.matmul(adj_matrix, assignments[b])

            # Consistency loss: assignment should be similar to neighbors
            diff = assignments[b] - neighbor_assign
            loss_b = torch.mean(torch.sum(diff ** 2, dim=1))
            spatial_loss += loss_b

        spatial_loss = spatial_loss / min(B, 4)

        # Normalization
        spatial_loss = spatial_loss / (N * K)

        return spatial_loss

    def _compute_simple_balance_loss(self, assignments: torch.Tensor) -> torch.Tensor:
        """
        Simplified balance constraint loss
        """
        B, N, K = assignments.shape

        balance_loss = 0.0

        for b in range(min(B, 4)):  # Limit batch count
            # Compute "mass" of each cluster
            cluster_masses = assignments[b].sum(dim=0)  # [K]

            # Ideally each cluster should have N/K nodes
            ideal_mass = N / K

            # Balance loss: difference between actual mass and ideal mass
            imbalance = torch.abs(cluster_masses - ideal_mass)
            balance_loss += imbalance.mean() / ideal_mass  # Normalized

        balance_loss = balance_loss / min(B, 4)

        return balance_loss


class ClusterGuidedPredictor(nn.Module):
    """Cluster-guided predictor - uses StackingEnsemble for fusion"""

    def __init__(self, fine_nodes, grid_size=(20, 23), hidden_dim=32, num_clusters=5,
                 use_metric_loss=False, metric_weights=None, use_stacking_fusion=True):
        super().__init__()

        self.fine_nodes = fine_nodes  # Valid node count: 108
        self.grid_h, self.grid_w = grid_size
        self.grid_nodes = self.grid_h * self.grid_w
        self.num_clusters = num_clusters
        self.use_metric_loss = use_metric_loss
        self.use_stacking_fusion = use_stacking_fusion

        # Metric weights
        self.metric_weights = metric_weights if metric_weights else {
            'mae': 1.0,
            'rmse': 0.3,
            'r2': 0.2
        }

        print(f" Creating ClusterGuidedPredictor:")
        print(f"   Valid node count: {fine_nodes}")
        print(f"   Grid size: {grid_size}")
        print(f"   Total grid nodes: {self.grid_nodes}")
        print(f"   Cluster count: {num_clusters}")
        print(f"   Using metric loss: {use_metric_loss}")
        print(f"   Using StackingEnsemble fusion: {use_stacking_fusion}")

        # 1. Clustering module
        self.cluster = SoftCluster(
            input_dim=1,
            num_clusters=num_clusters,
            hidden_dim=hidden_dim
        )

        # 2. Prediction model
        self.predictor = MultiGrainMambaPredictor(
            fine_nodes=fine_nodes,
            coarse_nodes=num_clusters,
            hidden_dim=hidden_dim,
            state_dim=16,
            node_batch=16,
            use_fine_causal=True,
            use_coarse_causal=True
        )

        # 3. Constraint module
        self.constraint = JointClusterConstraint(num_clusters=num_clusters)

        # 4. StackingEnsemble fusion module
        if use_stacking_fusion:
            # Ensure StackingEnsemble can be imported
            try:
                from models.model_utils import StackingEnsemble
                self.stacking_ensemble = StackingEnsemble(
                    num_predictors=2,  # Fusion of fine-grained and coarse-grained predictions
                    hidden_dim=hidden_dim
                )
                print(f"   StackingEnsemble initialization successful")
            except ImportError as e:
                print(f"   Unable to import StackingEnsemble: {e}")
                print(f"   Falling back to simple fusion")
                self.use_stacking_fusion = False

        # 5. Caching
        self.last_assignments = None
        self.last_fine_features = None

    def forward(self, flow_data, adj_matrix=None, return_cluster_info=False,
                valid_indices=None, return_causal_matrix=False):
        """
        Forward propagation - using StackingEnsemble fusion
        Keep the interface completely unchanged!
        """
        B, T, N = flow_data.shape

        # ==================== 1. Clustering ====================
        H_fine = flow_data[:, -1:, :].transpose(1, 2)  # [B, N, 1]

        assignments, coarse_features = self.cluster(
            H_fine,
            adjs=[adj_matrix] if adj_matrix is not None else None
        )

        # Cache clustering results
        self.last_assignments = assignments  # [B, N, K]
        self.last_fine_features = H_fine

        # ==================== 2. Create coarse-grained flow ====================
        coarse_flow = self._aggregate_to_coarse(flow_data, assignments)  # [B, T, K]

        # ==================== 3. Build coarse-grained adjacency matrix ====================
        C_coarse = self._build_coarse_adjacency(assignments, adj_matrix)  # [K, K]

        # ==================== 4. Dual-granularity prediction ====================
        pred_fine, pred_coarse, fine_causal_matrix, coarse_causal_matrix = self.predictor(
            flow_fine=flow_data,
            flow_coarse=coarse_flow,
            C_coarse=C_coarse,
            C_fine=adj_matrix
        )

        # ==================== 5. Use StackingEnsemble for fusion ====================
        if self.use_stacking_fusion and hasattr(self, 'stacking_ensemble'):
            # Key: Must first upsample coarse-grained prediction to fine-grained dimension
            pred_fine = self._fuse_with_stacking(pred_fine, pred_coarse, assignments)

        # ==================== 6. Return results ====================
        outputs = {
            'fine_predictions': pred_fine,  # [B, 1, N]
            'coarse_predictions': pred_coarse,  # [B, 1, K]
            'assignments': assignments,  # [B, N, K]
            'coarse_flow': coarse_flow,  # [B, T, K]
            'C_coarse': C_coarse,  # [K, K]
            'fine_causal_matrix': fine_causal_matrix,  # [N, N] - new
            'coarse_causal_matrix': coarse_causal_matrix,  # [K, K] - new
        }

        if return_cluster_info:
            outputs.update({
                'coarse_features': coarse_features,
                'clustering_quality': self._evaluate_clustering_quality(assignments),
                'fusion_used': self.use_stacking_fusion
            })

        return outputs

    def _fuse_with_stacking(self, pred_fine, pred_coarse, assignments):
        """
        Use StackingEnsemble to fuse predictions
        Steps:
        1. Use assignment matrix to upsample coarse-grained prediction to fine-grained dimension
        2. Use StackingEnsemble to fuse two fine-grained dimension predictions
        """
        B, _, N = pred_fine.shape  # N = 108
        _, _, K = pred_coarse.shape  # K = 5

        # 1. Upsample coarse-grained prediction using assignment matrix
        # assignments: [B, N, K]
        assignments_T = assignments.transpose(1, 2)  # [B, K, N]
        pred_coarse = pred_coarse.float()  # Ensure float32
        assignments_T = assignments_T.float()  # Ensure float32

        # Upsample: [B, 1, K] @ [B, K, N] = [B, 1, N]
        pred_coarse_upsampled = torch.bmm(pred_coarse, assignments_T)

        # 2. Ensure dimensions match
        assert pred_fine.shape == (B, 1, N), f"pred_fine shape error: {pred_fine.shape}"
        assert pred_coarse_upsampled.shape == (B, 1, N), f"upsampled shape error: {pred_coarse_upsampled.shape}"

        # 3. Use StackingEnsemble for fusion
        # StackingEnsemble expects input: List[Tensor], each Tensor is [B, 1, N]
        fused_pred = self.stacking_ensemble([pred_fine, pred_coarse_upsampled])

        # 4. Verify output dimensions
        assert fused_pred.shape == (B, 1, N), f"fused_pred shape error: {fused_pred.shape}"

        return fused_pred

    # ==================== Keep original methods completely unchanged ====================

    def compute_all_metrics(self, predictions, targets):
        """Compute all evaluation metrics"""
        pred_flat = predictions.reshape(-1)
        targ_flat = targets.reshape(-1)

        metrics = {}
        metrics['mae'] = F.l1_loss(pred_flat, targ_flat)
        metrics['mse'] = F.mse_loss(pred_flat, targ_flat)
        metrics['rmse'] = torch.sqrt(metrics['mse'] + 1e-8)

        ss_tot = torch.mean((targ_flat - torch.mean(targ_flat)) ** 2)
        metrics['r2'] = metrics['mse'] / (ss_tot + 1e-8)

        return metrics

    def compute_weighted_metric_loss(self, metrics, weights):
        """Compute weighted metric loss"""
        device = next(self.parameters()).device
        weighted_loss = torch.tensor(0.0, device=device)
        for metric_name, weight in weights.items():
            if metric_name in metrics and weight > 0:
                weighted_loss += weight * metrics[metric_name]
        return weighted_loss

    def compute_joint_loss(self, predictions, targets, features=None,
                           adj_matrix=None, valid_indices=None, verbose=False):
        """Compute joint loss - keep original implementation completely unchanged"""
        device = predictions.device

        # 1. Compute all prediction metrics
        metrics = self.compute_all_metrics(predictions, targets)

        # 2. Compute prediction loss component
        if self.use_metric_loss:
            weighted_metric_loss = self.compute_weighted_metric_loss(
                metrics, self.metric_weights
            )
            pred_loss_component = 0.8 * weighted_metric_loss + 0.2 * metrics['mse']
        else:
            pred_loss_component = metrics['mse']

        # 3. Get clustering constraint loss
        constraint_loss = torch.tensor(0.0, device=device)
        constraint_info = {}

        if hasattr(self, 'constraint') and self.constraint is not None:
            if self.last_assignments is not None:
                constraint_info = self.constraint.compute_constraint_loss(
                    assignments=self.last_assignments,
                    adj_matrix=adj_matrix,
                    valid_indices=valid_indices
                )
                constraint_loss = constraint_info['total_constraint_loss']

        # 4. Calculate total loss
        total_loss = pred_loss_component + 0.1 * constraint_loss

        return {
            'total_loss': total_loss,
            'prediction_loss': pred_loss_component,
            'metric_loss': weighted_metric_loss if self.use_metric_loss else torch.tensor(0.0, device=device),
            'constraint_loss': constraint_loss,
            'metrics': metrics,
            'constraint_info': constraint_info
        }

    def _aggregate_to_coarse(self, flow_data, assignments):
        """Aggregate fine-grained flow to coarse-grained"""
        B, T, N = flow_data.shape
        K = assignments.shape[-1]

        if assignments.dim() == 3:
            assignments_T = assignments.transpose(1, 2)
        else:
            assignments_T = assignments

        coarse_flow = torch.einsum('bkn,btn->btk', assignments_T, flow_data)
        return coarse_flow

    def _build_coarse_adjacency(self, assignments, fine_adj=None):
        """Build coarse-grained adjacency matrix"""
        B, N, K = assignments.shape

        if fine_adj is None:
            C = torch.eye(K, device=assignments.device)
            C = C + 0.1 * (1 - torch.eye(K, device=assignments.device))
            return C

        hard_assignments = torch.argmax(assignments, dim=-1)
        cluster_ids = hard_assignments[0]

        C = torch.zeros(K, K, device=assignments.device)

        if fine_adj.dim() == 2:
            for i in range(N):
                for j in range(N):
                    if fine_adj[i, j] > 0:
                        ci = cluster_ids[i]
                        cj = cluster_ids[j]
                        C[ci, cj] += fine_adj[i, j].item()
        else:
            fine_adj_batch = fine_adj[0]
            for i in range(N):
                for j in range(N):
                    if fine_adj_batch[i, j] > 0:
                        ci = cluster_ids[i]
                        cj = cluster_ids[j]
                        C[ci, cj] += fine_adj_batch[i, j].item()

        for i in range(K):
            row_sum = C[i].sum()
            if row_sum > 0:
                C[i] = C[i] / row_sum
            else:
                C[i, i] = 1.0

        C = (C + C.T) / 2
        return C

    def _evaluate_clustering_quality(self, assignments):
        """Evaluate clustering quality"""
        B, N, K = assignments.shape

        quality_metrics = {}

        balance_scores = []
        for b in range(B):
            cluster_sizes = assignments[b].sum(dim=0)
            if cluster_sizes.sum() > 0:
                size_dist = cluster_sizes / cluster_sizes.sum()
                entropy = -torch.sum(size_dist * torch.log(size_dist + 1e-8))
                max_entropy = torch.log(torch.tensor(K, dtype=torch.float))
                balance_score = entropy / max_entropy
                balance_scores.append(balance_score.item())

        quality_metrics['balance_score'] = np.mean(balance_scores) if balance_scores else 0.0

        confidence_scores = []
        for b in range(B):
            max_probs = assignments[b].max(dim=1).values
            confidence_scores.append(max_probs.mean().item())

        quality_metrics['confidence_score'] = np.mean(confidence_scores) if confidence_scores else 0.0

        quality_metrics['overall_quality'] = (
                0.6 * quality_metrics['balance_score'] +
                0.4 * quality_metrics['confidence_score']
        )

        return quality_metrics